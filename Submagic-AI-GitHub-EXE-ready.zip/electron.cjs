const { app, BrowserWindow, dialog } = require('electron');
const { spawn } = require('node:child_process');
const path = require('node:path');
const http = require('node:http');

let serverProcess;
let mainWindow;
const PORT = 3187;

function waitForServer(url, timeoutMs = 30000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const check = () => {
      const req = http.get(url, (res) => { res.resume(); resolve(); });
      req.on('error', () => {
        if (Date.now() - started > timeoutMs) return reject(new Error('Local Submagic server did not start in time.'));
        setTimeout(check, 300);
      });
      req.setTimeout(1000, () => req.destroy());
    };
    check();
  });
}

async function createWindow() {
  const appRoot = app.getAppPath();
  const tsxCli = path.join(appRoot, 'node_modules', 'tsx', 'dist', 'cli.mjs');
  const serverFile = path.join(appRoot, 'server.ts');
  const ffmpegPath = path.join(process.resourcesPath, 'ffmpeg.exe');
  serverProcess = spawn(process.execPath, [tsxCli, serverFile], {
    cwd: appRoot,
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', NODE_ENV: 'production', PORT: String(PORT), FFMPEG_PATH: ffmpegPath },
    stdio: 'ignore',
    windowsHide: true
  });
  serverProcess.on('error', (err) => console.error('Failed to start Submagic server:', err));
  try {
    await waitForServer(`http://127.0.0.1:${PORT}`);
    mainWindow = new BrowserWindow({ width: 1440, height: 900, minWidth: 980, minHeight: 650, autoHideMenuBar: true, webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
    await mainWindow.loadURL(`http://127.0.0.1:${PORT}`);
    mainWindow.on('closed', () => { mainWindow = null; });
  } catch (err) {
    dialog.showErrorBox('Submagic AI', `${err.message}\n\nPlease reinstall the application and try again.`);
    app.quit();
  }
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { if (serverProcess && !serverProcess.killed) serverProcess.kill(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
