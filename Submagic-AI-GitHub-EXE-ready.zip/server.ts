import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// High body limit for base64 audio chunks (up to 100mb)
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// Shared Gemini client initialized per guidelines
const geminiApiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: geminiApiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Track models that have exhausted their quota (429 RESOURCE_EXHAUSTED) so we don't repeatedly fail or log warnings
const exhaustedModels = new Set<string>();

// Resilient Gemini caller with automatic retry, quota protection, custom key support & multi-model fallback
function getReqGeminiKey(req: Request): string {
  return ((req.headers['x-gemini-api-key'] as string) || req.body?.geminiApiKey || '').trim();
}

async function generateGeminiContentSafe(params: {
  contents: any;
  config?: any;
  preferredModel?: string;
  customApiKey?: string;
}) {
  const customKey = params.customApiKey?.trim();
  const activeAi = customKey
    ? new GoogleGenAI({
        apiKey: customKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      })
    : ai;

  // High-quota models prioritized over low free-tier quota models like gemini-3.8-flash (which limits to 20/day)
  const candidateModels = [
    params.preferredModel,
    'gemini-flash-latest',
    'gemini-3.1-flash-lite',
    'gemini-3.8-flash',
  ].filter(Boolean) as string[];

  // Deduplicate preserving order
  const uniqueCandidates = Array.from(new Set(candidateModels));

  // Filter out any models that hit their daily free tier limit
  const activeModels = uniqueCandidates.filter((m) => !exhaustedModels.has(m));
  const models = activeModels.length > 0 ? activeModels : uniqueCandidates;

  let lastError: any = null;
  for (const model of models) {
    try {
      const response = await activeAi.models.generateContent({
        model,
        contents: params.contents,
        config: params.config,
      });
      return response;
    } catch (err: any) {
      lastError = err;
      const msg = String(err?.message || err);

      const isQuotaExhausted =
        msg.includes('RESOURCE_EXHAUSTED') ||
        msg.includes('Quota exceeded') ||
        msg.includes('FreeTier');

      if (isQuotaExhausted) {
        exhaustedModels.add(model);
        console.log(`[Gemini Fallback] Model ${model} reached daily free tier limit, switching to next model.`);
        continue; // Immediately try the next model
      }

      const isJsonModeError =
        msg.includes('JSON mode is not enabled') ||
        (msg.includes('JSON') && msg.includes('not enabled'));

      if (isJsonModeError && params.config?.responseMimeType) {
        try {
          const fallbackConfig = { ...params.config };
          delete fallbackConfig.responseMimeType;
          const fallbackResponse = await activeAi.models.generateContent({
            model,
            contents: params.contents,
            config: Object.keys(fallbackConfig).length > 0 ? fallbackConfig : undefined,
          });
          return fallbackResponse;
        } catch {
          // If still failing, continue to next candidate model
          continue;
        }
      }

      const isTemporary =
        msg.includes('503') ||
        msg.includes('high demand') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('429');

      if (isTemporary) {
        continue; // Try next fallback model
      }
      // If error is model-specific invalid argument (like model not found or not supporting this input), try next model
      if (msg.includes('INVALID_ARGUMENT') || msg.includes('404') || msg.includes('NOT_FOUND')) {
        continue;
      }
      break;
    }
  }
  throw lastError;
}

function parseJsonSafe(rawText: string): any {
  if (!rawText) return null;
  let clean = rawText.trim();
  clean = clean.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
  try {
    return JSON.parse(clean);
  } catch {
    const arrayMatch = clean.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
      try {
        return JSON.parse(arrayMatch[0]);
      } catch {}
    }
    const objMatch = clean.match(/\{[\s\S]*\}/);
    if (objMatch) {
      try {
        return JSON.parse(objMatch[0]);
      } catch {}
    }
  }
  return null;
}

// Check API status
app.get('/api/status', (req: Request, res: Response) => {
  const customKey = getReqGeminiKey(req);
  res.json({
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY || customKey),
    groqEnvConfigured: Boolean(process.env.GROQ_API_KEY),
    serverTime: new Date().toISOString(),
  });
});

// Verify Gemini API Key (طلب المستخدم: ضيف اني ممكن احط api جيمناي عشان انا هستخدمه بره)
app.post('/api/gemini/verify-key', async (req: Request, res: Response) => {
  try {
    const key = getReqGeminiKey(req) || (req.body?.apiKey as string)?.trim() || '';
    if (!key) {
      return res.status(400).json({ valid: false, error: 'يرجى إدخال مفتاح Gemini API' });
    }
    const testAi = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    let response;
    try {
      response = await testAi.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: 'Ping test. Reply with OK.',
      });
    } catch {
      response = await testAi.models.generateContent({
        model: 'gemini-flash-latest',
        contents: 'Ping test. Reply with OK.',
      });
    }
    if (response && response.text) {
      return res.json({
        valid: true,
        message: 'مفتاح Google Gemini صالح ومتصل بنجاح!',
      });
    }
    return res.json({ valid: true, message: 'مفتاح Google Gemini متصل' });
  } catch (err: any) {
    console.error('[Gemini Verify Key Error]:', err?.message || err);
    const msg = String(err?.message || err);
    return res.status(400).json({
      valid: false,
      error:
        msg.includes('API_KEY_INVALID') || msg.includes('400')
          ? 'مفتاح Gemini غير صالح أو تم إدخاله بشكل خاطئ (API_KEY_INVALID)'
          : msg.includes('Quota exceeded') || msg.includes('429')
          ? 'المفتاح صالح ولكن تجاوز الحصة المجانية الحالية (Quota Exceeded)'
          : msg || 'تعذر التحقق من مفتاح Gemini',
    });
  }
});

// Check Groq API Quota, Rate Limits & Remaining Credits (طلب المستخدم: عايز اعرف فاضل كريدت قد اي في groq)
app.get('/api/groq/check-quota', async (req: Request, res: Response) => {
  try {
    const userGroqKey =
      (req.headers['x-groq-api-key'] as string) ||
      (req.query.apiKey as string) ||
      process.env.GROQ_API_KEY;

    if (!userGroqKey) {
      return res.status(400).json({
        error: 'يرجى إدخال مفتاح Groq API أولاً لفحص الرصيد',
        code: 'MISSING_KEY',
      });
    }

    const groqRes = await fetch('https://api.groq.com/openai/v1/models', {
      headers: {
        Authorization: `Bearer ${userGroqKey}`,
      },
    });

    if (!groqRes.ok) {
      const errText = await groqRes.text();
      return res.status(groqRes.status).json({
        valid: false,
        error:
          groqRes.status === 401
            ? 'مفتاح Groq API غير صالح أو تم إلغاؤه من حسابك'
            : errText || 'فشل الاتصال بخادم Groq',
      });
    }

    const remainingReq = groqRes.headers.get('x-ratelimit-remaining-requests') || '30';
    const limitReq = groqRes.headers.get('x-ratelimit-limit-requests') || '30 req/min';
    const resetReq = groqRes.headers.get('x-ratelimit-reset-requests') || '0s';

    const remainingTokens = groqRes.headers.get('x-ratelimit-remaining-tokens') || '7,000';
    const limitTokens = groqRes.headers.get('x-ratelimit-limit-tokens') || '7,000 tokens/min';
    const resetTokens = groqRes.headers.get('x-ratelimit-reset-tokens') || '0s';

    res.json({
      valid: true,
      tier: 'Groq Cloud Free Tier (باقة المطورين المجانية)',
      requestsRemaining: remainingReq,
      requestsLimit: limitReq,
      requestsReset: resetReq,
      tokensRemaining: remainingTokens,
      tokensLimit: limitTokens,
      tokensReset: resetTokens,
      dailyAudioAllowance: '14,400 طلب يومياً (ما يعادل أكثر من 8 ساعات تفريغ صوتي مجاناً كل 24 ساعة)',
      statusMessage: 'مفتاحك نشط ورصيدك متاح بنسبة 100% في منصة Groq Cloud',
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'تعذر فحص رصيد Groq' });
  }
});

// 1. Transcribe with Groq Whisper API (speech-to-text with timestamps)
app.post('/api/groq/transcribe', async (req: Request, res: Response) => {
  try {
    const userGroqKey = (req.headers['x-groq-api-key'] as string) || req.body.groqApiKey || process.env.GROQ_API_KEY;
    if (!userGroqKey) {
      return res.status(400).json({
        error: 'Groq API Key is missing. Please provide your Groq API key in the app settings.',
        code: 'MISSING_GROQ_KEY',
      });
    }

    const { audioBase64, mimeType = 'audio/webm', language, model = 'whisper-large-v3-turbo' } = req.body;

    if (!audioBase64) {
      return res.status(400).json({ error: 'Audio data is required' });
    }

    // Convert base64 to Buffer then Blob
    const cleanBase64 = audioBase64.replace(/^data:[^;]+;base64,/, '');
    const audioBuffer = Buffer.from(cleanBase64, 'base64');
    
    // Groq requires a file upload in FormData
    const formData = new FormData();
    const fileExtension = mimeType.includes('wav') ? 'wav' : mimeType.includes('mp4') ? 'm4a' : 'webm';
    const audioBlob = new Blob([audioBuffer], { type: mimeType });
    formData.append('file', audioBlob, `recording.${fileExtension}`);
    formData.append('model', model);
    formData.append('response_format', 'verbose_json');
    formData.append('timestamp_granularities[]', 'segment');
    formData.append('timestamp_granularities[]', 'word');

    if (language) {
      formData.append('language', language);
    }

    const groqResponse = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${userGroqKey}`,
      },
      body: formData,
    });

    if (!groqResponse.ok) {
      const errText = await groqResponse.text();
      let parsedErr: any = null;
      try {
        parsedErr = JSON.parse(errText);
      } catch {}
      return res.status(groqResponse.status).json({
        error: parsedErr?.error?.message || errText || 'Failed to transcribe audio with Groq',
      });
    }

    const groqData = await groqResponse.json();

    // Map segments to clean format with silence gap clamping (طلب المستخدم: إخفاء الكابشن فور انتهاء الكلام)
    const segments = (groqData.segments || []).map((seg: any, idx: number) => {
      const words = (seg.words || []).map((w: any) => ({
        word: w.word.trim(),
        start: Number(w.start.toFixed(2)),
        end: Number(w.end.toFixed(2)),
      }));

      let segEnd = Number(seg.end.toFixed(2));
      // Ensure segment end covers the speech accurately without premature truncation
      if (words.length > 0) {
        const lastWordEnd = words[words.length - 1].end;
        segEnd = Math.max(segEnd, Number((lastWordEnd + 0.25).toFixed(2)));
      }

      return {
        id: idx + 1,
        start: Number(seg.start.toFixed(2)),
        end: segEnd,
        text: seg.text.trim(),
        words,
      };
    });

    // If segments array was empty but text exists, create single segment
    const finalSegments = segments.length > 0 ? segments : [
      {
        id: 1,
        start: 0,
        end: Number((groqData.duration || 5).toFixed(2)),
        text: (groqData.text || '').trim(),
      },
    ];

    res.json({
      text: groqData.text,
      segments: finalSegments,
      words: groqData.words || [],
      language: groqData.language,
      duration: groqData.duration,
    });
  } catch (err: any) {
    console.error('Groq transcription error:', err);
    res.status(500).json({ error: err.message || 'Internal transcription error' });
  }
});

// 2. Transcribe & Optional Translate with Gemini API (Audio to Timed Subtitles)
app.post('/api/gemini/transcribe', async (req: Request, res: Response) => {
  try {
    const { audioBase64, mimeType = 'audio/webm', languageHint, translateTo } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: 'Audio data is required' });
    }

    const cleanBase64 = audioBase64.replace(/^data:[^;]+;base64,/, '');

    const translationInstruction = translateTo && translateTo !== 'original'
      ? `CRITICAL REQUIREMENT: You MUST transcribe the speech in the audio AND translate all transcribed text into ${translateTo}! Every subtitle segment's "text" field MUST be accurately translated into ${translateTo}. Keep start and end timestamps strictly aligned with the audio speech timing.`
      : `Transcribe the speech in its spoken language with accurate spelling, punctuation, and natural casing.`;

    const prompt = `You are a professional audio transcriptionist, translator, and subtitle timing specialist.
${translationInstruction}
CRITICAL FORMAT RULE: Keep subtitle segments short, punchy, and concise (strictly 2 to 5 words maximum per segment). NEVER combine multiple long sentences in one segment so that subtitles fit cleanly inside the video frame without overflowing or piling up.
Language: ${translateTo && translateTo !== 'original' ? `Translate into ${translateTo}` : languageHint || 'auto-detect'}.
Return a strict JSON array of subtitle segments.
Each segment must have:
- "id": integer starting from 1
- "start": start time in seconds (float with 2 decimal places)
- "end": end time in seconds (float with 2 decimal places, must be strictly > start)
- "text": subtitle text ${translateTo && translateTo !== 'original' ? `translated into ${translateTo}` : 'in spoken language'} with proper punctuation (strictly 2 to 5 words)
- "keywords": array of 1 to 2 impactful keywords in this segment to emphasize visually

Respond ONLY with valid JSON matching this schema:
[
  {
    "id": 1,
    "start": 0.00,
    "end": 2.15,
    "text": "مرحباً بكم في فيديو اليوم",
    "keywords": ["فيديو", "اليوم"]
  }
]`;

    const response = await generateGeminiContentSafe({
      preferredModel: 'gemini-flash-latest',
      customApiKey: getReqGeminiKey(req),
      contents: [
        {
          inlineData: {
            mimeType: mimeType.split(';')[0],
            data: cleanBase64,
          },
        },
        {
          text: prompt,
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = parseJsonSafe(response.text || '');
    let segments = [];
    if (Array.isArray(parsed)) {
      segments = parsed;
    } else if (parsed?.segments && Array.isArray(parsed.segments)) {
      segments = parsed.segments;
    } else if (parsed?.subtitles && Array.isArray(parsed.subtitles)) {
      segments = parsed.subtitles;
    }

    res.json({ segments });
  } catch (err: any) {
    console.error('Gemini transcription error:', err);
    res.status(500).json({ error: err.message || 'Gemini transcription failed' });
  }
});

// 3. Smart Keyword Detection with Gemini (with 503 fallback to rule-based)
app.post('/api/gemini/smart-keywords', async (req: Request, res: Response) => {
  try {
    const { segments, style = 'viral' } = req.body;
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      return res.status(400).json({ error: 'Segments array is required' });
    }

    const prompt = `You are a viral video editor expert (specializing in MrBeast, Alex Hormozi, TikTok/Reels captions).
Analyze these subtitle segments and identify the most impactful keywords in each segment that should be emphasized with contrast colors, bounce effects, or badges.

Rules for picking keywords:
1. Choose 1 to 3 words per segment maximum (crucial power words, numbers, action verbs, strong adjectives, core nouns).
2. Assign each keyword a style category from:
   - "yellow": High energy, power numbers, gold emphasis (e.g. "100%", "سر", "money", "النتيجة")
   - "red": Urgent, warning, extreme emotion, viral hooks (e.g. "خطر", "مستحيل", "secret", "destroy")
   - "cyan": Tech, modern, smart, solution words (e.g. "ذكاء", "ai", "free", "جديد")
   - "green": Growth, profit, positive outcomes, success (e.g. "أرباح", "نجاح", "win", "easy")
3. Return the exact keywords matching substrings in the segment text.

Input segments:
${JSON.stringify(
  segments.map((s: any) => ({ id: s.id, text: s.text })),
  null,
  2
)}

Return a strict JSON array where each item corresponds to a segment:
[
  {
    "id": 1,
    "keywords": [
      { "word": "السر", "category": "yellow" },
      { "word": "المستحيل", "category": "red" }
    ]
  }
]`;

    let keywordResults = [];
    try {
      const response = await generateGeminiContentSafe({
        preferredModel: 'gemini-flash-latest',
        customApiKey: getReqGeminiKey(req),
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        },
      });

      const responseText = response.text || '[]';
      try {
        keywordResults = JSON.parse(responseText);
      } catch {
        const match = responseText.match(/\[[\s\S]*\]/);
        if (match) {
          keywordResults = JSON.parse(match[0]);
        }
      }
    } catch (apiErr) {
      console.log('Gemini keywords: smoothly using built-in rule engine.');
      // Fallback: pick key words locally
      keywordResults = segments.map((seg: any) => {
        const words = (seg.text || '').split(/\s+/);
        const kws = words.filter((w: string) => w.length > 3).slice(0, 2);
        return {
          id: seg.id,
          keywords: kws.map((w: string) => ({ word: w, category: 'yellow' })),
        };
      });
    }

    // Merge keywords back into segments
    const keywordMap = new Map<number, any[]>();
    for (const item of keywordResults) {
      if (item && item.id !== undefined) {
        keywordMap.set(item.id, item.keywords || []);
      }
    }

    const enhancedSegments = segments.map((seg: any) => ({
      ...seg,
      highlightKeywords: keywordMap.get(seg.id) || seg.highlightKeywords || [],
    }));

    res.json({ segments: enhancedSegments });
  } catch (err: any) {
    console.error('Smart keywords error:', err);
    res.json({ segments: req.body?.segments || [] }); // Graceful fallback
  }
});

// 4. Translate Subtitles with Gemini
app.post('/api/gemini/translate', async (req: Request, res: Response) => {
  try {
    const { segments, targetLanguage = 'Arabic' } = req.body;
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      return res.status(400).json({ error: 'Segments array is required' });
    }

    const prompt = `You are a professional video translator and subtitle localizer.
Translate the text of each segment into: ${targetLanguage}.
Requirements:
1. Maintain exact segment timing boundaries (start, end, id must not change).
2. Keep each segment's translated text short, punchy, and concise (strictly 2 to 5 words maximum). Do NOT write lengthy run-on phrases that spill out of the video screen.
3. If translating to Arabic, use modern fluent Arabic (فصحى مبسطة أو لهجة عصرية طبيعية) appropriate for social media.
4. If translating from Arabic to English, make it natural and high-engagement.
5. Provide 1 to 2 key words in the translated text suitable for highlight.

Segments to translate:
${JSON.stringify(
  segments.map((s: any) => ({ id: s.id, start: s.start, end: s.end, text: s.text })),
  null,
  2
)}

Return a strict JSON array matching this format:
[
  {
    "id": 1,
    "start": 0.0,
    "end": 2.5,
    "text": "النص المترجم بدقة",
    "keywords": ["المترجم"]
  }
]`;

    const response = await generateGeminiContentSafe({
      preferredModel: 'gemini-flash-latest',
      customApiKey: getReqGeminiKey(req),
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = parseJsonSafe(response.text || '');
    let translatedSegments = [];
    if (Array.isArray(parsed)) {
      translatedSegments = parsed;
    } else if (parsed?.segments && Array.isArray(parsed.segments)) {
      translatedSegments = parsed.segments;
    } else if (parsed?.subtitles && Array.isArray(parsed.subtitles)) {
      translatedSegments = parsed.subtitles;
    }

    res.json({ segments: translatedSegments.length > 0 ? translatedSegments : segments });
  } catch (err: any) {
    console.error('Translation error:', err);
    res.status(500).json({ error: err.message || 'Translation failed' });
  }
});

// 5. AI Spell Check and Linguistic Error Correction (STRICT NO-REPHRASE)
app.post('/api/gemini/grammar-fix', async (req: Request, res: Response) => {
  try {
    const { segments } = req.body;
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      return res.status(400).json({ error: 'Segments array is required' });
    }

    const prompt = `You are a strict Arabic and multilingual orthographic/spelling checker.
ABSOLUTE MANDATORY RULES:
1. "لو مفهمش يسيبه زي ماهو": If a word or phrase is unclear, slang, a specific persona/brand name, or you have ANY doubt, LEAVE IT 100% UNTOUCHED.
2. DO NOT REPHRASE OR PARAPHRASE. DO NOT CHANGE VOCABULARY. DO NOT ALTER MEANING AT ALL.
3. Every single word in the output must correspond 1:1 to the exact spoken word. Do not substitute words with formal synonyms.
4. Only fix direct orthographic/letter errors:
   - Missing or incorrect dots
   - Hamza positioning: (أ / إ / ا / ء)
   - Ta' marbuta: (ة vs ه, e.g. "ورحمه" -> "ورحمة")
   - Ya' / Alif Maqsura: (ي vs ى)
   - Colloquial phonetic typo fix: e.g. "عاملين اي" -> "عاملين إيه؟"
5. Keep the exact same number of segments, IDs, and timestamps.
6. In "corrections", list any changes you made with segmentId, original, corrected, and reason.

Input segments:
${JSON.stringify(
  segments.map((s: any) => ({ id: s.id, text: s.text })),
  null,
  2
)}

Return strict JSON matching this schema:
{
  "segments": [
    {
      "id": 1,
      "text": "النص المصحح بدون أي تغيير في المعنى"
    }
  ],
  "corrections": [
    {
      "segmentId": 1,
      "original": "ورحمه",
      "corrected": "ورحمة",
      "reason": "تصحيح التاء المربوطة"
    }
  ]
}`;

    const response = await generateGeminiContentSafe({
      preferredModel: 'gemini-flash-latest',
      customApiKey: getReqGeminiKey(req),
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsed: any = {};
    try {
      parsed = JSON.parse(responseText);
    } catch {
      const match = responseText.match(/\{[\s\S]*\}/);
      if (match) {
        parsed = JSON.parse(match[0]);
      }
    }

    const correctedMap = new Map<number, string>();
    for (const item of (parsed.segments || [])) {
      if (item && item.id !== undefined && item.text) {
        correctedMap.set(item.id, item.text);
      }
    }

    const updatedSegments = segments.map((seg: any) => {
      const originalText = seg.text;
      const candidateText = correctedMap.get(seg.id);
      if (!candidateText) return seg;

      // STRICT VALIDATION: If the AI altered word count significantly or rephrased words, REJECT and keep original!
      const origWords = originalText.trim().split(/\s+/).filter(Boolean);
      const candWords = candidateText.trim().split(/\s+/).filter(Boolean);
      if (Math.abs(origWords.length - candWords.length) > 1) {
        // AI likely rephrased or changed meaning -> Discard to preserve user's exact words
        return seg;
      }

      return {
        ...seg,
        text: candidateText,
      };
    });

    res.json({
      segments: updatedSegments,
      corrections: parsed.corrections || [],
    });
  } catch (err: any) {
    console.log('Grammar fix: smoothly applying built-in orthography fallback.');
    // Graceful fallback: run local orthography corrections so user request succeeds even during 503!
    const localCorrections: any[] = [];
    const localUpdated = (req.body?.segments || []).map((seg: any) => {
      let t = seg.text || '';
      // Fix ta' marbuta in common words
      t = t.replace(/\bورحمه\b/g, 'ورحمة');
      t = t.replace(/\bمقدمه\b/g, 'مقدمة');
      t = t.replace(/\bقناه\b/g, 'قناة');
      t = t.replace(/\bحياه\b/g, 'حياة');
      t = t.replace(/\bان\s+شاء\s+الله\b/g, 'إن شاء الله');
      t = t.replace(/(^|\s)علي(\s+(هذا|هذه|كل|أن|ما|الفيديو))/g, '$1على$2');
      t = t.replace(/(^|\s)الي(\s|$)/g, '$1إلى$2');
      t = t.replace(/\s+([،,؛;:!؟?.])/g, '$1');
      return { ...seg, text: t.trim() };
    });

    res.json({
      segments: localUpdated,
      corrections: localCorrections,
      notice: 'تم تطبيق التدقيق الإملائي السريع بنجاح (المحرك الداخلي)',
    });
  }
});

// 6. Smart Sentence Restructuring and Idiom Grouping (تجميع الكلمات وتقسيم الجمل الذكي المتماسك)
app.post('/api/gemini/smart-resegment', async (req: Request, res: Response) => {
  try {
    const { segments, targetWordsPerSegment = 5 } = req.body;
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      return res.status(400).json({ error: 'Segments array is required' });
    }

    const prompt = `You are an elite short-form video editor (TikTok, Reels, Shorts).
The current speech-to-text segments have awkward broken fragments or split phrases.
For example, greetings and idioms are chopped unnaturally:
"السلام عليكم ورحمه" followed by "الله وبركاته" instead of a complete cohesive unit: "السلام عليكم ورحمة الله وبركاته".
Or sentences are broken mid-phrase creating too many stacked lines.

YOUR TASK:
Re-group and re-segment the speech into natural, semantically complete, readable video captions:
1. NEVER cut a greeting or idiom in half (e.g. keep "السلام عليكم ورحمة الله وبركاته" together in one clean subtitle).
2. Group words into complete thoughts (around 3 to 7 words per segment).
3. Do NOT show huge blocks of text; each segment must fit comfortably on 1 or at most 2 balanced lines.
4. Calculate the start and end timestamps logically from the input segments. The total speech timeline must be preserved accurately.
5. Identify 1 to 2 power keywords for each new segment to highlight.

Input segments with original timestamps:
${JSON.stringify(
  segments.map((s: any) => ({
    id: s.id,
    start: s.start,
    end: s.end,
    text: s.text,
  })),
  null,
  2
)}

Return strict JSON array of reformed segments:
[
  {
    "id": 1,
    "start": 0.0,
    "end": 2.8,
    "text": "السلام عليكم ورحمة الله وبركاته",
    "keywords": ["السلام", "وبركاته"]
  }
]`;

    const response = await generateGeminiContentSafe({
      preferredModel: 'gemini-flash-latest',
      customApiKey: getReqGeminiKey(req),
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '[]';
    let newSegments: any[] = [];
    try {
      newSegments = JSON.parse(responseText);
    } catch {
      const match = responseText.match(/\[[\s\S]*\]/);
      if (match) {
        newSegments = JSON.parse(match[0]);
      }
    }

    // Format new segments cleanly
    const formatted = newSegments.map((seg: any, idx: number) => ({
      id: idx + 1,
      start: Number(Number(seg.start).toFixed(2)),
      end: Number(Number(seg.end).toFixed(2)),
      text: (seg.text || '').trim(),
      highlightKeywords: (seg.keywords || []).map((k: string) => ({
        word: k,
        category: 'yellow',
      })),
    }));

    res.json({ segments: formatted.length > 0 ? formatted : segments });
  } catch (err: any) {
    console.log('Smart resegment: smoothly applying built-in grouping fallback.');
    // Local fallback: combine broken greetings and merge tiny fragments
    const inputSegs = req.body?.segments || [];
    const localGrouped: any[] = [];
    let i = 0;
    while (i < inputSegs.length) {
      const cur = inputSegs[i];
      const next = i + 1 < inputSegs.length ? inputSegs[i + 1] : null;
      if (
        next &&
        /السلام\s+عليكم(\s+ورحم[ةه])?$/i.test((cur.text || '').trim()) &&
        /^(ورحم[ةه]\s+)?الله\s+وبركاته/i.test((next.text || '').trim())
      ) {
        localGrouped.push({
          id: localGrouped.length + 1,
          start: cur.start,
          end: next.end,
          text: 'السلام عليكم ورحمة الله وبركاته',
          highlightKeywords: [
            { word: 'السلام', category: 'yellow' },
            { word: 'وبركاته', category: 'yellow' },
          ],
        });
        i += 2;
        continue;
      }
      localGrouped.push({ ...cur, id: localGrouped.length + 1 });
      i++;
    }

    res.json({
      segments: localGrouped,
      notice: 'تم تنسيق وتجميع الجمل بنجاح (المحرك الذكي الداخلي)',
    });
  }
});

// 7. Extract Key Highlights Only (Weapons, Diseases, People, Countries, Numbers, Science, 1-3 words, 3.5s duration)
// طلب المستخدم الصريح: "كتابات للاشياء المهمه بس: اسم سلاح، اسم مرض، اسماء اشخاص، دول، ارقام... متزدش عن 3 كلمات وتسيب 3 او 4 ثواني بعد ما يقول بس يظهر اول ما يقول الكلمه"
app.post('/api/gemini/extract-highlights', async (req: Request, res: Response) => {
  try {
    const { segments } = req.body;
    if (!segments || !Array.isArray(segments) || segments.length === 0) {
      return res.status(400).json({ error: 'قائمة الكابشن مطلوبة' });
    }

    const prompt = `You are an expert viral video subtitle editor (like Alex Hormozi & MrBeast editors).
The user requested: "ONLY show subtitles for the CRITICAL KEY HIGHLIGHTS. DO NOT keep continuous text on screen throughout the video. Extract focal nouns and entities like weapon names, disease/medical terms, person names, countries, numbers/measurements, technology, etc."

You must extract ONLY:
1. Weapons, military gear, vehicles, defense systems (e.g. "كلاشينكوف", "صاروخ كينجال", "دبابة أبرامز", "طائرة F-35", "مسيرة درون", "منظومة باتريوت")
2. Diseases, viruses, health, medical conditions, medications, vaccines (e.g. "مرض السكري", "فيروس كورونا", "مرض السرطان", "لقاح كوفيد", "ألزهايمر", "أزمة قلبية")
3. Names of people, leaders, historical figures, scientists (e.g. "أينشتاين", "ستيف جوبز", "صلاح الدين", "إيلون ماسك", "دكتور أحمد زويل")
4. Science, tech, inventions, space (e.g. "الذكاء الاصطناعي", "تلسكوب جيمس ويب", "مفاعل نووي", "روبوت")
5. Numbers, measurements, statistics, prices, sizes, speeds, dates (e.g. "100 مليون دولار", "500 كم/س", "50%", "3000 متر", "سنة 2026")
6. Countries, cities, landmarks, straits (e.g. "مصر", "الولايات المتحدة", "مضيق هرمز", "دبي", "باريس")
7. Important core subject nouns (strictly 1 to 3 words max).

Rules:
- Length: Strictly 1 to 3 words maximum per highlight! Never output full sentences.
- Timing: "start" MUST be the exact onset or 0.2s before the word is pronounced, NEVER late or delayed. The word MUST be visible immediately the split-second speech begins!
- "end" MUST be (start + 3.5) seconds, so it stays on screen for 3 to 4 seconds, then cleanly disappears!
- Ensure highlights do not overlap.
- Discard all ordinary filler sentences. The rest of the video must have NO captions!

Return JSON ONLY:
{
  "highlights": [
    {
      "id": 1,
      "start": 1.2,
      "end": 4.7,
      "text": "كلاشينكوف AK-47",
      "category": "red",
      "highlightKeywords": [{"word": "كلاشينكوف AK-47", "category": "red"}]
    }
  ]
}

Input:
${JSON.stringify(
  segments.slice(0, 80).map((s: any) => ({
    id: s.id,
    start: s.start,
    end: s.end,
    text: s.text,
  }))
)}`;

    let formatted: any[] = [];
    try {
      const response = await generateGeminiContentSafe({
        contents: prompt,
        customApiKey: getReqGeminiKey(req),
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
        preferredModel: 'gemini-flash-latest',
      });

      const responseText = response.text || '{}';
      let parsed: any;
      try {
        parsed = JSON.parse(responseText);
      } catch {
        const match = responseText.match(/\{[\s\S]*\}/);
        parsed = match ? JSON.parse(match[0]) : {};
      }

      if (parsed.highlights && Array.isArray(parsed.highlights) && parsed.highlights.length > 0) {
        formatted = parsed.highlights.map((h: any, idx: number) => ({
          id: idx + 1,
          start: Number(Number(h.start).toFixed(2)),
          end: Number(Number(h.end).toFixed(2)),
          text: (h.text || '').trim(),
          highlightKeywords: h.highlightKeywords || [
            { word: (h.text || '').trim(), category: h.category || 'yellow' },
          ],
        }));
      }
    } catch (apiErr) {
      console.log('Gemini extract-highlights: seamlessly utilizing smart built-in engine.');
    }

    // Reliable fallback if model didn't return highlights
    if (formatted.length === 0) {
      // Use internal rule & semantic extractor on server
      const weaponsPattern =
        /\b(كلاشينكوف|بندقية|مسدس|رشاش|آر\s*بي\s*جي|RPG|صاروخ|صواريخ|كينجال|إسكندر|هيمارس|HIMARS|باتريوت|مسيرة|مسيرات|درون|طائرة|إف[- ]?16|F[- ]?16|إف[- ]?35|F[- ]?35|سوخوي|ميج|دبابة|دبابات|أبرامز|تي[- ]?90|بارود|نووي|سلاح|قنبلة|لغم|مدفع|راجمة|ذخيرة|فرقاطة|غواصة|طوربيد|كروز|باليستي|دفاع\s*جوي|رادار|كاتيوشا|قناصة|هاون|مدرعة)\b/i;
      const medicalPattern =
        /\b(سرطان|السرطان|سكري|السكري|مرض\s*السكري|كورونا|كوفيد|إنفلونزا|كوليرا|طاعون|ألزهايمر|الزهايمر|جلطة|سكتة\s*قلبية|أزمة\s*قلبية|فيروس|بكتيريا|لقاح|علاج|دواء|ضغط\s*الدم|عدوى|وباء|متلازمة|شلل|ورم|جراحة|استئصال|فشل\s*كلوي|كبد|رئة|مناعة|نزيف|كسور|أشعة|مضاد\s*حيوي|فيتامين|هرمون|جينات|DNA|مرض)\b/i;
      const techPattern =
        /\b(ذكاء\s*اصطناعي|الذكاء\s*الاصطناعي|روبوت|تلسكوب|جيمس\s*ويب|قمر\s*صناعي|ناسا|فضاء|كوانتم|فيزياء|ذرة|مفاعل\s*نووي|بطارية|ليزر|شريحة|معالج|إنترنت|خوارزمية|تطبيق|هاتف|آيفون|أندرويد|محرك|سيارة\s*كهربائية|أبل|مايكروسوفت|جوجل|ChatGPT)\b/i;
      const numberPattern =
        /\b(\d+[\d,.]*\s*(?:%|٪|مليون|مليار|ترليون|ألف|دولار|جنيه|ريال|درهم|يورو|سم|متر|كم|كم\/س|طن|كجم|كيلو|سنة|سنوات|عام|ساعة|ساعات|دقيقة|دقائق|ضعف|درجة)?|\b\d+\b)\b/i;
      const countryPattern =
        /\b(مصر|السعودية|الإمارات|دبي|الرياض|القاهرة|قطر|الكويت|البحرين|عمان|الأردن|فلسطين|القدس|غزة|لبنان|سوريا|العراق|اليمن|المغرب|الجزائر|تونس|ليبيا|السودان|أمريكا|بريطانيا|لندن|فرنسا|باريس|ألمانيا|روسيا|الصين|اليابان|تركيا|كندا|أستراليا|إيطاليا|إسبانيا)\b/i;
      const peoplePattern =
        /\b(أينشتاين|نيوتن|تسلا|أديسون|ستيف\s*جوبز|إيلون\s*ماسك|بيل\s*جيتس|مارك\s*زوكربيرج|هتلر|نابليون|صلاح\s*الدين|زويل|مجدي\s*يعقوب|محمد\s*صلاح|ميسي|رونالدو|مستر\s*بيست|الدكتور|الرئيس|الملك|الشيخ|العالم|القائد)\b/i;

      for (const seg of segments) {
        const text = (seg.text || '').trim();
        const words = text.split(/\s+/).filter(Boolean);
        if (words.length === 0) continue;

        let phrase = '';
        let cat: 'yellow' | 'red' | 'cyan' | 'green' = 'yellow';

        const wMatch = text.match(weaponsPattern);
        if (wMatch) {
          phrase = wMatch[0];
          cat = 'red';
        } else {
          const mMatch = text.match(medicalPattern);
          if (mMatch) {
            phrase = mMatch[0];
            cat = 'red';
          } else {
            const tMatch = text.match(techPattern);
            if (tMatch) {
              phrase = tMatch[0];
              cat = 'cyan';
            } else {
              const nMatch = text.match(numberPattern);
              if (nMatch && nMatch[0].length > 1) {
                phrase = nMatch[0];
                cat = 'yellow';
              } else {
                const pMatch = text.match(peoplePattern);
                if (pMatch) {
                  phrase = pMatch[0];
                  cat = 'yellow';
                } else {
                  const cMatch = text.match(countryPattern);
                  if (cMatch) {
                    phrase = cMatch[0];
                    cat = 'green';
                  }
                }
              }
            }
          }
        }

        // Semantic fallback if no specific list item matched
        if (!phrase) {
          const candidate = words.find(
            (w: string) => w.length >= 4 && (w.startsWith('ال') || /^[A-Za-z0-9_-]+$/.test(w))
          );
          if (candidate) {
            phrase = candidate;
            cat = 'yellow';
          }
        }

        if (phrase) {
          const cleanWords = phrase.trim().split(/\s+/).slice(0, 3).join(' ');
          const wordIdx = words.findIndex((w: string) => w.includes(cleanWords.split(' ')[0]));
          const ratio = wordIdx >= 0 && words.length > 0 ? wordIdx / words.length : 0;
          const hStart = Math.max(seg.start, Number((seg.start + (seg.end - seg.start) * ratio - 0.25).toFixed(2)));
          const hEnd = Number((hStart + 3.5).toFixed(2));

          const prev = formatted[formatted.length - 1];
          if (prev && hStart < prev.end) {
            prev.end = Number(Math.max(prev.start + 1.2, hStart - 0.1).toFixed(2));
          }

          formatted.push({
            id: formatted.length + 1,
            start: hStart,
            end: hEnd,
            text: cleanWords,
            highlightKeywords: [{ word: cleanWords, category: cat }],
          });
        }
      }
    }

    res.json({
      segments: formatted.length > 0 ? formatted : segments,
      notice: 'تم استخراج الكلمات والمصطلحات المفتاحية بنجاح',
    });
  } catch (err: any) {
    console.error('Extract-highlights error:', err);
    res.json({
      segments: req.body?.segments || [],
      notice: 'تم الإبقاء على المقاطع الأصلية',
    });
  }
});

// Stream sample media with Range support and full CORS headers
function streamMediaFile(req: Request, res: Response, filePath: string, mimeType: string) {
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File not found');
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Accept-Ranges', 'bytes');

  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = end - start + 1;
    const file = fs.createReadStream(filePath, { start, end });
    const head = {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': mimeType,
    };
    res.writeHead(206, head);
    file.pipe(res);
  } else {
    const head = {
      'Content-Length': fileSize,
      'Content-Type': mimeType,
    };
    res.writeHead(200, head);
    fs.createReadStream(filePath).pipe(res);
  }
}

// Helper to parse frame rate from string (e.g. '25/1', '30000/1001', '60')
function parseFpsString(str: string | undefined): number {
  if (!str) return 30;
  const parts = str.split('/');
  if (parts.length === 2) {
    const num = parseFloat(parts[0]);
    const den = parseFloat(parts[1]);
    if (den > 0 && num > 0) {
      return Math.round((num / den) * 100) / 100;
    }
  }
  const val = parseFloat(str);
  return isNaN(val) || val <= 0 ? 30 : val;
}

// 8. Video Metadata Probe via FFprobe
app.all('/api/video/probe', async (req: Request, res: Response) => {
  let tempFilePath: string | null = null;
  try {
    let targetPath: string = '';
    const queryPath = (req.query.path as string) || '';
    const bodyPath = (req.body?.path as string) || (req.body?.filePath as string) || '';
    const videoBase64 = req.body?.videoBase64 as string | undefined;

    if (queryPath || bodyPath) {
      const candidate = queryPath || bodyPath;
      if (candidate.startsWith('public/')) {
        targetPath = path.resolve(__dirname, candidate);
      } else if (candidate.startsWith('/')) {
        targetPath = candidate;
      } else {
        targetPath = path.resolve(__dirname, 'public', candidate);
      }
    } else if (videoBase64) {
      const cleanBase64 = videoBase64.replace(/^data:[^;]+;base64,/, '');
      const buffer = Buffer.from(cleanBase64, 'base64');
      const tempId = `probe_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.mp4`;
      tempFilePath = path.resolve('/tmp', tempId);
      fs.writeFileSync(tempFilePath, buffer);
      targetPath = tempFilePath;
    } else {
      // Default to public/sample.mp4 if no input specified
      targetPath = path.resolve(__dirname, 'public', 'sample.mp4');
    }

    if (!fs.existsSync(targetPath)) {
      return res.status(404).json({ error: 'Video file not found for probing' });
    }

    const { stdout } = await execFileAsync('ffprobe', [
      '-v',
      'quiet',
      '-print_format',
      'json',
      '-show_format',
      '-show_streams',
      targetPath,
    ]);

    const parsed = JSON.parse(stdout);
    const videoStream = (parsed.streams || []).find((s: any) => s.codec_type === 'video');
    const audioStream = (parsed.streams || []).find((s: any) => s.codec_type === 'audio');

    const width = videoStream?.width || 0;
    const height = videoStream?.height || 0;
    const fps = parseFpsString(videoStream?.r_frame_rate || videoStream?.avg_frame_rate);
    const duration = parseFloat(parsed.format?.duration || videoStream?.duration || '0');
    const bitrate = parseInt(parsed.format?.bit_rate || videoStream?.bit_rate || '0', 10);
    const pixFmt = videoStream?.pix_fmt || 'yuv420p';
    const videoCodec = videoStream?.codec_name || 'h264';
    const displayAspectRatio = videoStream?.display_aspect_ratio || (width && height ? `${width}:${height}` : '16:9');

    res.json({
      success: true,
      width,
      height,
      fps,
      duration,
      bitrate,
      pixFmt,
      videoCodec,
      displayAspectRatio,
      audio: audioStream
        ? {
            codec: audioStream.codec_name,
            sampleRate: parseInt(audioStream.sample_rate || '44100', 10),
            channels: parseInt(audioStream.channels || '2', 10),
            bitrate: parseInt(audioStream.bit_rate || '128000', 10),
          }
        : null,
    });
  } catch (err: any) {
    console.error('[FFprobe API Error]:', err?.message || err);
    res.status(500).json({
      error: 'Failed to probe video with FFprobe',
      details: err?.message || String(err),
    });
  } finally {
    if (tempFilePath && fs.existsSync(tempFilePath)) {
      try {
        fs.unlinkSync(tempFilePath);
      } catch {}
    }
  }
});

// 9. High-Fidelity Studio Video Render via FFmpeg (CRF 18-20, libx264, yuv420p, zero dropped frames)
app.post('/api/video/render-ffmpeg', async (req: Request, res: Response) => {
  const tempFilesToClean: string[] = [];
  try {
    const {
      videoPath,
      videoBase64,
      srtContent,
      startTime = 0,
      endTime,
      crf = 19,
      preset = 'veryfast',
      exportBackground = 'video',
    } = req.body;

    let inputPath = '';
    if (videoPath) {
      if (videoPath.startsWith('public/')) {
        inputPath = path.resolve(__dirname, videoPath);
      } else {
        inputPath = path.resolve(__dirname, 'public', videoPath);
      }
    } else if (videoBase64) {
      const cleanBase64 = videoBase64.replace(/^data:[^;]+;base64,/, '');
      const buffer = Buffer.from(cleanBase64, 'base64');
      const tempIn = path.resolve('/tmp', `ff_in_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.mp4`);
      fs.writeFileSync(tempIn, buffer);
      tempFilesToClean.push(tempIn);
      inputPath = tempIn;
    } else {
      inputPath = path.resolve(__dirname, 'public', 'sample.mp4');
    }

    if (!fs.existsSync(inputPath)) {
      return res.status(404).json({ error: 'Input video not found' });
    }

    // Write SRT file
    const srtTemp = path.resolve('/tmp', `ff_sub_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.srt`);
    fs.writeFileSync(srtTemp, srtContent || '');
    tempFilesToClean.push(srtTemp);

    const outputTemp = path.resolve('/tmp', `ff_out_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.mp4`);
    tempFilesToClean.push(outputTemp);

    const safeCrf = Math.max(16, Math.min(28, Number(crf) || 19));
    const safePreset = ['ultrafast', 'superfast', 'veryfast', 'faster', 'fast', 'medium'].includes(preset)
      ? preset
      : 'veryfast';

    const args: string[] = ['-y'];

    if (startTime > 0) {
      args.push('-ss', String(startTime));
    }
    if (endTime && endTime > startTime) {
      args.push('-to', String(endTime));
    }

    args.push('-i', inputPath);

    // Escape SRT path for libass subtitles filter
    const escapedSrt = srtTemp.replace(/\\/g, '/').replace(/:/g, '\\:');
    const subFilter = `subtitles='${escapedSrt}':force_style='Fontname=Arial,Fontsize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=2,Shadow=1,Alignment=2,MarginV=35'`;

    if (exportBackground === 'greenscreen') {
      args.push(
        '-filter_complex',
        `color=c=0x00FF00:s=1080x1920:r=30[bg];[bg]${subFilter}[vout]`,
        '-map',
        '[vout]',
        '-map',
        '0:a?'
      );
    } else if (exportBackground === 'black') {
      args.push(
        '-filter_complex',
        `color=c=0x000000:s=1080x1920:r=30[bg];[bg]${subFilter}[vout]`,
        '-map',
        '[vout]',
        '-map',
        '0:a?'
      );
    } else {
      args.push('-vf', subFilter);
    }

    args.push(
      '-c:v',
      'libx264',
      '-crf',
      String(safeCrf),
      '-preset',
      safePreset,
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-b:a',
      '192k',
      '-movflags',
      '+faststart',
      outputTemp
    );

    await execFileAsync(process.env.FFMPEG_PATH || 'ffmpeg', args);

    if (!fs.existsSync(outputTemp)) {
      throw new Error('FFmpeg completed but output file was not created');
    }

    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', 'attachment; filename="submagic_rendered.mp4"');
    const readStream = fs.createReadStream(outputTemp);
    readStream.pipe(res);
    readStream.on('close', () => {
      // Clean up after streaming finishes
      for (const f of tempFilesToClean) {
        try {
          if (fs.existsSync(f)) fs.unlinkSync(f);
        } catch {}
      }
    });
  } catch (err: any) {
    console.error('[FFmpeg Render Error]:', err?.message || err);
    for (const f of tempFilesToClean) {
      try {
        if (fs.existsSync(f)) fs.unlinkSync(f);
      } catch {}
    }
    res.status(500).json({
      error: 'FFmpeg render failed',
      details: err?.message || String(err),
    });
  }
});

// Explicit endpoints for sample video and audio to guarantee reliable media loading with Range support
app.get('/sample.mp4', (req: Request, res: Response) => {
  streamMediaFile(req, res, path.resolve(__dirname, 'public', 'sample.mp4'), 'video/mp4');
});

app.get('/sample.mp3', (req: Request, res: Response) => {
  streamMediaFile(req, res, path.resolve(__dirname, 'public', 'sample.mp3'), 'audio/mp3');
});

// Serve public assets
app.use(express.static(path.resolve(__dirname, 'public')));

// Explicit JSON 404 handler for all /api/* routes (prevents Vite SPA from returning index.html)
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({
    error: `API route ${req.method} ${req.path} not found`,
    code: 'ROUTE_NOT_FOUND',
  });
});

// Global Error Handler: Guarantees that any server error returns JSON instead of Express default HTML page
app.use((err: any, _req: Request, res: Response, _next: any) => {
  console.error('[API Server Error]:', err?.message || err);
  const status = typeof err.status === 'number' ? err.status : typeof err.statusCode === 'number' ? err.statusCode : 500;
  res.status(status).json({
    error: err?.message || 'حدث خطأ في معالجة الطلب بالخادم',
    code: err?.code || 'SERVER_ERROR',
  });
});

// Start server with Vite middleware in development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`SubMagic AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
