import React, { useState } from 'react';
import {
  FolderOpen,
  FileText,
  Sliders,
  Palette,
  Film,
  Music,
  FileCheck,
  Clock,
  Scissors,
  CheckCircle2,
  Sparkles,
  Layers,
  Upload,
} from 'lucide-react';
import {
  SubtitleSegment,
  SubtitleStylePreset,
  CaptionVisibilityRange,
} from '../types';
import { CaptionsEditor } from './CaptionsEditor';
import { PresetSelector } from './PresetSelector';
import { StyleControls } from './StyleControls';
import { formatTimeDisplay } from '../utils/srt';
import { Language, translations } from '../utils/translations';

interface ProjectInspectorProps {
  lang?: Language;
  segments: SubtitleSegment[];
  selectedSegmentId: number | null;
  currentTime: number;
  duration: number;
  activePreset: SubtitleStylePreset;
  videoSrc: string | null;
  videoFile: File | null;
  showCustomizer: boolean;
  captionVisibilityRange: CaptionVisibilityRange;
  isGrammarEnabled: boolean;
  isTranscribing: boolean;
  isProcessingAI: boolean;
  groqConnected: boolean;
  onUpdateSegments: (segments: SubtitleSegment[]) => void;
  onSeek: (time: number) => void;
  onSelectSegment: (id: number | null) => void;
  onSelectPreset: (preset: SubtitleStylePreset) => void;
  onToggleCustomizer: () => void;
  onGenerateGroq: () => void;
  onGenerateGemini: (translateTo?: string) => void;
  onDetectSmartKeywords: () => void;
  onTranslate: (lang: string) => void;
  onFixGrammar: () => void;
  onToggleGrammar: () => void;
  onSmartResegment: () => void;
  onShiftAllTime: (delta: number) => void;
  onExtractKeyHighlights: () => void;
  onTrimSilence: () => void;
  onUpdateCaptionVisibilityRange: (range: CaptionVisibilityRange) => void;
  onLoadSample: () => void;
  onFileUpload: (file: File) => void;
  isKeywordsOnlyMode?: boolean;
  onToggleKeywordsOnlyMode?: () => void;
}

export const ProjectInspector: React.FC<ProjectInspectorProps> = ({
  lang = 'en',
  segments,
  selectedSegmentId,
  currentTime,
  duration,
  activePreset,
  videoSrc,
  videoFile,
  showCustomizer,
  captionVisibilityRange,
  isGrammarEnabled,
  isTranscribing,
  isProcessingAI,
  groqConnected,
  onUpdateSegments,
  onSeek,
  onSelectSegment,
  onSelectPreset,
  onToggleCustomizer,
  onGenerateGroq,
  onGenerateGemini,
  onDetectSmartKeywords,
  onTranslate,
  onFixGrammar,
  onToggleGrammar,
  onSmartResegment,
  onShiftAllTime,
  onExtractKeyHighlights,
  onTrimSilence,
  onUpdateCaptionVisibilityRange,
  onLoadSample,
  onFileUpload,
  isKeywordsOnlyMode = false,
  onToggleKeywordsOnlyMode,
}) => {
  const t = translations[lang];
  const [activeTab, setActiveTab] = useState<'bin' | 'captions' | 'graphics' | 'effects'>('captions');
  const fileInputRef = React.useRef<HTMLInputElement | null>(null);

  return (
    <div className="flex flex-col h-full bg-[#FAF9F7] border-l rtl:border-l-0 rtl:border-r border-[#E5E0D8] select-none text-[#1C1C1E] overflow-hidden">
      {/* Premiere Pro Tabs Strip */}
      <div className="flex items-center justify-between px-3 bg-[#FAF9F7] border-b border-[#E5E0D8] text-xs shrink-0 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1">
          {/* Project Bin Tab */}
          <button
            onClick={() => setActiveTab('bin')}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-semibold transition text-xs ${
              activeTab === 'bin'
                ? 'border-[#E0532B] text-[#1C1C1E] font-bold'
                : 'border-transparent text-[#78716C] hover:text-[#1C1C1E]'
            }`}
          >
            <span>{t.projectBin}</span>
          </button>

          {/* Captions Text Editor Tab */}
          <button
            onClick={() => setActiveTab('captions')}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-semibold transition text-xs ${
              activeTab === 'captions'
                ? 'border-[#E0532B] text-[#1C1C1E] font-bold'
                : 'border-transparent text-[#78716C] hover:text-[#1C1C1E]'
            }`}
          >
            <span>{t.captionsSrt}</span>
            {segments.length > 0 && (
              <span className="bg-[#FDF0EB] text-[#C2410C] text-[10px] px-1.5 py-0.2 rounded-full font-mono border border-[#FED7AA]">
                {segments.length}
              </span>
            )}
          </button>

          {/* Essential Graphics (Presets) Tab */}
          <button
            onClick={() => setActiveTab('graphics')}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-semibold transition text-xs ${
              activeTab === 'graphics'
                ? 'border-[#E0532B] text-[#1C1C1E] font-bold'
                : 'border-transparent text-[#78716C] hover:text-[#1C1C1E]'
            }`}
          >
            <span>{t.essentialGraphics}</span>
          </button>

          {/* Effect Controls Tab */}
          <button
            onClick={() => setActiveTab('effects')}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-semibold transition text-xs ${
              activeTab === 'effects'
                ? 'border-[#E0532B] text-[#1C1C1E] font-bold'
                : 'border-transparent text-[#78716C] hover:text-[#1C1C1E]'
            }`}
          >
            <span>{t.effectControls}</span>
          </button>
        </div>
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-hidden relative bg-[#FAF9F7]">
        {/* Tab 1: Project Bin (Media Assets) */}
        {activeTab === 'bin' && (
          <div className="h-full overflow-y-auto p-4 space-y-4 bg-[#FAF9F7]">
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  onFileUpload(e.target.files[0]);
                }
              }}
            />

            <div className="flex items-center justify-between pb-2 border-b border-[#E5E0D8]">
              <span className="text-xs font-bold text-[#1C1C1E] font-['Cairo',sans-serif]">
                محتويات المشروع والملفات المرفوعة (Project Assets)
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-xl bg-[#E0532B] hover:bg-[#C9431E] text-xs font-bold text-white flex items-center gap-1.5 transition shadow-2xs active:scale-95"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>استيراد ميديا (فيديو / صوت)</span>
                </button>
              </div>
            </div>

            {/* Assets Grid matching Premiere Pro Bin */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {/* Asset 1: Video File */}
              <div className="p-3 bg-white border border-[#E5E0D8] hover:border-[#FED7AA] rounded-2xl flex flex-col justify-between group transition shadow-2xs">
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-2 bg-blue-50 text-blue-600 rounded-xl border border-blue-200">
                    <Film className="w-5 h-5" />
                  </div>
                  <div className="overflow-hidden">
                    <span className="text-xs font-bold text-[#1C1C1E] block truncate">
                      {videoFile?.name || 'Master_Sequence.mp4'}
                    </span>
                    <span className="text-[10px] text-[#78716C] font-mono" dir="ltr">
                      {formatTimeDisplay(duration)}
                    </span>
                  </div>
                </div>
                <div className="text-[10px] text-[#78716C] flex items-center justify-between pt-2 border-t border-[#F3EFEA]">
                  <span>فيديو رئيسي (V1)</span>
                  <span className="text-blue-600 font-bold">1080p</span>
                </div>
              </div>

              {/* Asset 2: Extracted Audio */}
              <div className="p-3 bg-white border border-[#E5E0D8] hover:border-[#FED7AA] rounded-2xl flex flex-col justify-between group transition shadow-2xs">
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-2 bg-teal-50 text-teal-600 rounded-xl border border-teal-200">
                    <Music className="w-5 h-5" />
                  </div>
                  <div className="overflow-hidden">
                    <span className="text-xs font-bold text-[#1C1C1E] block truncate">
                      Audio_Dialogue.wav
                    </span>
                    <span className="text-[10px] text-[#78716C] font-mono" dir="ltr">
                      48kHz Stereo
                    </span>
                  </div>
                </div>
                <div className="text-[10px] text-[#78716C] flex items-center justify-between pt-2 border-t border-[#F3EFEA]">
                  <span>صوت الحوار (A1)</span>
                  <span className="text-teal-600 font-bold">Active</span>
                </div>
              </div>

              {/* Asset 3: Subtitles SRT */}
              <div
                onClick={() => setActiveTab('captions')}
                className="p-3 bg-white border border-[#E5E0D8] hover:border-[#DDD6FE] rounded-2xl flex flex-col justify-between group transition cursor-pointer shadow-2xs"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-2 bg-purple-50 text-purple-600 rounded-xl border border-purple-200">
                    <FileCheck className="w-5 h-5" />
                  </div>
                  <div className="overflow-hidden">
                    <span className="text-xs font-bold text-[#1C1C1E] block truncate">
                      Subtitles_Sync.srt
                    </span>
                    <span className="text-[10px] text-purple-600 font-mono">
                      {segments.length} مقاطع
                    </span>
                  </div>
                </div>
                <div className="text-[10px] text-[#78716C] flex items-center justify-between pt-2 border-t border-[#F3EFEA]">
                  <span>كابشن متزامن (CC)</span>
                  <span className="text-purple-600 font-bold">عرض المحرر ↗</span>
                </div>
              </div>

              {/* Asset 4: Active Preset */}
              <div
                onClick={() => setActiveTab('graphics')}
                className="p-3 bg-white border border-[#E5E0D8] hover:border-[#FED7AA] rounded-2xl flex flex-col justify-between group transition cursor-pointer shadow-2xs"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-2 bg-orange-50 text-orange-600 rounded-xl border border-orange-200">
                    <Palette className="w-5 h-5" />
                  </div>
                  <div className="overflow-hidden">
                    <span className="text-xs font-bold text-[#1C1C1E] block truncate">
                      {activePreset.nameAr}
                    </span>
                    <span className="text-[10px] text-orange-600 truncate block">
                      {activePreset.fontFamily}
                    </span>
                  </div>
                </div>
                <div className="text-[10px] text-[#78716C] flex items-center justify-between pt-2 border-t border-[#F3EFEA]">
                  <span>قالب الستايل</span>
                  <span className="text-[#E0532B] font-bold">تغيير ↗</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Captions Editor (Full Rich Subtitle Suite) */}
        {activeTab === 'captions' && (
          <div className="h-full overflow-hidden bg-[#FAF9F7]">
            <CaptionsEditor
              lang={lang}
              segments={segments}
              currentTime={currentTime}
              duration={duration}
              activePreset={activePreset}
              onUpdateSegments={onUpdateSegments}
              onSeek={onSeek}
              onGenerateGroq={onGenerateGroq}
              onGenerateGemini={onGenerateGemini}
              onDetectSmartKeywords={onDetectSmartKeywords}
              onTranslate={onTranslate}
              onFixGrammar={onFixGrammar}
              onSmartResegment={onSmartResegment}
              onShiftAllTime={onShiftAllTime}
              onExtractKeyHighlights={onExtractKeyHighlights}
              isTranscribing={isTranscribing}
              isProcessingAI={isProcessingAI}
              groqConnected={groqConnected}
              isGrammarEnabled={isGrammarEnabled}
              onToggleGrammar={onToggleGrammar}
              captionVisibilityRange={captionVisibilityRange}
              onUpdateCaptionVisibilityRange={onUpdateCaptionVisibilityRange}
              onTrimSilence={onTrimSilence}
              isKeywordsOnlyMode={isKeywordsOnlyMode}
              onToggleKeywordsOnlyMode={onToggleKeywordsOnlyMode}
            />
          </div>
        )}

        {/* Tab 3: Essential Graphics (30 Presets & Customizer) */}
        {activeTab === 'graphics' && (
          <div className="h-full overflow-y-auto p-4 space-y-4 bg-[#FAF9F7]">
            <PresetSelector
              selectedPreset={activePreset}
              onSelectPreset={onSelectPreset}
              showCustomizer={showCustomizer}
              onToggleCustomizer={onToggleCustomizer}
            />
            {showCustomizer && (
              <StyleControls preset={activePreset} onChange={onSelectPreset} />
            )}
          </div>
        )}

        {/* Tab 4: Effect Controls (Time-Shift, Silence Trimmer, Range, Pop-in Sync) */}
        {activeTab === 'effects' && (
          <div className="h-full overflow-y-auto p-4 space-y-4 bg-[#FAF9F7] text-xs">
            {/* Instant Prominent Keywords Sync */}
            <div className="bg-white border border-[#FED7AA] rounded-2xl p-4 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🎯</span>
                  <div>
                    <h4 className="font-bold text-sm text-[#1C1C1E] font-['Cairo',sans-serif]">
                      الظهور الفوري للمصطلحات البارزة (Instant Keyword Speech Pop)
                    </h4>
                    <p className="text-[11px] text-[#C2410C] font-semibold">
                      ظهور فوري للمصطلح البارز في نفس لحظة نطقه دون أي تأخير
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-[#FDF2EC] text-[#C2410C] font-bold border border-[#FED7AA] text-[11px]">
                  مفعّل تلقائياً ✓
                </span>
              </div>
              <p className="text-[#554F47] text-[11.5px] leading-relaxed">
                بمجرد أن يبدأ المتحدث في نطق المصطلح أو الكلمة المفتاحية، تنبثق الكلمة فوراً بحجم بارز ولون مضيء يجذب عين المشاهد في نفس الثانية.
              </p>
              <div className="flex items-center gap-2 pt-1 flex-wrap">
                <button
                  onClick={() => onShiftAllTime(-0.15)}
                  className="px-3 py-1.5 bg-[#FEF3EC] hover:bg-[#FDE7D9] border border-[#FED7AA] text-[#C2410C] font-bold rounded-xl transition active:scale-95 flex items-center gap-1.5 shadow-2xs"
                >
                  <span>⚡ تسريع ظهور المصطلح (-0.15 ث)</span>
                </button>
                <button
                  onClick={onDetectSmartKeywords}
                  className="px-3 py-1.5 bg-[#F4F1FA] hover:bg-[#EBE5F7] border border-[#DDD6FE] text-[#6B21A8] font-bold rounded-xl transition active:scale-95 flex items-center gap-1.5 shadow-2xs"
                >
                  <span>✨ استخراج وتلوين المصطلحات تلقائياً</span>
                </button>
              </div>
            </div>

            {/* Global Time Shift Effect */}
            <div className="bg-white border border-[#E5E0D8] rounded-2xl p-4 space-y-3 shadow-2xs">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#E0532B]" />
                <h4 className="font-bold text-sm text-[#1C1C1E] font-['Cairo',sans-serif]">
                  معالجة تأخير وتوقيت الكابشن (Global Time-Shift)
                </h4>
              </div>
              <p className="text-[#554F47] leading-relaxed">
                إذا كان الكابشن يظهر متأخراً قليلاً عن حركة الشفاه أو متقدماً، استخدم هذه الأزرار لتقديم أو تأخير كل المقاطع معاً فورياً.
              </p>
              <div className="flex items-center gap-2 flex-wrap pt-1">
                <button
                  onClick={() => onShiftAllTime(-0.3)}
                  className="px-3 py-1.5 bg-[#FAF9F7] hover:bg-white text-[#1C1C1E] rounded-xl border border-[#E5E0D8] font-mono transition shadow-2xs font-semibold"
                >
                  -0.3s (تقديم سريع)
                </button>
                <button
                  onClick={() => onShiftAllTime(-0.1)}
                  className="px-3 py-1.5 bg-[#FAF9F7] hover:bg-white text-[#1C1C1E] rounded-xl border border-[#E5E0D8] font-mono transition shadow-2xs font-semibold"
                >
                  -0.1s
                </button>
                <button
                  onClick={() => onShiftAllTime(0.1)}
                  className="px-3 py-1.5 bg-[#FAF9F7] hover:bg-white text-[#1C1C1E] rounded-xl border border-[#E5E0D8] font-mono transition shadow-2xs font-semibold"
                >
                  +0.1s
                </button>
                <button
                  onClick={() => onShiftAllTime(0.3)}
                  className="px-3 py-1.5 bg-[#FAF9F7] hover:bg-white text-[#1C1C1E] rounded-xl border border-[#E5E0D8] font-mono transition shadow-2xs font-semibold"
                >
                  +0.3s (تأخير)
                </button>
              </div>
            </div>

            {/* Silence Cleaner Effect */}
            <div className="bg-white border border-[#E5E0D8] rounded-2xl p-4 space-y-3 shadow-2xs">
              <div className="flex items-center gap-2">
                <Scissors className="w-4 h-4 text-[#EA580C]" />
                <h4 className="font-bold text-sm text-[#1C1C1E] font-['Cairo',sans-serif]">
                  إخفاء الكابشن فور توقف الكلام (Silence Trimmer)
                </h4>
              </div>
              <p className="text-[#554F47] leading-relaxed">
                يقوم بقص أوقات نهاية المقاطع تلقائياً ليختفي الكابشن بمجرد توقف المتحدث عن الكلام حتى لا تظل آخر كلمة معلقة أثناء الصمت.
              </p>
              <button
                onClick={onTrimSilence}
                className="px-4 py-2 bg-[#FEF3EC] hover:bg-[#FDE7D9] border border-[#FED7AA] text-[#C2410C] font-bold rounded-xl transition shadow-2xs flex items-center gap-1.5"
              >
                <span>🧹 تنظيف فترات السكوت والصمت لكل المقاطع</span>
              </button>
            </div>

            {/* Caption Active Visibility Range */}
            <div className="bg-white border border-[#E5E0D8] rounded-2xl p-4 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-[#1C1C1E] font-['Cairo',sans-serif]">
                  تحديد نطاق زمني مخصص لظهور الكابشن (اختياري)
                </span>
                <label className="flex items-center gap-2 cursor-pointer font-bold text-[#E0532B]">
                  <input
                    type="checkbox"
                    checked={captionVisibilityRange.enabled}
                    onChange={(e) =>
                      onUpdateCaptionVisibilityRange({
                        ...captionVisibilityRange,
                        enabled: e.target.checked,
                      })
                    }
                    className="rounded accent-[#E0532B]"
                  />
                  <span>تفعيل</span>
                </label>
              </div>

              {captionVisibilityRange.enabled ? (
                <div className="space-y-3 pt-2">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[#78716C] block mb-1">وقت البداية (ثانية):</span>
                      <input
                        type="number"
                        min={0}
                        max={captionVisibilityRange.endTime - 1}
                        value={captionVisibilityRange.startTime}
                        onChange={(e) =>
                          onUpdateCaptionVisibilityRange({
                            ...captionVisibilityRange,
                            startTime: Math.max(0, parseFloat(e.target.value) || 0),
                          })
                        }
                        className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl p-2 font-mono text-[#1C1C1E] text-center font-bold focus:outline-none focus:border-[#E0532B]"
                      />
                    </div>
                    <div>
                      <span className="text-[#78716C] block mb-1">وقت النهاية (ثانية):</span>
                      <input
                        type="number"
                        min={captionVisibilityRange.startTime + 1}
                        max={duration || 1800}
                        value={captionVisibilityRange.endTime}
                        onChange={(e) =>
                          onUpdateCaptionVisibilityRange({
                            ...captionVisibilityRange,
                            endTime: Math.max(
                              captionVisibilityRange.startTime + 1,
                              parseFloat(e.target.value) || 180
                            ),
                          })
                        }
                        className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl p-2 font-mono text-[#1C1C1E] text-center font-bold focus:outline-none focus:border-[#E0532B]"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={() =>
                        onUpdateCaptionVisibilityRange({
                          enabled: false,
                          startTime: 0,
                          endTime: duration || 999999,
                        })
                      }
                      className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-[11px] font-bold shadow-2xs hover:bg-emerald-100"
                    >
                      كامل الفيديو (طوال مدة المقطع) ✨
                    </button>
                    <button
                      onClick={() =>
                        onUpdateCaptionVisibilityRange({
                          enabled: true,
                          startTime: 0,
                          endTime: 60,
                        })
                      }
                      className="px-3 py-1.5 rounded-xl bg-[#FAF9F7] hover:bg-white text-[#554F47] border border-[#E5E0D8] text-[11px] font-semibold shadow-2xs"
                    >
                      أول دقيقة (01:00)
                    </button>
                  </div>
                </div>
              ) : (
                <span className="text-[#8D827A] text-[11px]">
                  الكابشن يظهر على كامل مدة الفيديو بدون اقتطاع.
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
