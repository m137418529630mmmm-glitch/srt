import React from 'react';
import { SubtitleStylePreset, SubtitleAnimation } from '../types';
import { Palette, Type, MoveVertical, Sparkles, Layers } from 'lucide-react';
import { CATEGORY_COLORS } from '../constants/presets';

interface StyleControlsProps {
  preset: SubtitleStylePreset;
  onChange: (updated: SubtitleStylePreset) => void;
}

const FONTS = [
  { label: 'تجوال (Tajawal - عربي فخم)', value: 'Tajawal, sans-serif' },
  { label: 'كايرو (Cairo - عربي عصري)', value: 'Cairo, sans-serif' },
  { label: 'مونتسيرات (Montserrat - هرموزي)', value: 'Montserrat, sans-serif' },
  { label: 'أنتون (Anton - مستر بيست عريض)', value: 'Anton, sans-serif' },
  { label: 'أوتفيت (Outfit - تيك توك مودرن)', value: 'Outfit, sans-serif' },
];

const PRESET_COLORS = [
  '#FFE600', // Yellow
  '#EF4444', // Red
  '#00F0FF', // Cyan
  '#22C55E', // Green
  '#A855F7', // Purple
  '#F59E0B', // Amber
  '#FFFFFF', // White
  '#FF007F', // Hot Pink
];

export const StyleControls: React.FC<StyleControlsProps> = ({ preset, onChange }) => {
  const update = (partial: Partial<SubtitleStylePreset>) => {
    onChange({ ...preset, ...partial });
  };

  return (
    <div className="bg-white border border-[#E5E0D8] rounded-2xl p-4 shadow-2xs space-y-4 animate-in fade-in duration-200 text-xs">
      <div className="flex items-center gap-2 border-b border-[#F3EFEA] pb-3">
        <Palette className="w-4 h-4 text-[#E0532B]" />
        <h4 className="font-bold text-sm text-[#1C1C1E] font-['Cairo',sans-serif]">تخصيص تفاصيل الستايل (Customizer)</h4>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Font Family */}
        <div className="space-y-1.5">
          <label className="text-[#2E2A25] font-semibold flex items-center gap-1.5">
            <Type className="w-3.5 h-3.5 text-[#E0532B]" />
            <span>نوع الخط (Font Family)</span>
          </label>
          <select
            value={preset.fontFamily}
            onChange={(e) => update({ fontFamily: e.target.value })}
            className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl px-2.5 py-1.5 text-[#1C1C1E] text-xs focus:outline-none focus:border-[#E0532B]"
          >
            {FONTS.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </div>

        {/* Font Size */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[#2E2A25] font-semibold">
            <span>حجم الخط (Font Size)</span>
            <span className="font-mono text-[#E0532B] font-bold">{preset.fontSize}px</span>
          </div>
          <input
            type="range"
            min={24}
            max={72}
            value={preset.fontSize}
            onChange={(e) => update({ fontSize: parseInt(e.target.value) })}
            className="w-full h-1.5 bg-[#E5E0D8] rounded-lg appearance-none cursor-pointer accent-[#E0532B]"
          />
        </div>

        {/* Keyword Color Swatches */}
        <div className="space-y-1.5">
          <label className="text-[#2E2A25] font-semibold flex items-center justify-between">
            <span>لون الكلمات المفتاحية الأساسي</span>
            <span
              className="w-3.5 h-3.5 rounded-full border border-black/10 shadow-2xs"
              style={{ backgroundColor: preset.keywordColor }}
            />
          </label>
          <div className="flex items-center gap-1.5">
            {PRESET_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => update({ keywordColor: c })}
                style={{ backgroundColor: c }}
                className={`w-6 h-6 rounded-md border transition-transform active:scale-90 ${
                  preset.keywordColor === c ? 'scale-110 border-[#1C1C1E] ring-2 ring-[#E0532B]/50' : 'border-[#E5E0D8]'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Stroke Width */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[#2E2A25] font-semibold">
            <span>سماكة الإطار (Outline / Stroke)</span>
            <span className="font-mono text-[#E0532B] font-bold">{preset.strokeWidth}px</span>
          </div>
          <input
            type="range"
            min={0}
            max={14}
            value={preset.strokeWidth}
            onChange={(e) => update({ strokeWidth: parseInt(e.target.value) })}
            className="w-full h-1.5 bg-[#E5E0D8] rounded-lg appearance-none cursor-pointer accent-[#E0532B]"
          />
        </div>

        {/* Position Y (Vertical alignment) */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[#2E2A25] font-semibold">
            <span className="flex items-center gap-1">
              <MoveVertical className="w-3.5 h-3.5 text-[#E0532B]" />
              <span>موضع النص الرأسي (Position Y)</span>
            </span>
            <span className="font-mono text-[#E0532B] font-bold">{preset.positionY}%</span>
          </div>
          <input
            type="range"
            min={20}
            max={90}
            value={preset.positionY}
            onChange={(e) => update({ positionY: parseInt(e.target.value) })}
            className="w-full h-1.5 bg-[#E5E0D8] rounded-lg appearance-none cursor-pointer accent-[#E0532B]"
          />
          <div className="flex justify-between text-[10px] text-[#8D827A]">
            <span>أعلى (20%)</span>
            <span>وسط (50%)</span>
            <span>أسفل (78%)</span>
          </div>
        </div>

        {/* Max Words per line & Animation */}
        <div className="space-y-1.5">
          <label className="text-[#2E2A25] font-semibold flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#E0532B]" />
            <span>حركة الكابشن (Animation)</span>
          </label>
          <select
            value={preset.animation}
            onChange={(e) => update({ animation: e.target.value as SubtitleAnimation })}
            className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl px-2.5 py-1.5 text-[#1C1C1E] text-xs focus:outline-none focus:border-[#E0532B]"
          >
            <option value="pop">انبثاق الكلمة (Pop Scale)</option>
            <option value="bounce">وثب حيوي (Bounce)</option>
            <option value="glow">توهج نيون (Neon Glow)</option>
            <option value="karaoke">كاريوكي الكلمة الحالية (Karaoke)</option>
            <option value="none">ثابت بدون حركة (Static)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
