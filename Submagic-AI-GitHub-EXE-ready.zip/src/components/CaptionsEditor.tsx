import React, { useState } from 'react';
import {
  SubtitleSegment,
  KeywordHighlight,
  SubtitleStylePreset,
  CaptionVisibilityRange,
} from '../types';
import {
  Zap,
  Sparkles,
  Languages,
  Plus,
  Trash2,
  Play,
  Download,
  Split,
  ChevronDown,
  Clock,
  Wand2,
  Layers,
  Type,
  CheckCircle2,
} from 'lucide-react';
import {
  formatTimeSRT,
  generateSRT,
  generateVTT,
  downloadFile,
} from '../utils/srt';
import { CATEGORY_COLORS } from '../constants/presets';
import { Language, translations } from '../utils/translations';

interface CaptionsEditorProps {
  lang?: Language;
  segments: SubtitleSegment[];
  currentTime: number;
  duration: number;
  activePreset: SubtitleStylePreset;
  onUpdateSegments: (segments: SubtitleSegment[]) => void;
  onSeek: (time: number) => void;
  onGenerateGroq: () => void;
  onGenerateGemini: (translateTo?: string) => void;
  onDetectSmartKeywords: () => void;
  onTranslate: (lang: string) => void;
  onFixGrammar: () => void;
  onSmartResegment: () => void;
  onShiftAllTime: (delta: number) => void;
  onExtractKeyHighlights: () => void;
  isTranscribing: boolean;
  isProcessingAI: boolean;
  groqConnected: boolean;
  isGrammarEnabled: boolean;
  onToggleGrammar: () => void;
  captionVisibilityRange: CaptionVisibilityRange;
  onUpdateCaptionVisibilityRange: (range: CaptionVisibilityRange) => void;
  onTrimSilence: () => void;
  isKeywordsOnlyMode?: boolean;
  onToggleKeywordsOnlyMode?: () => void;
}

export const CaptionsEditor: React.FC<CaptionsEditorProps> = ({
  lang = 'en',
  segments,
  currentTime,
  activePreset,
  onUpdateSegments,
  onSeek,
  onGenerateGroq,
  onGenerateGemini,
  onDetectSmartKeywords,
  onTranslate,
  onFixGrammar,
  onSmartResegment,
  onShiftAllTime,
  isTranscribing,
  isProcessingAI,
  onTrimSilence,
  isKeywordsOnlyMode = false,
  onToggleKeywordsOnlyMode,
}) => {
  const t = translations[lang];
  const [searchQuery, setSearchQuery] = useState('');
  const [showTranscribeMenu, setShowTranscribeMenu] = useState(false);
  const [showTranslateMenu, setShowTranslateMenu] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [keywordsClickedRecently, setKeywordsClickedRecently] = useState(false);

  // Update a single segment
  const updateSegment = (id: number, partial: Partial<SubtitleSegment>) => {
    const updated = segments.map((seg) =>
      seg.id === id ? { ...seg, ...partial } : seg
    );
    onUpdateSegments(updated);
  };

  // Delete segment
  const deleteSegment = (id: number) => {
    const updated = segments
      .filter((s) => s.id !== id)
      .map((s, idx) => ({ ...s, id: idx + 1 }));
    onUpdateSegments(updated);
  };

  // Add new empty segment at current playhead or at end
  const addSegment = () => {
    const start = Number(currentTime.toFixed(2));
    const end = Number((start + 2.5).toFixed(2));
    const newSeg: SubtitleSegment = {
      id: segments.length + 1,
      start,
      end,
      text: lang === 'en' ? 'New subtitle text' : 'نص كابشن جديد',
      highlightKeywords: [{ word: lang === 'en' ? 'subtitle' : 'جديد', category: 'yellow' }],
    };
    const updated = [...segments, newSeg].sort((a, b) => a.start - b.start);
    onUpdateSegments(updated.map((s, idx) => ({ ...s, id: idx + 1 })));
  };

  // Split segment in half
  const splitSegment = (seg: SubtitleSegment) => {
    const words = seg.text.trim().split(/\s+/);
    if (words.length < 2) return;
    const midIdx = Math.ceil(words.length / 2);
    const midTime = Number(((seg.start + seg.end) / 2).toFixed(2));

    const seg1: SubtitleSegment = {
      id: seg.id,
      start: seg.start,
      end: midTime,
      text: words.slice(0, midIdx).join(' '),
      highlightKeywords: seg.highlightKeywords?.filter((kw) =>
        words.slice(0, midIdx).includes(kw.word)
      ),
    };

    const seg2: SubtitleSegment = {
      id: seg.id + 1,
      start: midTime,
      end: seg.end,
      text: words.slice(midIdx).join(' '),
      highlightKeywords: seg.highlightKeywords?.filter((kw) =>
        words.slice(midIdx).includes(kw.word)
      ),
    };

    const idx = segments.findIndex((s) => s.id === seg.id);
    const updated = [...segments.slice(0, idx), seg1, seg2, ...segments.slice(idx + 1)];
    onUpdateSegments(updated.map((s, i) => ({ ...s, id: i + 1 })));
  };

  // Toggle keyword highlight for a specific word
  const toggleWordKeyword = (seg: SubtitleSegment, wordText: string) => {
    const clean = wordText.replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '');
    const currentHighlights = seg.highlightKeywords || [];
    const exists = currentHighlights.find(
      (k) => k.word.toLowerCase() === clean.toLowerCase()
    );

    let updatedHighlights: KeywordHighlight[];
    if (exists) {
      const order: ('yellow' | 'red' | 'cyan' | 'green')[] = [
        'yellow',
        'red',
        'cyan',
        'green',
      ];
      const curIdx = order.indexOf(exists.category as any);
      if (curIdx < order.length - 1) {
        updatedHighlights = currentHighlights.map((k) =>
          k.word.toLowerCase() === clean.toLowerCase()
            ? { ...k, category: order[curIdx + 1] }
            : k
        );
      } else {
        updatedHighlights = currentHighlights.filter(
          (k) => k.word.toLowerCase() !== clean.toLowerCase()
        );
      }
    } else {
      updatedHighlights = [
        ...currentHighlights,
        { word: clean, category: 'yellow' },
      ];
    }
    updateSegment(seg.id, { highlightKeywords: updatedHighlights });
  };

  // Nudge timestamps for individual segment
  const nudgeTime = (segId: number, field: 'start' | 'end', delta: number) => {
    const seg = segments.find((s) => s.id === segId);
    if (!seg) return;
    const newVal = Number(Math.max(0, seg[field] + delta).toFixed(2));
    if (field === 'start' && newVal >= seg.end) return;
    if (field === 'end' && newVal <= seg.start) return;
    updateSegment(segId, { [field]: newVal });
  };

  // Trigger keyword detection with visual feedback
  const handleKeywordsClick = () => {
    setKeywordsClickedRecently(true);
    setTimeout(() => setKeywordsClickedRecently(false), 2500);
    onDetectSmartKeywords();
  };

  // Filter segments
  const filteredSegments = segments.filter((s) =>
    s.text.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-2xl overflow-hidden shadow-xs">
      {/* Top AI Action Bar */}
      <div className="p-3 bg-[#FAF9F7] border-b border-[#E5E0D8] space-y-2.5">
        <div className="space-y-2">
          {/* Row 1: Transcription and Translation (SEPARATED as requested by user) */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* 1. Fast Groq Whisper Transcribe */}
            <button
              onClick={onGenerateGroq}
              disabled={isTranscribing || isProcessingAI}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition shadow-xs ${
                isTranscribing
                  ? 'bg-[#E0532B]/60 text-white animate-pulse cursor-wait'
                  : 'bg-[#E0532B] hover:bg-[#C9431E] text-white active:scale-95'
              }`}
              title={t.generateGroq}
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>{isTranscribing ? '...' : t.generateGroq}</span>
            </button>

            {/* 2. Dedicated Audio Transcription Dropdown */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowTranscribeMenu(!showTranscribeMenu);
                  setShowTranslateMenu(false);
                }}
                disabled={isTranscribing || isProcessingAI}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-[#6B21A8] bg-[#F4F1FA] hover:bg-[#EBE5F7] border border-[#DDD6FE] rounded-xl transition shadow-2xs active:scale-95"
                title={t.transcribeAudio}
              >
                <Sparkles className="w-3.5 h-3.5 text-[#9333EA]" />
                <span>{t.transcribeAudio}</span>
                <ChevronDown className="w-3 h-3 text-[#9333EA]" />
              </button>

              {showTranscribeMenu && (
                <div className="absolute top-full mt-1.5 left-0 rtl:left-auto rtl:right-0 z-50 w-56 bg-white border border-[#E5E0D8] rounded-xl shadow-xl p-1.5 space-y-1">
                  <button
                    onClick={() => {
                      onGenerateGemini();
                      setShowTranscribeMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition flex items-center justify-between"
                  >
                    <span>{t.transcribeOriginal}</span>
                  </button>
                  <button
                    onClick={() => {
                      onGenerateGemini('العربية (Arabic)');
                      setShowTranscribeMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition flex items-center justify-between"
                  >
                    <span>{t.transcribeArabic}</span>
                  </button>
                  <button
                    onClick={() => {
                      onGenerateGemini('English');
                      setShowTranscribeMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition flex items-center justify-between"
                  >
                    <span>{t.transcribeEnglish}</span>
                  </button>
                </div>
              )}
            </div>

            {/* 3. Dedicated Translation Dropdown (Translates existing captions without re-transcribing!) */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowTranslateMenu(!showTranslateMenu);
                  setShowTranscribeMenu(false);
                }}
                disabled={segments.length === 0 || isProcessingAI}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-[#0D9488] bg-[#F0FDFA] hover:bg-[#CCFBF1] border border-[#99F6E4] rounded-xl transition shadow-2xs active:scale-95"
                title={t.translateCaptions}
              >
                <Languages className="w-3.5 h-3.5 text-[#0D9488]" />
                <span>{t.translateCaptions}</span>
                <ChevronDown className="w-3 h-3 text-[#0D9488]" />
              </button>

              {showTranslateMenu && (
                <div className="absolute top-full mt-1.5 left-0 rtl:left-auto rtl:right-0 z-50 w-56 bg-white border border-[#E5E0D8] rounded-xl shadow-xl p-1.5 space-y-1">
                  <div className="px-2.5 py-1 text-[10px] text-[#0F766E] font-bold border-b border-[#F3EFEA]">
                    {lang === 'en' ? 'Translate current subtitles into:' : 'ترجمة الكابشن الحالي إلى:'}
                  </div>
                  <button
                    onClick={() => {
                      onTranslate('العربية (Arabic)');
                      setShowTranslateMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition"
                  >
                    <span>{t.translateToArabic}</span>
                  </button>
                  <button
                    onClick={() => {
                      onTranslate('English');
                      setShowTranslateMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition"
                  >
                    <span>{t.translateToEnglish}</span>
                  </button>
                  <button
                    onClick={() => {
                      onTranslate('French (الفرنسية)');
                      setShowTranslateMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition"
                  >
                    <span>{t.translateToFrench}</span>
                  </button>
                  <button
                    onClick={() => {
                      onTranslate('Spanish (الإسبانية)');
                      setShowTranslateMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition"
                  >
                    <span>{t.translateToSpanish}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Smart Re-segmenting / Merging */}
            <button
              onClick={onSmartResegment}
              disabled={segments.length === 0 || isProcessingAI}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#C2410C] bg-[#FDF0EB] hover:bg-[#FAECE3] border border-[#FED7AA] rounded-xl transition active:scale-95 shadow-2xs"
              title={t.smartResegment}
            >
              <Layers className="w-3.5 h-3.5 text-[#EA580C]" />
              <span>{t.smartResegment}</span>
            </button>
          </div>

          {/* Row 2: Keyword detection, Featured Captions mode, Grammar */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Smart Keywords Detection */}
            <button
              onClick={handleKeywordsClick}
              disabled={segments.length === 0 || isProcessingAI}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl transition active:scale-95 shadow-2xs ${
                keywordsClickedRecently
                  ? 'bg-[#FEF3C7] text-[#B45309] border border-[#FCD34D] ring-2 ring-[#F59E0B]/30'
                  : 'bg-white hover:bg-[#F3EFEA] text-[#1C1C1E] border border-[#E5E0D8]'
              }`}
              title={t.smartKeywords}
            >
              <Wand2 className="w-3.5 h-3.5 text-[#E0532B]" />
              <span>{t.smartKeywords}</span>
              {keywordsClickedRecently && <span className="text-[10px] font-bold">✓</span>}
            </button>

            {/* Mode Switch: Featured Captions ("الكابشن المميز") - FIXED BUG & PROMINENT ACTIVE STATE */}
            <button
              onClick={() => {
                if (onToggleKeywordsOnlyMode) {
                  onToggleKeywordsOnlyMode();
                }
              }}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-xl transition active:scale-95 shadow-2xs ${
                isKeywordsOnlyMode
                  ? 'bg-[#E0532B] text-white border border-[#E0532B] shadow-sm ring-2 ring-[#E0532B]/30'
                  : 'bg-white hover:bg-[#F3EFEA] text-[#1C1C1E] border border-[#E5E0D8]'
              }`}
              title={lang === 'en' ? 'Toggle Featured Prominent Captions Only' : 'تفعيل وضع الكابشن المميز والمصطلحات البارزة فقط'}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${isKeywordsOnlyMode ? 'text-white' : 'text-[#E0532B]'}`} />
              <span>{t.featuredCaptions}</span>
              {isKeywordsOnlyMode && (
                <span className="text-[10px] bg-white/25 px-1 py-0.2 rounded-sm font-mono">
                  ON
                </span>
              )}
            </button>

            {/* Grammar / Spell Check */}
            <button
              onClick={onFixGrammar}
              disabled={segments.length === 0 || isProcessingAI}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#1C1C1E] bg-white hover:bg-[#F3EFEA] border border-[#E5E0D8] rounded-xl transition active:scale-95 shadow-2xs"
              title={t.grammarCheck}
            >
              <Type className="w-3.5 h-3.5 text-[#554F47]" />
              <span>{t.grammarCheck}</span>
            </button>
          </div>

          {/* Row 3: Add segment & Export SRT */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={addSegment}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#1C1C1E] bg-white hover:bg-[#F3EFEA] border border-[#E5E0D8] rounded-xl transition shadow-2xs"
              title={t.addSegment}
            >
              <Plus className="w-3.5 h-3.5 text-[#16A34A]" />
              <span>{t.addSegment}</span>
            </button>

            {/* Download SRT Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                disabled={segments.length === 0}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#1C1C1E] bg-white hover:bg-[#F3EFEA] border border-[#E5E0D8] rounded-xl transition shadow-2xs"
              >
                <Download className="w-3.5 h-3.5 text-[#554F47]" />
                <span>{t.downloadSrt}</span>
                <ChevronDown className="w-3 h-3 text-[#8D827A]" />
              </button>

              {showExportMenu && (
                <div className="absolute top-full mt-1.5 left-0 rtl:left-auto rtl:right-0 z-50 w-44 bg-white border border-[#E5E0D8] rounded-xl shadow-xl p-1.5 space-y-1">
                  <button
                    onClick={() => {
                      downloadFile(generateSRT(segments), 'subtitles.srt', 'text/plain');
                      setShowExportMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition"
                  >
                    .SRT ({t.downloadSrt})
                  </button>
                  <button
                    onClick={() => {
                      downloadFile(generateVTT(segments), 'subtitles.vtt', 'text/vtt');
                      setShowExportMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition"
                  >
                    {t.downloadVtt}
                  </button>
                  <button
                    onClick={() => {
                      const plainText = segments.map((s) => s.text).join('\n');
                      downloadFile(plainText, 'transcript.txt', 'text/plain');
                      setShowExportMenu(false);
                    }}
                    className="w-full text-left rtl:text-right px-3 py-1.5 text-xs rounded-lg hover:bg-[#FAF9F7] text-[#1C1C1E] transition"
                  >
                    {t.downloadTxt}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Global Timing Controller Card */}
        <div className="bg-white border border-[#E5E0D8] rounded-2xl p-3 shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-[#1C1C1E] font-bold">
              <Clock className="w-3.5 h-3.5 text-[#E0532B]" />
              <span>{t.timingControl}</span>
              <span className="text-[10px] text-[#8D827A] font-normal">
                {t.timingControlHint}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap text-xs">
            <button
              onClick={() => onShiftAllTime(0.1)}
              className="px-2.5 py-1 rounded-lg bg-[#FEF3EC] text-[#C2410C] border border-[#FED7AA] font-bold text-[11px] flex items-center gap-1 transition shadow-2xs active:scale-95"
            >
              <span>+0.1s ⚡</span>
            </button>
            <button
              onClick={() => onShiftAllTime(-0.1)}
              className="px-2.5 py-1 rounded-lg bg-white border border-[#E5E0D8] text-[#1C1C1E] text-[11px] font-mono hover:bg-[#F3EFEA] transition shadow-2xs"
            >
              -0.1s
            </button>
            <button
              onClick={() => onShiftAllTime(0.25)}
              className="px-2.5 py-1 rounded-lg bg-white border border-[#E5E0D8] text-[#1C1C1E] text-[11px] font-mono hover:bg-[#F3EFEA] transition shadow-2xs"
            >
              +0.25s
            </button>
            <button
              onClick={onTrimSilence}
              className="px-2.5 py-1 rounded-lg bg-[#FEF3EC] text-[#C2410C] border border-[#FED7AA] font-bold text-[11px] flex items-center gap-1 transition shadow-2xs"
            >
              <span>{t.trimSilence}</span>
            </button>
          </div>
        </div>

        {/* Search bar */}
        <div className="pt-1">
          <input
            type="text"
            placeholder={t.searchCaptions}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-[#E5E0D8] rounded-xl px-3 py-2 text-xs text-[#1C1C1E] placeholder-[#A8A29E] focus:outline-none focus:border-[#E0532B] shadow-2xs"
          />
        </div>
      </div>

      {/* Segments List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-[#FAF9F7]">
        {filteredSegments.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-12 text-center text-[#8D827A] space-y-3">
            <Sparkles className="w-8 h-8 text-[#A8A29E]" />
            <p className="text-sm font-semibold text-[#78716C]">{t.noCaptions}</p>
          </div>
        ) : (
          filteredSegments.map((seg) => {
            const isActive = currentTime >= seg.start && currentTime <= seg.end;
            const words = seg.text.trim().split(/\s+/).filter(Boolean);

            return (
              <div
                key={seg.id}
                className={`transition-all rounded-2xl p-3.5 ${
                  isActive
                    ? 'bg-[#FDF2EC] border border-[#FDBA74] shadow-xs ring-1 ring-[#FED7AA]'
                    : 'bg-white hover:bg-[#FAF9F7] border border-[#E5E0D8] shadow-2xs'
                }`}
              >
                {/* Header row: ID, timestamps, actions */}
                <div className="flex items-center justify-between text-xs mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-[#FAF0EC] border border-[#FED7AA] flex items-center justify-center font-mono text-[11px] font-bold text-[#E0532B]">
                      {seg.id}
                    </span>

                    {/* Start time controls */}
                    <div className="flex items-center bg-[#FAF9F7] px-2 py-0.5 rounded-lg border border-[#E5E0D8] font-mono text-[11px] text-[#1C1C1E] gap-1" dir="ltr">
                      <button
                        onClick={() => nudgeTime(seg.id, 'start', -0.05)}
                        className="text-[#8D827A] hover:text-[#1C1C1E] px-0.5"
                      >
                        -
                      </button>
                      <span>{formatTimeSRT(seg.start).slice(3, 11)}</span>
                      <button
                        onClick={() => nudgeTime(seg.id, 'start', 0.05)}
                        className="text-[#8D827A] hover:text-[#1C1C1E] px-0.5"
                      >
                        +
                      </button>
                    </div>

                    <span className="text-[#A8A29E] font-mono text-[10px]">→</span>

                    {/* End time controls */}
                    <div className="flex items-center bg-[#FAF9F7] px-2 py-0.5 rounded-lg border border-[#E5E0D8] font-mono text-[11px] text-[#1C1C1E] gap-1" dir="ltr">
                      <button
                        onClick={() => nudgeTime(seg.id, 'end', -0.05)}
                        className="text-[#8D827A] hover:text-[#1C1C1E] px-0.5"
                      >
                        -
                      </button>
                      <span>{formatTimeSRT(seg.end).slice(3, 11)}</span>
                      <button
                        onClick={() => nudgeTime(seg.id, 'end', 0.05)}
                        className="text-[#8D827A] hover:text-[#1C1C1E] px-0.5"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onSeek(seg.start)}
                      className="p-1.5 text-[#554F47] hover:text-[#E0532B] rounded-lg hover:bg-[#F3EFEA] transition"
                      title={lang === 'en' ? 'Play clip' : 'تشغيل هذا المقطع'}
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </button>
                    <button
                      onClick={() => splitSegment(seg)}
                      className="p-1.5 text-[#554F47] hover:text-amber-600 rounded-lg hover:bg-[#F3EFEA] transition"
                      title={lang === 'en' ? 'Split clip' : 'تقسيم المقطع لنصفين'}
                    >
                      <Split className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteSegment(seg.id)}
                      className="p-1.5 text-[#554F47] hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                      title={lang === 'en' ? 'Delete clip' : 'حذف هذا المقطع'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Subtitle Text Area */}
                <input
                  type="text"
                  value={seg.text}
                  onChange={(e) => updateSegment(seg.id, { text: e.target.value })}
                  className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl px-3 py-1.5 text-sm text-[#1C1C1E] focus:outline-none focus:border-[#E0532B] focus:ring-1 focus:ring-[#E0532B]/30"
                />

                {/* Clickable Word Highlighting Pills */}
                <div className="mt-2.5 flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-[10px] text-[#8D827A] ml-1">{t.clickKeywordHint}</span>
                  {words.map((word, wIdx) => {
                    const clean = word.replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '');
                    const kw = seg.highlightKeywords?.find(
                      (k) => k.word.toLowerCase() === clean.toLowerCase()
                    );
                    const color = kw
                      ? CATEGORY_COLORS[kw.category] || activePreset.keywordColor
                      : undefined;

                    return (
                      <button
                        key={wIdx}
                        onClick={() => toggleWordKeyword(seg, word)}
                        style={
                          kw
                            ? {
                                backgroundColor: `${color}20`,
                                borderColor: `${color}90`,
                                color: color,
                              }
                            : undefined
                        }
                        className={`px-2.5 py-0.5 rounded-lg border text-[11px] transition-all font-semibold active:scale-95 ${
                          kw
                            ? 'shadow-xs font-bold scale-105'
                            : 'bg-white border-[#E5E0D8] text-[#554F47] hover:text-[#1C1C1E] hover:border-[#D5CFBF]'
                        }`}
                        title={lang === 'en' ? 'Click to toggle keyword color' : 'انقر لتمييز هذا المصطلح البارز وتغيير لونه'}
                      >
                        {word}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
