import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Maximize2,
  Upload,
  Scissors,
  Trash2,
  Film,
  Download,
  Settings,
  Sparkles,
  ChevronDown,
  Monitor,
  AlertCircle,
  Layers,
} from 'lucide-react';
import { SubtitleSegment, SubtitleStylePreset, CaptionVisibilityRange } from '../types';
import { formatTimecodePremiere } from '../utils/srt';
import { drawSubtitlesOnCanvas } from '../utils/videoRenderer';
import { Language, translations } from '../utils/translations';

interface ProgramMonitorProps {
  lang?: Language;
  videoSrc: string | null;
  videoElementRef: React.RefObject<HTMLVideoElement | null>;
  segments: SubtitleSegment[];
  activePreset: SubtitleStylePreset;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  onTimeUpdate: (time: number) => void;
  onDurationChange: (duration: number) => void;
  onPlayPause: () => void;
  onSeek: (time: number) => void;
  onFileUpload: (file: File) => void;
  onLoadSample: () => void;
  onSplitAtPlayhead: () => void;
  onDeleteSelected: () => void;
  onOpenExport: () => void;
  captionVisibilityRange: CaptionVisibilityRange;
  isAudioOnly?: boolean;
  backgroundMode?: 'video' | 'greenscreen' | 'black';
  onToggleGreenScreen?: () => void;
  onSplitVideo?: () => void;
  onMergeVideoCuts?: () => void;
}

export const ProgramMonitor: React.FC<ProgramMonitorProps> = ({
  lang = 'en',
  videoSrc,
  videoElementRef,
  segments,
  activePreset,
  currentTime,
  duration,
  isPlaying,
  onTimeUpdate,
  onDurationChange,
  onPlayPause,
  onSeek,
  onFileUpload,
  onLoadSample,
  onSplitAtPlayhead,
  onDeleteSelected,
  onOpenExport,
  captionVisibilityRange,
  isAudioOnly = false,
  backgroundMode = 'video',
  onToggleGreenScreen,
  onSplitVideo,
  onMergeVideoCuts,
}) => {
  const t = translations[lang];
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [isMuted, setIsMuted] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<'auto' | '9:16' | '16:9' | '1:1'>('auto');
  const [nativeDimensions, setNativeDimensions] = useState<{ width: number; height: number }>({ width: 0, height: 0 });
  const [monitorTime, setMonitorTime] = useState<number>(currentTime);
  const [zoomFit, setZoomFit] = useState<'fit' | '100%' | '75%'>('fit');
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [showSafeMargins, setShowSafeMargins] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileUpload(e.dataTransfer.files[0]);
    }
  };

  useEffect(() => {
    setLoadError(null);
  }, [videoSrc]);

  useEffect(() => {
    setMonitorTime(currentTime);
  }, [currentTime]);

  const handleVideoError = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    const err = e.currentTarget.error;
    console.warn('[ProgramMonitor] Video load error:', err?.code, err?.message);
    setLoadError(lang === 'en' ? 'Could not load video source. You can upload a video or audio file.' : 'تعذر تحميل مصدر المقطع الحالي. يمكنك رفع ملف فيديو أو صوت من جهازك للمتابعة.');
  };

  // Throttle time updates to parent at ~20fps (55ms) to prevent React re-render thrashing (solves "البرنامج تقيل اوي")
  const lastTimeUpdateRef = useRef<number>(0);
  const handleTimeUpdate = () => {
    if (videoElementRef.current) {
      const cur = videoElementRef.current.currentTime;
      const now = performance.now();
      if (now - lastTimeUpdateRef.current >= 55 || cur === 0 || videoElementRef.current.ended) {
        lastTimeUpdateRef.current = now;
        setMonitorTime(cur);
        onTimeUpdate(cur);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (videoElementRef.current) {
      const dur = videoElementRef.current.duration;
      if (dur && !isNaN(dur)) {
        onDurationChange(dur);
      }
      const w = videoElementRef.current.videoWidth || 0;
      const h = videoElementRef.current.videoHeight || 0;
      if (w > 0 && h > 0) {
        setNativeDimensions({ width: w, height: h });
      }
      // CRITICAL: When user selects 'auto' (or by default), keep 'auto' to preserve original dimensions!
      setTimeout(renderOverlay, 50);
    }
  };

  // Get native resolution
  const nativeW = nativeDimensions.width || videoElementRef.current?.videoWidth || 0;
  const nativeH = nativeDimensions.height || videoElementRef.current?.videoHeight || 0;

  // Resolved aspect ratio and resolution
  let resolvedRatioStr = '16 / 9';
  let resolvedRatioNum = 16 / 9;
  let resolvedWidth = 1920;
  let resolvedHeight = 1080;

  if (aspectRatio === 'auto') {
    if (nativeW > 0 && nativeH > 0) {
      resolvedRatioStr = `${nativeW} / ${nativeH}`;
      resolvedRatioNum = nativeW / nativeH;
      resolvedWidth = nativeW;
      resolvedHeight = nativeH;
    } else {
      resolvedRatioStr = '16 / 9';
      resolvedRatioNum = 16 / 9;
      resolvedWidth = 1920;
      resolvedHeight = 1080;
    }
  } else if (aspectRatio === '9:16') {
    resolvedRatioStr = '9 / 16';
    resolvedRatioNum = 9 / 16;
    resolvedWidth = 1080;
    resolvedHeight = 1920;
  } else if (aspectRatio === '16:9') {
    resolvedRatioStr = '16 / 9';
    resolvedRatioNum = 16 / 9;
    resolvedWidth = 1920;
    resolvedHeight = 1080;
  } else if (aspectRatio === '1:1') {
    resolvedRatioStr = '1 / 1';
    resolvedRatioNum = 1;
    resolvedWidth = 1080;
    resolvedHeight = 1080;
  }

  // Effective time from video or state
  const effectiveTime =
    videoElementRef.current && isPlaying
      ? videoElementRef.current.currentTime
      : monitorTime !== undefined
      ? monitorTime
      : currentTime;

  // Active segment at playhead (with range check)
  const isCaptionRangeValid =
    !captionVisibilityRange?.enabled ||
    (effectiveTime >= captionVisibilityRange.startTime && effectiveTime <= captionVisibilityRange.endTime);

  // Find exact segment or closest segment
  const activeSeg = isCaptionRangeValid
    ? segments.find((s) => effectiveTime >= s.start && effectiveTime <= s.end) ||
      (isPlaying
        ? null
        : segments.find(
            (s) => Math.abs(effectiveTime - s.start) <= 0.4 || Math.abs(effectiveTime - s.end) <= 0.4
          ) || (segments.length > 0 && effectiveTime <= segments[0].start ? segments[0] : null))
    : null;

  // Render overlay background on canvas (HTML overlay handles the crisp text)
  const renderOverlay = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = resolvedWidth;
    const height = resolvedHeight;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (backgroundMode === 'greenscreen' || (isAudioOnly && backgroundMode !== 'black')) {
      ctx.fillStyle = '#00FF00';
      ctx.fillRect(0, 0, width, height);
    } else if (backgroundMode === 'black') {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);
    }
  }, [resolvedWidth, resolvedHeight, backgroundMode, isAudioOnly]);

  // Throttled animation loop for smooth playback sync without CPU jank
  const lastAnimUpdateRef = useRef<number>(0);
  useEffect(() => {
    let animId: number;
    const loop = () => {
      if (videoElementRef.current && isPlaying) {
        const now = performance.now();
        if (now - lastAnimUpdateRef.current > 70) { // ~14 fps React state updates keeps app responsive & silky smooth
          lastAnimUpdateRef.current = now;
          setMonitorTime(videoElementRef.current.currentTime);
        }
      }
      renderOverlay();
      if (isPlaying) {
        animId = requestAnimationFrame(loop);
      }
    };
    renderOverlay();
    if (isPlaying) {
      animId = requestAnimationFrame(loop);
    }
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, renderOverlay]);

  // Step 1 frame backward (1/30th second)
  const stepBackward = () => {
    onSeek(Math.max(0, currentTime - 0.05));
    if (videoElementRef.current) {
      videoElementRef.current.currentTime = Math.max(0, currentTime - 0.05);
    }
  };

  // Step 1 frame forward (1/30th second)
  const stepForward = () => {
    onSeek(Math.min(duration, currentTime + 0.05));
    if (videoElementRef.current) {
      videoElementRef.current.currentTime = Math.min(duration, currentTime + 0.05);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#FAF9F7] border border-[#E5E0D8] select-none text-[#1C1C1E] overflow-hidden font-['Cairo',sans-serif]">
      {/* Top Header Bar: Program: Sequence 01 */}
      <div className="flex flex-wrap items-center justify-between gap-1.5 px-3 py-1.5 bg-[#FAF9F7] border-b border-[#E5E0D8] text-xs">
        {/* Right side in RTL (Program Monitor Tab & Aspect Ratios) */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-transparent border-b-2 border-[#E0532B] text-[#1C1C1E] font-bold text-xs shrink-0">
            <Monitor className="w-3.5 h-3.5 text-[#E0532B]" />
            <span>برنامج المونيتور</span>
            <span className="text-[10.5px] text-[#8D827A] font-normal hidden lg:inline font-sans">(Program Monitor)</span>
          </div>

          {/* Instant Keyword Speech Sync Indicator */}
          <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-[#FDF2EC] border border-[#FED7AA] text-[10px] text-[#C2410C] font-semibold" title="الظهور الفوري للكلمات والمصطلحات البارزة أول ما يقولها المتحدث">
            <span className="w-1.5 h-1.5 rounded-full bg-[#E0532B]" />
            <span>ظهور التلقائيات</span>
          </div>

          {/* Video Aspect Ratio Switcher */}
          <div className="flex items-center bg-[#EFECE6] p-0.5 rounded-xl border border-[#E5E0D8] text-[11px] shrink-0">
            <button
              onClick={() => setAspectRatio('auto')}
              className={`px-2 py-0.5 rounded-lg transition text-[10.5px] ${
                aspectRatio === 'auto'
                  ? 'bg-white text-[#1C1C1E] font-bold shadow-2xs'
                  : 'text-[#78716C] hover:text-[#1C1C1E]'
              }`}
              title={nativeW > 0 ? `الأبعاد الأصلية: ${nativeW}×${nativeH}` : 'الأبعاد الأصلية للفيديو'}
            >
              تلقائي
            </button>
            <button
              onClick={() => setAspectRatio('9:16')}
              className={`px-2 py-0.5 rounded-lg transition text-[10.5px] ${
                aspectRatio === '9:16'
                  ? 'bg-white text-[#1C1C1E] font-bold shadow-2xs'
                  : 'text-[#78716C] hover:text-[#1C1C1E]'
              }`}
              title="أبعاد ريلز وتيك توك وشورتس (9:16)"
            >
              9:16
            </button>
            <button
              onClick={() => setAspectRatio('16:9')}
              className={`px-2 py-0.5 rounded-lg transition text-[10.5px] ${
                aspectRatio === '16:9'
                  ? 'bg-white text-[#1C1C1E] font-bold shadow-2xs'
                  : 'text-[#78716C] hover:text-[#1C1C1E]'
              }`}
              title="أبعاد يوتيوب وأفقية (16:9)"
            >
              16:9
            </button>
            <button
              onClick={() => setAspectRatio('1:1')}
              className={`px-2 py-0.5 rounded-lg transition text-[10.5px] ${
                aspectRatio === '1:1'
                  ? 'bg-white text-[#1C1C1E] font-bold shadow-2xs'
                  : 'text-[#78716C] hover:text-[#1C1C1E]'
              }`}
              title="أبعاد مربعة (1:1)"
            >
              1:1
            </button>
          </div>
        </div>

        {/* Left side in RTL: Safe Area, Green Screen & Export */}
        <div className="flex items-center gap-1.5 flex-wrap shrink-0">
          {/* Green Screen Chroma Key Button */}
          <button
            onClick={() => {
              if (onToggleGreenScreen) {
                onToggleGreenScreen();
              }
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[11px] font-semibold border transition shadow-2xs ${
              backgroundMode === 'greenscreen' || isAudioOnly
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'text-[#554F47] border-[#E5E0D8] hover:text-emerald-700 bg-white'
            }`}
            title="تفعيل خلفية الشاشة الخضراء (Green Screen Chroma Key #00FF00) لتصدير كابشن مفرغ"
          >
            <span className="w-2 h-2 rounded-full bg-[#16A34A] shadow-xs" />
            <span>شاشة خضراء</span>
          </button>

          <button
            onClick={() => setShowSafeMargins(!showSafeMargins)}
            className={`px-2.5 py-1 rounded-xl text-[10.5px] font-semibold border transition shadow-2xs ${
              showSafeMargins
                ? 'bg-blue-50 text-blue-700 border-blue-300'
                : 'text-[#554F47] border-[#E5E0D8] hover:text-[#1C1C1E] bg-white'
            }`}
            title="حدود الأمان (Safe Margins)"
          >
            Safe Area
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept="video/*,audio/*,.mp4,.mov,.webm,.mp3,.wav,.m4a,.aac,.ogg,.flac"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                onFileUpload(e.target.files[0]);
              }
            }}
          />

          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 px-3 py-1 bg-white hover:bg-[#F3EFEA] text-[#1C1C1E] rounded-xl text-xs font-semibold border border-[#E5E0D8] shadow-2xs transition active:scale-95"
            title="تصدير وحفظ الفيديو مع الكابشن المدمج بجودة عالية"
          >
            <Download className="w-3.5 h-3.5 text-[#E0532B]" />
            <span>تصدير الفيديو (MP4)</span>
          </button>
        </div>
      </div>

      {/* Main Viewport Container */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`flex-1 bg-[#F6F5F3] flex items-center justify-center relative overflow-hidden min-h-[260px] p-3 w-full h-full transition-colors ${
          isDraggingOver ? 'bg-[#FDF2EC]/60' : ''
        }`}
      >
        {videoSrc ? (
          <div
            className="relative flex items-center justify-center overflow-hidden transition-all duration-200 shadow-xl rounded-2xl border border-[#E5E0D8]"
            style={{
              aspectRatio: resolvedRatioStr,
              maxWidth: '100%',
              maxHeight: '100%',
              width: resolvedRatioNum < 1 ? 'auto' : '100%',
              height: resolvedRatioNum < 1 ? '100%' : 'auto',
              backgroundColor: backgroundMode === 'greenscreen' || isAudioOnly ? '#00FF00' : '#1C1C1E',
            }}
          >
            {/* Green Screen Background layer if audio only or green screen mode enabled */}
            {(backgroundMode === 'greenscreen' || isAudioOnly) && (
              <div className="absolute inset-0 bg-[#00FF00] z-0 pointer-events-none" />
            )}

            {/* The Video Element */}
            <video
              ref={videoElementRef}
              src={videoSrc}
              playsInline
              crossOrigin={
                videoSrc && !videoSrc.startsWith('blob:') && !videoSrc.startsWith('data:')
                  ? 'anonymous'
                  : undefined
              }
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onSeeked={renderOverlay}
              onSeeking={renderOverlay}
              onPlay={renderOverlay}
              onPause={renderOverlay}
              onClick={onPlayPause}
              onError={handleVideoError}
              className={`w-full h-full object-contain cursor-pointer select-none relative z-10 ${
                isAudioOnly || backgroundMode === 'greenscreen' ? 'opacity-0' : ''
              }`}
            />

            {/* Error Fallback Banner if source fails */}
            {loadError && (
              <div className="absolute inset-0 bg-slate-950/90 z-20 flex flex-col items-center justify-center p-6 text-center text-slate-300">
                <AlertCircle className="w-10 h-10 text-amber-400 mb-2" />
                <p className="text-sm font-semibold mb-3">{loadError}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg transition"
                  >
                    رفع ملف جديد من جهازي
                  </button>
                </div>
              </div>
            )}

            {/* Subtitle Canvas Overlay (z-20: Always in front of video) */}
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full pointer-events-none object-contain z-20"
            />

            {/* Guaranteed-Visible Real-Time Subtitle Overlay (HTML/CSS z-30: Crisp, clean text, natural Arabic ligatures, no excessive black) */}
            {activeSeg && (() => {
              const isArabicText = /[\u0600-\u06FF]/.test(activeSeg.text);
              // Balanced proportional font size so text never overflows the frame or looks excessively giant
              const previewFontSize = resolvedRatioNum < 1
                ? Math.min(18, Math.max(12, Math.round((activePreset.fontSize || 42) * 0.32)))
                : Math.min(20, Math.max(13, Math.round((activePreset.fontSize || 42) * 0.35)));

              return (
                <div
                  className="absolute inset-x-0 pointer-events-none z-30 flex flex-col items-center justify-center px-4 transition-all duration-75 select-none"
                  style={{
                    top: `${activePreset.positionY || 76}%`,
                    transform: 'translateY(-50%)',
                  }}
                >
                  <div
                    className="flex flex-wrap items-center justify-center gap-x-1.5 gap-y-1 text-center max-w-[85%] transition-all"
                    dir={isArabicText ? 'rtl' : 'ltr'}
                    style={{
                      fontFamily: isArabicText
                        ? "'Tajawal', 'Cairo', 'Almarai', sans-serif"
                        : (activePreset.fontFamily || 'Montserrat, sans-serif'),
                      fontWeight: activePreset.fontWeight || '800',
                      fontSize: `${previewFontSize}px`,
                      lineHeight: 1.35,
                      letterSpacing: 'normal',
                      wordBreak: 'break-word',
                      overflowWrap: 'break-word',
                      textTransform: isArabicText ? 'none' : (activePreset.textTransform || 'none'),
                      backgroundColor:
                        activePreset.backgroundColor && activePreset.backgroundColor !== 'transparent'
                          ? activePreset.backgroundColor
                          : undefined,
                      padding:
                        activePreset.backgroundColor && activePreset.backgroundColor !== 'transparent'
                          ? `${Math.max(4, (activePreset.backgroundPadding || 8) * 0.5)}px ${Math.max(8, (activePreset.backgroundPadding || 8) * 1.0)}px`
                          : undefined,
                      borderRadius: `${activePreset.backgroundRadius || 8}px`,
                    }}
                  >
                    {(() => {
                      const words = activeSeg.text.trim().split(/\s+/).filter(Boolean);
                      const totalWords = words.length;
                      const segDuration = Math.max(0.1, activeSeg.end - activeSeg.start);

                      return words.map((word, wIdx) => {
                        const cleanWord = word.replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '').toLowerCase();
                        const isKeyword = activeSeg.highlightKeywords?.some(
                          (kw) => kw.word.trim().replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '').toLowerCase() === cleanWord
                        );
                        const kwMatch = activeSeg.highlightKeywords?.find(
                          (kw) => kw.word.trim().replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '').toLowerCase() === cleanWord
                        );
                        const color = isKeyword ? (kwMatch?.color || activePreset.keywordColor || '#FFE600') : (activePreset.textColor || '#FFFFFF');

                        // Word-level speech sync: exact moment the speaker speaks this word
                        const wordStart = activeSeg.words?.[wIdx]?.start ?? (activeSeg.start + (wIdx / totalWords) * segDuration);
                        const wordEnd = activeSeg.words?.[wIdx]?.end ?? (wordStart + segDuration / totalWords);

                        // Strict speech onset with slight natural auditory lead (-0.06s) for instant sync
                        const hasBeenSpoken = effectiveTime >= (wordStart - 0.06);
                        const isCurrentlySpoken = effectiveTime >= (wordStart - 0.06) && effectiveTime <= wordEnd;
                        const timeSinceSpoken = effectiveTime - wordStart;

                        // Burst pop moment: within first 0.38s of speech onset
                        const isSpeechBurst = hasBeenSpoken && timeSinceSpoken >= -0.06 && timeSinceSpoken < 0.38;

                        // Dynamic scale: prominent keywords pop instantly and vigorously when spoken!
                        let scale = 1;
                        if (isKeyword) {
                          if (isSpeechBurst) {
                            scale = 1.32; // Snappy instant speech pop for prominent keywords!
                          } else if (hasBeenSpoken) {
                            scale = 1.08;
                          } else {
                            scale = 0.92;
                          }
                        } else if (isCurrentlySpoken && (activePreset.animation === 'pop' || activePreset.animation === 'karaoke')) {
                          scale = 1.14;
                        }

                        // Opacity in live speech sync: unspoken words fade so prominent terms pop in immediately on speech!
                        const opacity = hasBeenSpoken || !isPlaying ? 1 : 0.15;

                        return (
                          <span
                            key={wIdx}
                            className={`inline-block transition-all duration-75 ${
                              isSpeechBurst && isKeyword ? 'animate-keyword-burst' : ''
                            }`}
                            style={{
                              color,
                              opacity,
                              transform: `scale(${scale})`,
                              letterSpacing: 'normal',
                              paintOrder: 'stroke fill',
                              WebkitTextStroke:
                                activePreset.strokeWidth > 0
                                  ? `${isArabicText ? '1px' : '1.2px'} ${activePreset.strokeColor && activePreset.strokeColor !== '#000000' ? activePreset.strokeColor : '#0B1120'}`
                                  : '0.6px #0B1120',
                              textShadow: isKeyword
                                ? `0 0 14px ${color}95, 0 2px 5px rgba(11, 17, 32, 0.95)`
                                : '0 1px 3px rgba(11, 17, 32, 0.85)',
                              backgroundColor: isKeyword && activePreset.keywordBgColor ? activePreset.keywordBgColor : undefined,
                              padding: isKeyword && activePreset.keywordBgColor ? '1px 6px' : undefined,
                              borderRadius: isKeyword && activePreset.keywordBgColor ? '4px' : undefined,
                            }}
                          >
                            {word}
                          </span>
                        );
                      });
                    })()}
                  </div>
                </div>
              );
            })()}

            {/* Safe Margins Overlay */}
            {showSafeMargins && (
              <div className="absolute inset-4 pointer-events-none border border-cyan-400/40 rounded-sm z-30">
                <div className="absolute inset-4 border border-cyan-400/20" />
              </div>
            )}
          </div>
        ) : (
          <div
            className={`w-full max-w-md bg-white rounded-3xl border-2 transition-all duration-200 p-8 text-center my-auto flex flex-col items-center justify-center shadow-[0_4px_20px_rgba(0,0,0,0.03)] ${
              isDraggingOver
                ? 'border-[#E0532B] bg-[#FDF2EC]/40 scale-[1.02]'
                : 'border-[#E5E0D8] hover:border-[#D5CFBF]'
            }`}
          >
            {/* Elegant Upload Icon Badge */}
            <div className="relative mb-4">
              <div className="w-16 h-16 rounded-2xl bg-[#FDF2EC] border border-[#FED7AA] flex items-center justify-center text-[#E0532B] shadow-xs">
                <Upload className="w-7 h-7 text-[#E0532B]" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#E0532B]/15 flex items-center justify-center">
                <Sparkles className="w-2.5 h-2.5 text-[#E0532B]" />
              </div>
            </div>

            {/* Large readable title */}
            <h3 className="text-base sm:text-lg font-bold text-[#1C1C1E] mb-2 font-semibold">
              {t.dragDropTitle}
            </h3>

            {/* Clean supporting text */}
            <p className="text-xs text-[#78716C] mb-6 leading-relaxed max-w-xs font-normal">
              {t.dragDropSub}
            </p>

            {/* Primary Action Button: Vibrant modern orange (#E0532B) centered underneath */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-[#E0532B] hover:bg-[#C9431E] rounded-xl shadow-sm hover:shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{t.chooseFileBtn} 📁</span>
            </button>
          </div>
        )}
      </div>

      {/* Premiere Transport Toolbar (Bottom Bar of Program Monitor) - Light SaaS Theme matching image.png */}
      <div className="min-h-[48px] py-1.5 bg-[#FAF9F7] border-t border-[#E5E0D8] flex flex-wrap items-center justify-between px-3 text-xs gap-2 shrink-0 select-none">
        {/* Left: Volume, Delete [A], Merge [M], Undo/Redo */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1 text-[#8D827A] text-[10px] font-mono">
            <span>1/2</span>
            <button
              onClick={() => {
                if (videoElementRef.current) {
                  videoElementRef.current.muted = !isMuted;
                  setIsMuted(!isMuted);
                }
              }}
              className="p-1 text-[#78716C] hover:text-[#1C1C1E]"
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-500" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Delete [A] Button */}
          <button
            onClick={onDeleteSelected}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#FDECEE] text-[#BE123C] border border-[#FECDD3] text-[11px] font-bold hover:bg-[#FCD9DF] transition shadow-2xs"
            title="حذف الكابشن أو الجزء المحدد (اختصار Del أو A)"
          >
            <Trash2 className="w-3 h-3" />
            <span>حذف [A]</span>
          </button>

          {/* Merge [M] Button */}
          {onMergeVideoCuts && (
            <button
              onClick={onMergeVideoCuts}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#FEF3EC] text-[#C2410C] border border-[#FED7AA] text-[11px] font-bold hover:bg-[#FDE7D9] transition shadow-2xs"
              title="تجميع ودمج أجزاء الفيديو (اختصار M)"
            >
              <Layers className="w-3 h-3 text-[#EA580C]" />
              <span>تجميع [M]</span>
            </button>
          )}

          {/* Rotate / Frame step */}
          <button
            onClick={stepBackward}
            className="p-1.5 rounded-lg bg-white border border-[#E5E0D8] text-[#554F47] hover:text-[#1C1C1E] transition shadow-2xs"
            title="الرجوع إطار واحد للخلف"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
          <button
            onClick={stepForward}
            className="p-1.5 rounded-lg bg-white border border-[#E5E0D8] text-[#554F47] hover:text-[#1C1C1E] transition shadow-2xs"
            title="التقدم إطار واحد للأمام"
          >
            <RotateCw className="w-3 h-3" />
          </button>
        </div>

        {/* Center: Vibrant Orange Circular Play/Pause Button */}
        <div className="flex items-center justify-center">
          <button
            onClick={onPlayPause}
            className="w-10 h-10 rounded-full bg-[#E0532B] hover:bg-[#C9431E] text-white flex items-center justify-center shadow-md shadow-orange-500/25 transition active:scale-95 cursor-pointer"
            title="تشغيل / إيقاف (مسافة Space)"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>
        </div>

        {/* Right: Timecode Display */}
        <div className="flex items-center gap-2 shrink-0">
          <span
            className="font-mono font-bold text-xs text-[#1C1C1E] bg-white px-3 py-1.5 rounded-lg border border-[#E5E0D8] shadow-2xs tracking-wider"
            dir="ltr"
          >
            {formatTimecodePremiere(currentTime)}
          </span>
        </div>
      </div>
    </div>
  );
};
