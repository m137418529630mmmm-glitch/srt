import React, { useState, useRef, useEffect } from 'react';
import { SubtitleSegment, SubtitleStylePreset, CaptionVisibilityRange } from '../types';
import { X, Film, Download, CheckCircle2, AlertCircle, Loader2, Sparkles, RefreshCw, Scissors, Clock } from 'lucide-react';
import {
  exportVideoWithBurnedSubtitles,
  exportVideoWithFFmpegServer,
  probeVideoMetadata,
  ExportQualityPreset,
  VideoMetadata,
} from '../utils/videoRenderer';
import { formatTimeDisplay } from '../utils/srt';

import { Language, translations } from '../utils/translations';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoElement: HTMLVideoElement | null;
  videoFile?: File | null;
  segments: SubtitleSegment[];
  activePreset: SubtitleStylePreset;
  duration?: number;
  captionVisibilityRange?: CaptionVisibilityRange;
  isAudioOnly?: boolean;
  initialBackgroundMode?: 'video' | 'greenscreen' | 'black';
  lang?: Language;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  videoElement,
  videoFile,
  segments,
  activePreset,
  duration: appDuration = 0,
  captionVisibilityRange,
  isAudioOnly = false,
  initialBackgroundMode = 'video',
  lang = 'en',
}) => {
  const t = translations[lang];
  const [isRendering, setIsRendering] = useState(false);
  const [progress, setProgress] = useState(0);
  const [renderTime, setRenderTime] = useState(0);
  const [renderedUrl, setRenderedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Quality & Render Engine Options
  const [quality, setQuality] = useState<ExportQualityPreset>('high');
  const [renderEngine, setRenderEngine] = useState<'webcodecs' | 'ffmpeg'>('webcodecs');
  const [detectedMeta, setDetectedMeta] = useState<VideoMetadata | null>(null);

  // Background Mode for render (Green Screen Chroma Key #00FF00 / Original Video / Black)
  const [exportBackground, setExportBackground] = useState<'video' | 'greenscreen' | 'black'>(() => {
    return isAudioOnly || !videoElement?.videoWidth ? 'greenscreen' : initialBackgroundMode;
  });

  // Calculate true video duration securely (handles Infinity, NaN, and Blob URLs)
  const computedSegmentsEnd = segments.length > 0 ? Math.max(...segments.map((s) => s.end)) : 0;
  const duration =
    appDuration > 0 && isFinite(appDuration)
      ? appDuration
      : videoElement?.duration && isFinite(videoElement.duration) && videoElement.duration > 0
      ? videoElement.duration
      : computedSegmentsEnd > 0
      ? computedSegmentsEnd
      : 10;
  const [renderMode, setRenderMode] = useState<'full' | 'custom'>('full');
  const [customStart, setCustomStart] = useState<number>(0);
  const [customEnd, setCustomEnd] = useState<number>(duration);

  const abortControllerRef = useRef<AbortController | null>(null);

  const [renderStats, setRenderStats] = useState<{ currentFrame: number; totalFrames: number; fps: number } | null>(null);

  useEffect(() => {
    if (duration > 0 && customEnd === 0) {
      setCustomEnd(duration);
    }
  }, [duration, customEnd]);

  useEffect(() => {
    if (isOpen && videoElement) {
      probeVideoMetadata(videoElement, videoFile)
        .then((m) => {
          setDetectedMeta(m);
        })
        .catch(() => {});
    }
  }, [isOpen, videoElement, videoFile]);

  if (!isOpen) return null;

  const width = detectedMeta?.width || videoElement?.videoWidth || 1080;
  const height = detectedMeta?.height || videoElement?.videoHeight || 1920;

  const effectiveStart = renderMode === 'full' ? 0 : Math.max(0, Math.min(customStart, duration));
  const effectiveEnd = renderMode === 'full' ? duration : Math.max(effectiveStart + 0.5, Math.min(customEnd, duration));
  const effectiveDuration = Math.max(0.1, effectiveEnd - effectiveStart);

  const handleStartRender = async () => {
    if (!videoElement) {
      setError('لا يوجد فيديو محدد');
      return;
    }

    setIsRendering(true);
    setProgress(0);
    setError(null);
    setRenderedUrl(null);
    setRenderStats(null);

    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    try {
      let url: string;
      if (renderEngine === 'ffmpeg') {
        url = await exportVideoWithFFmpegServer({
          videoElement,
          videoFile,
          segments,
          preset: activePreset,
          signal: abortController.signal,
          backgroundMode: exportBackground === 'greenscreen' ? 'greenscreen' : exportBackground === 'black' ? 'black' : 'video',
          renderRange: {
            startTime: effectiveStart,
            endTime: effectiveEnd,
          },
          crf: quality === 'ultra' ? 17 : quality === 'high' ? 19 : quality === 'balanced' ? 23 : 26,
          onProgress: (p, cur) => {
            setProgress(Math.round(p));
            setRenderTime(cur);
          },
        });
      } else {
        url = await exportVideoWithBurnedSubtitles({
          videoElement,
          videoFile,
          segments,
          preset: activePreset,
          signal: abortController.signal,
          captionVisibilityRange,
          backgroundMode: exportBackground,
          quality,
          fps: detectedMeta?.fps,
          renderRange: {
            startTime: effectiveStart,
            endTime: effectiveEnd,
          },
          onProgress: (p: number, cur: number, _dur: number, stats?: { currentFrame: number; totalFrames: number; fps: number }) => {
            setProgress(Math.round(p));
            setRenderTime(cur);
            if (stats) setRenderStats(stats);
          },
        });
      }

      setRenderedUrl(url);
      setProgress(100);
    } catch (err: any) {
      if (err.message !== 'Export cancelled by user') {
        console.error('Rendering error:', err);
        setError(err.message || 'حدث خطأ أثناء رندر الفيديو');
      }
    } finally {
      setIsRendering(false);
      abortControllerRef.current = null;
    }
  };

  const handleCancelRender = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsRendering(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white border border-[#E5E0D8] rounded-2xl shadow-2xl p-6 text-[#1C1C1E] max-h-[90vh] overflow-y-auto font-['Cairo',sans-serif]">
        <button
          onClick={() => {
            if (isRendering) handleCancelRender();
            onClose();
          }}
          className="absolute top-4 left-4 p-2 text-[#78716C] hover:text-[#1C1C1E] rounded-xl hover:bg-[#F3EFEA] transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 bg-[#FDF2EC] text-[#E0532B] rounded-2xl border border-[#FED7AA] shadow-2xs">
            <Film className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-[#1C1C1E]">رندر وحرق الكابشن وتنزيل الفيديو (MP4)</h2>
            <p className="text-xs text-[#78716C]">
              توليد ملف فيديو أصلي عالي الدقة مع دمج الكابشن والتأثيرات والصوت المتزامن
            </p>
          </div>
        </div>

        {/* Video Specs Card */}
        <div className="bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl p-3.5 mb-4 grid grid-cols-4 gap-2.5 text-center text-xs">
          <div className="p-2.5 bg-white rounded-lg border border-[#E5E0D8] shadow-2xs">
            <span className="text-[#78716C] block text-[10.5px] mb-0.5">الدقة الأصلية</span>
            <span className="font-mono font-bold text-[#1C1C1E] text-[12px]" dir="ltr">{width} x {height}</span>
          </div>
          <div className="p-2.5 bg-white rounded-lg border border-[#E5E0D8] shadow-2xs">
            <span className="text-[#78716C] block text-[10.5px] mb-0.5">معدل الإطارات</span>
            <span className="font-mono font-bold text-[#2563EB] text-[12px]" dir="ltr">
              {detectedMeta?.fps ? `${detectedMeta.fps} FPS` : '30 FPS'}
            </span>
          </div>
          <div className="p-2.5 bg-white rounded-lg border border-[#E5E0D8] shadow-2xs">
            <span className="text-[#78716C] block text-[10.5px] mb-0.5">مدة الرندر</span>
            <span className="font-mono font-bold text-[#0D9488] text-[12px]" dir="ltr">{formatTimeDisplay(effectiveDuration)}</span>
          </div>
          <div className="p-2.5 bg-white rounded-lg border border-[#E5E0D8] shadow-2xs">
            <span className="text-[#78716C] block text-[10.5px] mb-0.5">قالب الستايل</span>
            <span className="font-bold text-[#E0532B] text-[11px] truncate block">{activePreset.nameAr}</span>
          </div>
        </div>

        {/* Quality and Engine Selector */}
        {!isRendering && !renderedUrl && (
          <div className="bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl p-3.5 mb-4 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#1C1C1E] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#E0532B]" />
                <span>جودة الرندر ومحرك التصدير (Render Profile):</span>
              </span>
              <div className="flex bg-white p-0.5 rounded-lg border border-[#E5E0D8] shadow-2xs">
                <button
                  type="button"
                  onClick={() => setRenderEngine('webcodecs')}
                  className={`px-2.5 py-1 rounded-md text-[10.5px] transition font-medium ${
                    renderEngine === 'webcodecs'
                      ? 'bg-[#E0532B] text-white font-bold shadow-2xs'
                      : 'text-[#78716C] hover:text-[#1C1C1E]'
                  }`}
                >
                  ⚡ سريع GPU (WebCodecs)
                </button>
                <button
                  type="button"
                  onClick={() => setRenderEngine('ffmpeg')}
                  className={`px-2.5 py-1 rounded-md text-[10.5px] transition font-medium ${
                    renderEngine === 'ffmpeg'
                      ? 'bg-[#E0532B] text-white font-bold shadow-2xs'
                      : 'text-[#78716C] hover:text-[#1C1C1E]'
                  }`}
                >
                  🎬 ستوديو (FFmpeg)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center">
              {[
                { id: 'ultra', label: 'فائقة (Ultra)', desc: 'CRF 17 / أقصى وضوح' },
                { id: 'high', label: 'عالية (High)', desc: 'CRF 20 / يوتيوب وماستر' },
                { id: 'balanced', label: 'متوازنة', desc: 'CRF 23 / سوشيال ميديا' },
                { id: 'compact', label: 'مضغوطة', desc: 'حجم ملف صغير' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setQuality(opt.id as ExportQualityPreset)}
                  className={`p-2 rounded-xl border text-center transition flex flex-col justify-between ${
                    quality === opt.id
                      ? 'bg-[#FDF2EC] border-[#FED7AA] text-[#C2410C] font-bold shadow-xs'
                      : 'bg-white border-[#E5E0D8] text-[#554F47] hover:bg-[#F3EFEA]'
                  }`}
                >
                  <span className="text-[11px] block">{opt.label}</span>
                  <span className="text-[9.5px] text-[#78716C] mt-0.5">{opt.desc}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Background Mode Selector */}
        {!isRendering && !renderedUrl && (
          <div className="bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl p-3.5 mb-4 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#1C1C1E] flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-[#00FF00] shadow-xs inline-block border border-[#86EFAC]" />
                <span>خلفية الرندر والتصدير (Background):</span>
              </span>
              {isAudioOnly && (
                <span className="text-[10px] bg-[#CCFBF1] text-[#0F766E] px-2 py-0.5 rounded-md border border-[#99F6E4] font-bold">
                  ملف صوت فقط (تلقائي شاشة خضراء)
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Option 1: Green Screen */}
              <button
                type="button"
                onClick={() => setExportBackground('greenscreen')}
                className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                  exportBackground === 'greenscreen'
                    ? 'bg-[#F0FDF4] border-[#22C55E] ring-1 ring-[#22C55E] text-[#15803D] shadow-xs'
                    : 'bg-white border-[#E5E0D8] text-[#554F47] hover:bg-[#F3EFEA]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="w-4 h-4 rounded-full bg-[#00FF00] border border-[#86EFAC] shadow-xs" />
                  <span className="text-[10px] font-mono text-[#16A34A] font-bold">#00FF00</span>
                </div>
                <span className="font-bold text-xs block text-[#15803D]">شاشة خضراء 🟢</span>
                <span className="text-[10px] text-[#78716C] mt-0.5">مخصص لبريمير برو وداڤينشي (Ultra Key)</span>
              </button>

              {/* Option 2: Original Video */}
              <button
                type="button"
                disabled={isAudioOnly || !videoElement?.videoWidth}
                onClick={() => setExportBackground('video')}
                className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                  isAudioOnly || !videoElement?.videoWidth
                    ? 'opacity-40 cursor-not-allowed border-[#E5E0D8] bg-[#F6F5F3]'
                    : exportBackground === 'video'
                    ? 'bg-[#EFF6FF] border-[#3B82F6] ring-1 ring-[#3B82F6] text-[#1D4ED8] shadow-xs'
                    : 'bg-white border-[#E5E0D8] text-[#554F47] hover:bg-[#F3EFEA]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <Film className="w-4 h-4 text-[#2563EB]" />
                  <span className="text-[10px] font-bold text-[#2563EB]">MP4</span>
                </div>
                <span className="font-bold text-xs block text-[#1D4ED8]">فيديو الأصل 🎬</span>
                <span className="text-[10px] text-[#78716C] mt-0.5">حرق الكابشن فوق الفيديو الأصلي</span>
              </button>

              {/* Option 3: Studio Charcoal/Black */}
              <button
                type="button"
                onClick={() => setExportBackground('black')}
                className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                  exportBackground === 'black'
                    ? 'bg-[#F4F4F5] border-[#52525B] ring-1 ring-[#52525B] text-[#18181B] shadow-xs'
                    : 'bg-white border-[#E5E0D8] text-[#554F47] hover:bg-[#F3EFEA]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="w-4 h-4 rounded-full bg-[#18181B] border border-[#71717A] shadow-xs" />
                  <span className="text-[10px] font-mono text-[#52525B]">#000000</span>
                </div>
                <span className="font-bold text-xs block text-[#18181B]">خلفية ستوديو ⚫</span>
                <span className="text-[10px] text-[#78716C] mt-0.5">استوديو داكن نقي</span>
              </button>
            </div>
          </div>
        )}

        {/* Render Range Selector */}
        {!isRendering && !renderedUrl && (
          <div className="bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl p-3.5 mb-4 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#1C1C1E] flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5 text-[#E0532B]" />
                <span>تحديد المقطع المراد رندره (Render Range):</span>
              </span>
              <div className="flex bg-white p-0.5 rounded-lg border border-[#E5E0D8] shadow-2xs">
                <button
                  type="button"
                  onClick={() => setRenderMode('full')}
                  className={`px-2.5 py-1 rounded-md text-[11px] transition font-medium ${
                    renderMode === 'full'
                      ? 'bg-[#E0532B] text-white font-bold shadow-2xs'
                      : 'text-[#78716C] hover:text-[#1C1C1E]'
                  }`}
                >
                  كامل الفيديو
                </button>
                <button
                  type="button"
                  onClick={() => setRenderMode('custom')}
                  className={`px-2.5 py-1 rounded-md text-[11px] transition font-medium ${
                    renderMode === 'custom'
                      ? 'bg-[#E0532B] text-white font-bold shadow-2xs'
                      : 'text-[#78716C] hover:text-[#1C1C1E]'
                  }`}
                >
                  قص مقطع محدد
                </button>
              </div>
            </div>

            {renderMode === 'custom' && (
              <div className="p-3 bg-white border border-[#E5E0D8] rounded-xl space-y-2.5 shadow-2xs">
                {/* Quick Trim Presets */}
                <div className="flex items-center gap-1.5 flex-wrap pb-2 border-b border-[#F3EFEA]">
                  <span className="text-[10.5px] text-[#78716C]">خيارات سريعة:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomStart(0);
                      setCustomEnd(Math.min(duration, 30));
                    }}
                    className="px-2 py-0.5 rounded-md bg-[#FAF9F7] hover:bg-[#F3EFEA] border border-[#E5E0D8] text-[#1C1C1E] text-[10.5px] transition"
                  >
                    أول 30 ثانية (Reels)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomStart(0);
                      setCustomEnd(Math.min(duration, 60));
                    }}
                    className="px-2 py-0.5 rounded-md bg-[#FAF9F7] hover:bg-[#F3EFEA] border border-[#E5E0D8] text-[#1C1C1E] text-[10.5px] transition"
                  >
                    أول دقيقة (01:00)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomStart(0);
                      setCustomEnd(duration);
                    }}
                    className="px-2 py-0.5 rounded-md bg-[#FDF2EC] border border-[#FED7AA] text-[#C2410C] font-bold text-[10.5px] transition"
                  >
                    كامل الفيديو ({duration.toFixed(0)} ثانية) ✨
                  </button>
                  {captionVisibilityRange?.enabled && (
                    <button
                      type="button"
                      onClick={() => {
                        setCustomStart(captionVisibilityRange.startTime);
                        setCustomEnd(Math.min(duration, captionVisibilityRange.endTime));
                      }}
                      className="px-2 py-0.5 rounded-md bg-[#EFF6FF] border border-[#BFDBFE] text-[#1D4ED8] text-[10.5px] transition font-bold"
                    >
                      مطابقة نطاق الكابشن
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3 text-center">
                  <div>
                    <span className="text-[11px] text-[#78716C] block mb-1">من (بداية الرندر بالثواني):</span>
                    <input
                      type="number"
                      min={0}
                      max={customEnd - 0.5}
                      step={0.5}
                      value={customStart}
                      onChange={(e) => setCustomStart(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-lg px-2 py-1 text-center font-mono text-[#1C1C1E] text-xs focus:outline-none focus:border-[#E0532B]"
                    />
                    <span className="text-[10.5px] text-[#78716C] mt-1 block font-mono bg-[#FAF9F7] py-0.5 rounded" dir="ltr">
                      {formatTimeDisplay(customStart)}
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] text-[#78716C] block mb-1">إلى (نهاية الرندر بالثواني):</span>
                    <input
                      type="number"
                      min={customStart + 0.5}
                      max={duration}
                      step={0.5}
                      value={customEnd}
                      onChange={(e) => setCustomEnd(Math.min(duration, parseFloat(e.target.value) || duration))}
                      className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-lg px-2 py-1 text-center font-mono text-[#1C1C1E] text-xs focus:outline-none focus:border-[#E0532B]"
                    />
                    <span className="text-[10.5px] text-[#78716C] mt-1 block font-mono bg-[#FAF9F7] py-0.5 rounded" dir="ltr">
                      {formatTimeDisplay(customEnd)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-[#78716C] pt-1 border-t border-[#F3EFEA]">
                  <span>مدة المقطع المحدد للرندر والتنزيل:</span>
                  <span className="font-mono font-bold text-[#E0532B] text-xs" dir="ltr">
                    {formatTimeDisplay(effectiveDuration)}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Error Notice */}
        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
            <span>{error}</span>
          </div>
        )}

        {/* Render Progress or Success */}
        {isRendering ? (
          <div className="p-6 bg-[#FAF9F7] border border-[#E5E0D8] rounded-2xl text-center space-y-4 shadow-2xs">
            <div className="flex items-center justify-center gap-2 text-[#E0532B] font-bold text-sm">
              <Loader2 className="w-5 h-5 animate-spin text-[#E0532B]" />
              <span>جاري رندر إطارات الفيديو أوفلاين بسرعة وسلاسة (MP4)...</span>
            </div>

            {/* Progress Bar with vibrant orange accent */}
            <div className="w-full bg-[#E5E0D8] rounded-full h-3 overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#E0532B] to-[#F97316] h-full rounded-full transition-all duration-150"
                style={{ width: `${progress}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-[#78716C] font-mono" dir="ltr">
              <span className="text-[#E0532B] font-bold">{progress}%</span>
              <span>{formatTimeDisplay(renderTime)} / {formatTimeDisplay(effectiveDuration)}</span>
            </div>

            {renderStats && (
              <div className="flex items-center justify-between px-3 py-2 bg-white rounded-xl border border-[#E5E0D8] text-[11px] text-[#554F47] font-mono shadow-2xs">
                <span>الإطار: <strong className="text-[#1C1C1E]">{renderStats.currentFrame} / {renderStats.totalFrames}</strong></span>
                <span>السرعة: <strong className="text-[#0D9488]">{renderStats.fps} FPS</strong></span>
              </div>
            )}

            <button
              onClick={handleCancelRender}
              className="text-xs text-[#78716C] hover:text-rose-600 underline pt-1 transition cursor-pointer"
            >
              إلغاء العملية
            </button>
          </div>
        ) : renderedUrl ? (
          /* Rendered Video Ready */
          <div className="p-4 bg-[#F0FDF4] border border-[#86EFAC] rounded-2xl space-y-4 shadow-2xs">
            <div className="flex items-center gap-2 text-[#15803D] font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-[#22C55E]" />
              <span>Done ✓ تم رندر الفيديو وحرق الكابشن بنجاح!</span>
            </div>

            <div className="rounded-xl overflow-hidden bg-[#18181B] max-h-56 flex items-center justify-center border border-[#E5E0D8] shadow-inner">
              <video
                src={renderedUrl}
                controls
                autoPlay
                className="max-h-56 max-w-full object-contain"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <button
                onClick={handleStartRender}
                className="flex items-center gap-1.5 text-xs text-[#554F47] hover:text-[#1C1C1E] px-3.5 py-2 rounded-xl bg-white border border-[#E5E0D8] hover:bg-[#FAF9F7] transition shadow-2xs font-semibold"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>إعادة الرندر</span>
              </button>

              <a
                href={renderedUrl}
                download="video_with_subtitles.mp4"
                className="flex items-center gap-2 px-6 py-2.5 text-sm font-bold text-white bg-[#E0532B] hover:bg-[#C8441F] rounded-xl shadow-md transition active:scale-95 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل الفيديو (MP4)</span>
              </a>
            </div>
          </div>
        ) : (
          /* Ready to render call-to-action */
          <div className="space-y-4">
            <div className="p-4 bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl text-xs text-[#554F47] leading-relaxed space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[#E0532B] font-bold">
                  <Sparkles className="w-4 h-4" />
                  <span>مواصفات الرندر الأصلي:</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-[#FDF2EC] text-[#C2410C] border border-[#FED7AA] font-mono text-[10px] font-bold">
                  MP4 / 18 Mbps High Bitrate
                </span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-[#78716C] pr-2">
                <li>حرق الكابشن بدقة 100% مطابقة لأبعاد الفيديو الأصلي ({width}x{height})</li>
                <li>تصدير بصيغة MP4 المتوافقة مع جميع منصات التواصل (تيك توك، إنستغرام، يوتيوب، فيسبوك)</li>
                <li>الحفاظ الكامل على نقاء الصوت الأصلي المتزامن بدقة عالية</li>
                <li>إخفاء الكابشن تلقائياً عند فترات الصمت لتجنب بقاء آخر كلمة معلقة</li>
              </ul>
            </div>

            <button
              onClick={handleStartRender}
              className="w-full flex items-center justify-center gap-2 py-3 px-6 text-sm font-bold text-white bg-[#E0532B] hover:bg-[#C8441F] rounded-xl shadow-md transition active:scale-98 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>تصدير الفيديو (MP4)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
