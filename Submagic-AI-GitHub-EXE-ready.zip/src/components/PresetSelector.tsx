import React, { useState } from 'react';
import { SUBTITLE_PRESETS, PRESET_CATEGORIES } from '../constants/presets';
import { SubtitleStylePreset } from '../types';
import { Sparkles, Sliders, Search } from 'lucide-react';

interface PresetSelectorProps {
  selectedPreset: SubtitleStylePreset;
  onSelectPreset: (preset: SubtitleStylePreset) => void;
  showCustomizer: boolean;
  onToggleCustomizer: () => void;
}

export const PresetSelector: React.FC<PresetSelectorProps> = ({
  selectedPreset,
  onSelectPreset,
  showCustomizer,
  onToggleCustomizer,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredPresets = SUBTITLE_PRESETS.filter((preset) => {
    const matchesCategory =
      selectedCategory === 'all' || preset.category === selectedCategory;
    const matchesSearch =
      preset.nameAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      preset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      preset.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-white border border-[#E5E0D8] rounded-2xl p-4 shadow-2xs space-y-3.5">
      {/* Header and Toggle */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#E0532B]" />
          <h3 className="font-bold text-sm text-[#1C1C1E] font-['Cairo',sans-serif]">
            مكتبة قوالب الكابشن الاحترافية (30 قالباً)
          </h3>
        </div>
        <button
          onClick={onToggleCustomizer}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition shadow-2xs ${
            showCustomizer
              ? 'bg-[#F4F1FA] text-[#6B21A8] border-[#DDD6FE]'
              : 'bg-[#FAF9F7] text-[#554F47] border-[#E5E0D8] hover:text-[#1C1C1E] hover:bg-[#F3EFEA]'
          }`}
        >
          <Sliders className="w-3.5 h-3.5 text-[#9333EA]" />
          <span>{showCustomizer ? 'إخفاء التخصيص' : 'تخصيص يدوي'}</span>
        </button>
      </div>

      {/* Category Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
        {/* Category Pills */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs scrollbar-none">
          {PRESET_CATEGORIES.map((cat) => {
            const isCatActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition text-[11px] ${
                  isCatActive
                    ? 'bg-[#E0532B] text-white font-bold shadow-2xs'
                    : 'bg-[#FAF9F7] text-[#78716C] hover:text-[#1C1C1E] hover:bg-[#F3EFEA] border border-[#E5E0D8]'
                }`}
              >
                {cat.nameAr}
              </button>
            );
          })}
        </div>

        {/* Quick Search */}
        <div className="relative w-full sm:w-44">
          <Search className="w-3.5 h-3.5 text-[#A8A29E] absolute right-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث في القوالب..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#FAF9F7] border border-[#E5E0D8] rounded-xl pr-8 pl-2.5 py-1.5 text-xs text-[#1C1C1E] placeholder-[#A8A29E] focus:outline-none focus:border-[#E0532B] shadow-2xs font-['Cairo',sans-serif]"
          />
        </div>
      </div>

      {/* Preset Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-2.5 max-h-[290px] overflow-y-auto pr-1">
        {filteredPresets.map((preset) => {
          const isSelected = selectedPreset.id === preset.id;
          return (
            <button
              key={preset.id}
              onClick={() => onSelectPreset(preset)}
              className={`group relative text-right p-2.5 rounded-xl border transition-all duration-200 overflow-hidden text-xs flex flex-col justify-between ${
                isSelected
                  ? 'border-[#E0532B] bg-[#FDF2EC] ring-1 ring-[#FED7AA] shadow-xs'
                  : 'border-[#E5E0D8] bg-[#FAF9F7] hover:bg-white hover:border-[#D5CFBF] shadow-2xs'
              }`}
            >
              {/* Visual preview pill */}
              <div
                className={`w-full py-2 px-2 mb-2 rounded-lg bg-white border border-[#E5E0D8] ${preset.previewBgGradient} flex items-center justify-center text-center shadow-2xs`}
              >
                <div
                  style={{
                    fontFamily: preset.fontFamily,
                    fontWeight: preset.fontWeight,
                    color: preset.textColor,
                    textShadow: `0 2px 4px ${preset.shadowColor}`,
                  }}
                  className="truncate text-[12px]"
                >
                  <span>كابشن </span>
                  <span
                    style={{
                      color: preset.keywordColor,
                      backgroundColor: preset.keywordBgColor || 'transparent',
                      padding: preset.keywordBgColor ? '1px 4px' : '0',
                      borderRadius: preset.keywordBgColor ? '4px' : '0',
                    }}
                  >
                    خرافي
                  </span>
                </div>
              </div>

              <div>
                <div className="font-bold text-[#1C1C1E] flex items-center justify-between text-[11px]">
                  <span className="truncate">{preset.nameAr}</span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-[#E0532B] shrink-0 mr-1" />
                  )}
                </div>
                <div className="text-[9.5px] text-[#78716C] font-mono mt-0.5 truncate" dir="ltr">
                  {preset.name}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
