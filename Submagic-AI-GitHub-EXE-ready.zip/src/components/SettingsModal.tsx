import React, { useState, useEffect } from 'react';
import { X, Key, Zap, Sparkles, CheckCircle2, AlertCircle, ExternalLink, RefreshCw, Activity, ShieldCheck } from 'lucide-react';
import { safeApiFetch } from '../utils/api';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  groqKey: string;
  onSaveGroqKey: (key: string) => void;
  geminiKey: string;
  onSaveGeminiKey: (key: string) => void;
  geminiConnected: boolean;
}

interface GroqQuotaInfo {
  valid: boolean;
  tier?: string;
  requestsRemaining?: string;
  requestsLimit?: string;
  requestsReset?: string;
  tokensRemaining?: string;
  tokensLimit?: string;
  tokensReset?: string;
  dailyAudioAllowance?: string;
  statusMessage?: string;
  error?: string;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  groqKey,
  onSaveGroqKey,
  geminiKey,
  onSaveGeminiKey,
  geminiConnected,
}) => {
  const [inputGroq, setInputGroq] = useState(groqKey);
  const [showGroq, setShowGroq] = useState(false);

  // Gemini API Key state (طلب المستخدم: ضيف اني ممكن احط api جيمناي عشان انا هستخدمه بره)
  const [inputGemini, setInputGemini] = useState(geminiKey);
  const [showGemini, setShowGemini] = useState(false);
  const [isVerifyingGemini, setIsVerifyingGemini] = useState(false);
  const [geminiVerifyResult, setGeminiVerifyResult] = useState<{
    valid: boolean;
    message?: string;
    error?: string;
  } | null>(null);

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Live Groq Quota & Credit Check state (طلب المستخدم: عايز اعرف فاضل كريدت قد اي في groq)
  const [quotaInfo, setQuotaInfo] = useState<GroqQuotaInfo | null>(null);
  const [isCheckingQuota, setIsCheckingQuota] = useState(false);

  useEffect(() => {
    setInputGroq(groqKey);
  }, [groqKey]);

  useEffect(() => {
    setInputGemini(geminiKey);
  }, [geminiKey]);

  // Check quota function
  const checkGroqQuota = async (keyToCheck = inputGroq) => {
    const key = keyToCheck.trim();
    if (!key) {
      setQuotaInfo(null);
      return;
    }

    setIsCheckingQuota(true);
    try {
      const res = await safeApiFetch<GroqQuotaInfo>('/api/groq/check-quota', {
        headers: {
          'x-groq-api-key': key,
        },
      });

      if (res.ok && res.data) {
        setQuotaInfo(res.data);
      } else {
        setQuotaInfo({
          valid: false,
          error: res.error || 'تعذر التحقق من المفتاح',
        });
      }
    } catch (err: any) {
      setQuotaInfo({
        valid: false,
        error: err?.message || 'خطأ في الاتصال بالخادم',
      });
    } finally {
      setIsCheckingQuota(false);
    }
  };

  // Verify Gemini Key function (طلب المستخدم: ضيف اني ممكن احط api جيمناي عشان انا هستخدمه بره)
  const verifyGeminiKey = async (keyToCheck = inputGemini) => {
    const key = keyToCheck.trim();
    if (!key) {
      setGeminiVerifyResult({ valid: false, error: 'يرجى إدخال مفتاح Gemini أولاً للفحص' });
      return;
    }

    setIsVerifyingGemini(true);
    try {
      const res = await safeApiFetch<{ valid: boolean; message?: string; error?: string }>(
        '/api/gemini/verify-key',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-gemini-api-key': key,
          },
          body: JSON.stringify({ apiKey: key }),
        }
      );

      if (res.ok && res.data?.valid) {
        setGeminiVerifyResult({
          valid: true,
          message: res.data.message || 'المفتاح متصل وصالح بنجاح!',
        });
      } else {
        setGeminiVerifyResult({
          valid: false,
          error: res.data?.error || res.error || 'المفتاح غير صالح أو لم يتم تفعيله',
        });
      }
    } catch (err: any) {
      setGeminiVerifyResult({
        valid: false,
        error: err?.message || 'خطأ في الاتصال بالسيرفر',
      });
    } finally {
      setIsVerifyingGemini(false);
    }
  };

  useEffect(() => {
    if (isOpen && groqKey) {
      checkGroqQuota(groqKey);
    }
  }, [isOpen, groqKey]);

  if (!isOpen) return null;

  const handleSave = () => {
    const cleanedGroq = inputGroq.trim();
    const cleanedGemini = inputGemini.trim();
    onSaveGroqKey(cleanedGroq);
    onSaveGeminiKey(cleanedGemini);
    setSavedSuccess(true);
    if (cleanedGroq) {
      checkGroqQuota(cleanedGroq);
    }
    if (cleanedGemini) {
      verifyGeminiKey(cleanedGemini);
    }
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white border border-[#E5E0D8] rounded-2xl shadow-xl p-6 text-[#1C1C1E] max-h-[92vh] overflow-y-auto font-['Cairo',sans-serif]">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 text-[#78716C] hover:text-[#1C1C1E] rounded-xl hover:bg-[#F3EFEA] transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#FDF2EC] text-[#E0532B] rounded-2xl border border-[#FED7AA] shadow-2xs">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold font-['Cairo',sans-serif] text-[#1C1C1E]">إعدادات الذكاء الاصطناعي والهوية</h2>
            <p className="text-xs text-[#78716C]">إدارة شعار mediaLab ورصيد محركات Groq Whisper و Google Gemini</p>
          </div>
        </div>

        <div className="space-y-5">
          {/* Logo & Brand Identity Section */}
          <div className="bg-[#FAF9F7] border border-[#E5E0D8] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-[#F4F1FA] text-[#6B21A8] rounded-lg border border-[#DDD6FE]">
                  <Sparkles className="w-4 h-4" />
                </span>
                <div>
                  <span className="font-bold text-[#1C1C1E] text-sm">شعار وهويّة mediaLab publishing</span>
                  <p className="text-[11px] text-[#78716C]">الشعار المستخدم في الهيدر والبرنامج</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-4 p-3 bg-white border border-[#E5E0D8] rounded-xl shadow-2xs">
              <div className="flex items-center gap-3">
                <div className="h-10 px-3 bg-[#FAF9F7] border border-[#E5E0D8] rounded-lg flex items-center justify-center">
                  {localStorage.getItem('medialab_custom_logo') ? (
                    <img
                      src={localStorage.getItem('medialab_custom_logo')!}
                      alt="Logo Preview"
                      className="h-8 max-w-[130px] object-contain drop-shadow-xs"
                    />
                  ) : (
                    <div className="flex flex-col leading-none text-right">
                      <span className="font-sans font-bold text-sm text-[#18181B]">
                        media<span className="font-black text-[#1C1C1E]">Lab</span>
                      </span>
                      <span className="font-sans font-medium text-[10px] text-[#27272A] -mt-0.5 tracking-wider">
                        publishing
                      </span>
                    </div>
                  )}
                </div>
                <div>
                  <div className="text-xs font-bold text-[#1C1C1E]">
                    {localStorage.getItem('medialab_custom_logo') ? 'شعار مخصص تم رفعه' : 'شعار mediaLab publishing الأصلي'}
                  </div>
                  <div className="text-[10px] text-[#78716C]">صورة أصلية مطابقة للتصميم المرفق بالكامل</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <label className="cursor-pointer px-3 py-1.5 bg-[#E0532B] hover:bg-[#C9431E] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-2xs active:scale-95">
                  <span>رفع صورة مخصصة</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      const reader = new FileReader();
                      reader.onload = (ev) => {
                        const b64 = ev.target?.result as string;
                        if (b64) {
                          localStorage.setItem('medialab_custom_logo', b64);
                          window.location.reload();
                        }
                      };
                      reader.readAsDataURL(file);
                    }}
                  />
                </label>

                {localStorage.getItem('medialab_custom_logo') && (
                  <button
                    type="button"
                    onClick={() => {
                      localStorage.removeItem('medialab_custom_logo');
                      window.location.reload();
                    }}
                    className="px-2.5 py-1.5 bg-white hover:bg-rose-50 text-[#78716C] hover:text-rose-600 rounded-xl text-xs transition border border-[#E5E0D8]"
                    title="الرجوع إلى شعار mediaLab الأصلي"
                  >
                    استعادة الأصلي
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Groq API Key & Quota Section */}
          <div className="bg-[#FAF9F7] border border-[#FED7AA] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-[#FEF3EC] text-[#C2410C] rounded-lg border border-[#FED7AA]">
                  <Zap className="w-4 h-4 text-[#EA580C]" />
                </span>
                <span className="font-bold text-[#C2410C] text-sm">مفتاح ورصيد Groq Whisper</span>
              </div>
              <a
                href="https://console.groq.com/keys"
                target="_blank"
                rel="noreferrer"
                className="text-xs text-[#C2410C] hover:text-[#9A3412] flex items-center gap-1 hover:underline font-semibold"
              >
                <span>إنشاء مفتاح مجاني</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <p className="text-xs text-[#554F47] leading-relaxed">
              نموذج <code className="text-[#C2410C] font-mono bg-white px-1.5 py-0.5 rounded border border-[#FED7AA]">whisper-large-v3-turbo</code> يقدم سرعة فائقة (10x من الوقت الحقيقي) مجاناً.
            </p>

            <div className="relative">
              <input
                type={showGroq ? 'text' : 'password'}
                placeholder="gsk_..."
                value={inputGroq}
                onChange={(e) => setInputGroq(e.target.value)}
                className="w-full bg-white border border-[#E5E0D8] rounded-xl px-3.5 py-2.5 text-xs font-mono text-[#1C1C1E] placeholder-[#A8A29E] focus:outline-none focus:border-[#E0532B] shadow-2xs"
                dir="ltr"
              />
              <button
                type="button"
                onClick={() => setShowGroq(!showGroq)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#78716C] hover:text-[#1C1C1E]"
              >
                {showGroq ? 'إخفاء' : 'إظهار'}
              </button>
            </div>

            {/* Live Quota & Credit Card */}
            <div className="bg-white border border-[#E5E0D8] rounded-xl p-3 space-y-2 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#1C1C1E] flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-[#E0532B]" />
                  <span>حالة الرصيد والاستهلاك المتبقي (Live Quota):</span>
                </span>
                <button
                  type="button"
                  onClick={() => checkGroqQuota(inputGroq)}
                  disabled={isCheckingQuota || !inputGroq}
                  className="flex items-center gap-1 text-[11px] text-[#C2410C] hover:text-[#9A3412] font-semibold disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${isCheckingQuota ? 'animate-spin' : ''}`} />
                  <span>تحديث الرصيد</span>
                </button>
              </div>

              {quotaInfo ? (
                quotaInfo.valid ? (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-bold">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>{quotaInfo.statusMessage || 'المفتاح نشط ورصيدك متاح بالكامل'}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                      <div className="bg-[#FAF9F7] p-2 rounded-lg border border-[#E5E0D8]">
                        <div className="text-[#78716C] text-[10px]">الطلبات المتبقية:</div>
                        <div className="text-[#C2410C] font-bold text-sm">
                          {quotaInfo.requestsRemaining} / {quotaInfo.requestsLimit}
                        </div>
                      </div>

                      <div className="bg-[#FAF9F7] p-2 rounded-lg border border-[#E5E0D8]">
                        <div className="text-[#78716C] text-[10px]">الرموز المتبقية (Tokens):</div>
                        <div className="text-blue-600 font-bold text-sm">
                          {quotaInfo.tokensRemaining} / {quotaInfo.tokensLimit}
                        </div>
                      </div>
                    </div>

                    <div className="text-[10.5px] text-[#78716C] bg-[#FAF9F7] p-2 rounded-lg border border-[#E5E0D8] leading-relaxed">
                      🎁 <strong className="text-[#1C1C1E]">حصة الحساب المجاني:</strong> {quotaInfo.dailyAudioAllowance}
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-rose-600 flex items-center gap-1 pt-1 font-semibold">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                    <span>{quotaInfo.error || 'المفتاح غير صالح أو منتهي'}</span>
                  </div>
                )
              ) : (
                <div className="text-[11px] text-[#78716C]">
                  أدخل مفتاح Groq واضغط "تحديث الرصيد" لعرض معدل الطلبات وحجم الساعات المتبقية.
                </div>
              )}
            </div>
          </div>

          {/* Gemini AI Engine & Custom API Key Section */}
          <div className="bg-[#FAF9F7] border border-[#DDD6FE] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-[#F4F1FA] text-[#6B21A8] rounded-lg border border-[#DDD6FE]">
                  <Sparkles className="w-4 h-4 text-[#9333EA]" />
                </span>
                <span className="font-bold text-[#6B21A8] text-sm">مفتاح Google Gemini API (للاستخدام الخارجي المستقل)</span>
              </div>
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noreferrer"
                className="text-xs text-[#6B21A8] hover:text-[#581C87] flex items-center gap-1 hover:underline font-semibold"
              >
                <span>احصل على مفتاح مجاني</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <p className="text-xs text-[#554F47] leading-relaxed">
              إذا كنت تستخدم التطبيق <strong className="text-[#6B21A8]">خارج واجهة Google AI Studio</strong> (على خادمك الخاص، محلياً، أو استضافة سحابية)، أدخل مفتاح Gemini API الخاص بك هنا لحفظه واستخدامه في كشف الكلمات المفتاحية والتدقيق اللغوي:
            </p>

            <div className="relative">
              <input
                type={showGemini ? 'text' : 'password'}
                placeholder="AIzaSy..."
                value={inputGemini}
                onChange={(e) => {
                  setInputGemini(e.target.value);
                  setGeminiVerifyResult(null);
                }}
                className="w-full bg-white border border-[#E5E0D8] rounded-xl px-3.5 py-2.5 text-xs font-mono text-[#1C1C1E] placeholder-[#A8A29E] focus:outline-none focus:border-[#E0532B] shadow-2xs"
                dir="ltr"
              />
              <button
                type="button"
                onClick={() => setShowGemini(!showGemini)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#78716C] hover:text-[#1C1C1E]"
              >
                {showGemini ? 'إخفاء' : 'إظهار'}
              </button>
            </div>

            {/* Test Connection Button & Result */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={() => verifyGeminiKey(inputGemini)}
                disabled={isVerifyingGemini || !inputGemini.trim()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-[#F3EFEA] border border-[#DDD6FE] text-xs font-semibold text-[#6B21A8] transition disabled:opacity-50 disabled:cursor-not-allowed shadow-2xs"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isVerifyingGemini ? 'animate-spin' : ''}`} />
                <span>اختبار صحة المفتاح والاتصال</span>
              </button>

              {geminiVerifyResult ? (
                geminiVerifyResult.valid ? (
                  <span className="flex items-center gap-1 text-xs text-emerald-700 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{geminiVerifyResult.message}</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-xs text-rose-600 font-semibold">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                    <span className="truncate max-w-[220px]">{geminiVerifyResult.error}</span>
                  </span>
                )
              ) : (
                <span className="text-[11px] text-[#78716C]">
                  {inputGemini ? 'اضغط لاختبار المفتاح' : geminiConnected ? 'متصل بالمفتاح الافتراضي (يمكنك استبداله بمفتاحك الخاص)' : 'أدخل مفتاحك للتشغيل خارج AI Studio'}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-end gap-3 pt-4 border-t border-[#E5E0D8]">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-[#554F47] hover:text-[#1C1C1E] rounded-xl hover:bg-[#F3EFEA] transition"
          >
            إغلاق
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-[#E0532B] hover:bg-[#C9431E] rounded-xl shadow-sm transition active:scale-95"
          >
            {savedSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>تم الحفظ!</span>
              </>
            ) : (
              <span>حفظ المفتاح</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
