import React, { useRef, useState, memo } from 'react';
import {
  Settings,
  Download,
  RotateCcw,
  Languages,
  LayoutGrid,
} from 'lucide-react';
import { Language, translations } from '../utils/translations';

interface PremiereHeaderProps {
  lang: Language;
  onToggleLanguage: () => void;
  onOpenSettings: () => void;
  onOpenExport: () => void;
  onLoadSample: () => void;
  segmentCount: number;
  layoutPreset: 'default' | 'monitor' | 'timeline';
  onSelectLayoutPreset: (preset: 'default' | 'monitor' | 'timeline') => void;
}

export const PremiereHeader: React.FC<PremiereHeaderProps> = memo(({
  lang,
  onToggleLanguage,
  onOpenSettings,
  onOpenExport,
  onLoadSample,
  segmentCount,
  layoutPreset,
  onSelectLayoutPreset,
}) => {
  const t = translations[lang];
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [customLogo, setCustomLogo] = useState<string | null>(() => {
    return localStorage.getItem('medialab_custom_logo') || null;
  });
  const [showLayoutMenu, setShowLayoutMenu] = useState(false);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        setCustomLogo(base64);
        localStorage.setItem('medialab_custom_logo', base64);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleResetLogo = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCustomLogo(null);
    localStorage.removeItem('medialab_custom_logo');
  };

  return (
    <header className="w-full bg-[#FAF9F7] border-b border-[#E5E0D8] select-none text-[#1C1C1E] text-xs shrink-0 shadow-xs transition-colors z-30">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleLogoUpload}
        accept="image/*"
        className="hidden"
      />

      <div className="flex items-center justify-between px-4 py-2 text-xs">
        {/* Left Side (in LTR: Logo & Brand, in RTL: Mirrored) */}
        <div className="flex items-center gap-3">
          <div
            onClick={() => fileInputRef.current?.click()}
            className="group relative flex items-center gap-2 p-1 rounded-xl hover:bg-[#EFECE6] cursor-pointer transition"
            title={lang === 'en' ? 'Click to upload custom logo' : 'انقر لتغيير أو رفع شعار مخصص'}
          >
            {customLogo ? (
              <img
                src={customLogo}
                alt="Custom Logo"
                className="h-8 max-w-[150px] object-contain drop-shadow-xs"
              />
            ) : (
              <div className="flex flex-col text-left rtl:text-right leading-none select-none">
                <span className="font-sans font-bold text-[16px] text-[#18181B] tracking-tight">
                  media<span className="font-black text-[#E0532B]">Lab</span>
                </span>
                <span className="font-sans font-medium text-[10px] text-[#52525B] tracking-normal -mt-0.5">
                  publishing
                </span>
              </div>
            )}

            {customLogo && (
              <button
                onClick={handleResetLogo}
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-rose-100 text-[#8D827A] hover:text-rose-600 rounded-md transition"
                title={lang === 'en' ? 'Reset Logo' : 'استعادة الشعار الأصلي'}
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            )}
          </div>

          <div className="h-5 w-px bg-[#E5E0D8] hidden sm:block" />

          <span className="text-[10px] font-bold text-[#8D827A] tracking-wider uppercase hidden md:inline">
            {t.videoSuite}
          </span>
        </div>

        {/* Center Title & Counter */}
        <div className="hidden lg:flex items-center gap-2 text-xs text-[#554F47]">
          <span className="text-[#1C1C1E] font-bold text-[13px]">
            {t.appTitle}
          </span>
          <span className="text-[#A8A29E]">·</span>
          <span className="text-[#E0532B] font-bold bg-[#FDF0EB] px-2.5 py-0.5 rounded-full border border-[#FED7AA] font-mono text-[10.5px]">
            {segmentCount} {t.subtitleCount}
          </span>
        </div>

        {/* Right Side: Primary Actions & Utilities */}
        <div className="flex items-center gap-2">
          {/* Primary Action Button: Vibrant Orange "Export Video (MP4)" */}
          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#E0532B] hover:bg-[#C9431E] text-white font-bold rounded-xl shadow-xs transition active:scale-95 text-xs"
            title={t.exportVideoMp4}
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.exportVideoMp4}</span>
          </button>

          {/* Layout Customization Menu */}
          <div className="relative">
            <button
              onClick={() => setShowLayoutMenu(!showLayoutMenu)}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-white hover:bg-[#F3EFEA] text-[#554F47] hover:text-[#1C1C1E] rounded-xl border border-[#E5E0D8] shadow-2xs transition text-[11px] font-semibold"
              title={t.layoutPreset}
            >
              <LayoutGrid className="w-3.5 h-3.5 text-[#E0532B]" />
              <span className="hidden sm:inline">{t.layoutPreset}</span>
            </button>

            {showLayoutMenu && (
              <div className="absolute top-full mt-1.5 right-0 rtl:right-auto rtl:left-0 z-50 w-44 bg-white border border-[#E5E0D8] rounded-xl shadow-xl p-1 space-y-0.5">
                <button
                  onClick={() => {
                    onSelectLayoutPreset('default');
                    setShowLayoutMenu(false);
                  }}
                  className={`w-full text-left rtl:text-right px-2.5 py-1.5 text-xs rounded-lg transition flex items-center justify-between ${
                    layoutPreset === 'default'
                      ? 'bg-[#FDF2EC] text-[#E0532B] font-bold'
                      : 'hover:bg-[#FAF9F7] text-[#1C1C1E]'
                  }`}
                >
                  <span>{t.layoutDefault}</span>
                  {layoutPreset === 'default' && <span className="text-[10px]">✓</span>}
                </button>
                <button
                  onClick={() => {
                    onSelectLayoutPreset('monitor');
                    setShowLayoutMenu(false);
                  }}
                  className={`w-full text-left rtl:text-right px-2.5 py-1.5 text-xs rounded-lg transition flex items-center justify-between ${
                    layoutPreset === 'monitor'
                      ? 'bg-[#FDF2EC] text-[#E0532B] font-bold'
                      : 'hover:bg-[#FAF9F7] text-[#1C1C1E]'
                  }`}
                >
                  <span>{t.layoutMonitorFocus}</span>
                  {layoutPreset === 'monitor' && <span className="text-[10px]">✓</span>}
                </button>
                <button
                  onClick={() => {
                    onSelectLayoutPreset('timeline');
                    setShowLayoutMenu(false);
                  }}
                  className={`w-full text-left rtl:text-right px-2.5 py-1.5 text-xs rounded-lg transition flex items-center justify-between ${
                    layoutPreset === 'timeline'
                      ? 'bg-[#FDF2EC] text-[#E0532B] font-bold'
                      : 'hover:bg-[#FAF9F7] text-[#1C1C1E]'
                  }`}
                >
                  <span>{t.layoutTimelineFocus}</span>
                  {layoutPreset === 'timeline' && <span className="text-[10px]">✓</span>}
                </button>
              </div>
            )}
          </div>

          {/* Language Switcher (EN / AR) */}
          <button
            onClick={onToggleLanguage}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-white hover:bg-[#F3EFEA] text-[#1C1C1E] rounded-xl border border-[#E5E0D8] shadow-2xs transition text-[11px] font-bold active:scale-95"
            title={lang === 'en' ? 'تبديل إلى اللغة العربية' : 'Switch to English'}
          >
            <Languages className="w-3.5 h-3.5 text-[#E0532B]" />
            <span>{lang === 'en' ? 'العربية' : 'EN'}</span>
          </button>

          {/* Settings Gear */}
          <button
            onClick={onOpenSettings}
            className="p-2 bg-white hover:bg-[#F3EFEA] text-[#554F47] hover:text-[#1C1C1E] rounded-xl border border-[#E5E0D8] shadow-2xs transition"
            title={t.settings}
          >
            <Settings className="w-3.5 h-3.5" />
          </button>

          {/* Help/Sample Video */}
          <button
            onClick={onLoadSample}
            className="p-2 bg-white hover:bg-[#F3EFEA] text-[#554F47] hover:text-[#1C1C1E] rounded-xl border border-[#E5E0D8] shadow-2xs transition"
            title={t.sampleVideo}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
});

PremiereHeader.displayName = 'PremiereHeader';
