import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  Scissors,
  Trash2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Magnet,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Volume2,
  MousePointer,
  Hand,
  Type,
  Plus,
  Undo2,
  Redo2,
  CheckSquare,
  Layers,
} from 'lucide-react';
import { SubtitleSegment, TimelineTool, VideoCutSegment } from '../types';
import { formatTimecodePremiere, splitSegmentAtTime } from '../utils/srt';

import { Language, translations } from '../utils/translations';

interface TimelineProps {
  lang?: Language;
  duration: number;
  currentTime: number;
  segments: SubtitleSegment[];
  selectedSegmentIds: number[];
  isPlaying: boolean;
  canUndo?: boolean;
  canRedo?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
  onSeek: (time: number) => void;
  onSelectSegments: (ids: number[]) => void;
  onUpdateSegments: (segments: SubtitleSegment[], recordHistory?: boolean) => void;
  onSplitAtPlayhead: () => void;
  onDeleteSelected: () => void;
  onAddSegmentAtPlayhead: () => void;
  videoCuts?: VideoCutSegment[];
  selectedCutId?: string | null;
  onSelectCut?: (id: string | null) => void;
  onSplitVideo?: () => void;
  onDeleteCut?: (id: string) => void;
  onMergeCuts?: () => void;
}

export const Timeline: React.FC<TimelineProps> = ({
  lang = 'en',
  duration,
  currentTime,
  segments,
  selectedSegmentIds,
  isPlaying,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onSeek,
  onSelectSegments,
  onUpdateSegments,
  onSplitAtPlayhead,
  onDeleteSelected,
  onAddSegmentAtPlayhead,
  videoCuts = [],
  selectedCutId = null,
  onSelectCut,
  onSplitVideo,
  onDeleteCut,
  onMergeCuts,
}) => {
  const t = translations[lang];
  const containerRef = useRef<HTMLDivElement | null>(null);
  const tracksScrollRef = useRef<HTMLDivElement | null>(null);
  const rulerRef = useRef<HTMLDivElement | null>(null);

  // Zoom level: pixels per second
  const [zoom, setZoom] = useState<number>(35);
  const [activeTool, setActiveTool] = useState<TimelineTool>('select');
  const [snapping, setSnapping] = useState<boolean>(true);

  // Dragging state for clips and playhead
  const [isScrubbing, setIsScrubbing] = useState<boolean>(false);
  const [dragAction, setDragAction] = useState<{
    type: 'move' | 'trim-start' | 'trim-end';
    targetId: number;
    initialMouseX: number;
    initialStarts: Record<number, number>;
    initialEnds: Record<number, number>;
  } | null>(null);

  // Marquee box selection state
  const [marquee, setMarquee] = useState<{
    startX: number;
    startY: number;
    currentX: number;
    currentY: number;
  } | null>(null);

  // Track lock & mute
  const [subTrackLocked, setSubTrackLocked] = useState(false);
  const [videoTrackMuted, setVideoTrackMuted] = useState(false);
  const [audioTrackMuted, setAudioTrackMuted] = useState(false);

  // Effective duration (at least 10s)
  const effectiveDuration = Math.max(duration || 10, 10);
  const timelineWidth = Math.max(1000, Math.ceil(effectiveDuration * zoom) + 100);

  // Conversions between time and pixels
  const timeToPx = useCallback((t: number) => t * zoom, [zoom]);
  const pxToTime = useCallback(
    (px: number) => Math.max(0, Math.min(effectiveDuration, px / zoom)),
    [effectiveDuration, zoom]
  );

  // Auto-scroll timeline to follow playhead when playing
  useEffect(() => {
    if (isPlaying && tracksScrollRef.current) {
      const scrollEl = tracksScrollRef.current;
      const playheadPx = timeToPx(currentTime);
      const viewLeft = scrollEl.scrollLeft;
      const viewRight = viewLeft + scrollEl.clientWidth;

      if (playheadPx > viewRight - 100 || playheadPx < viewLeft) {
        scrollEl.scrollLeft = Math.max(0, playheadPx - 150);
      }
    }
  }, [currentTime, isPlaying, timeToPx]);

  // Alt + Mouse Wheel = Zoom | Regular Mouse Wheel = Horizontal Scroll across Timeline (User Request #9)
  useEffect(() => {
    const scrollContainer = tracksScrollRef.current;
    if (!scrollContainer) return;

    const handleWheel = (e: WheelEvent) => {
      if (e.altKey) {
        e.preventDefault();
        e.stopPropagation();

        const rect = scrollContainer.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const scrollLeft = scrollContainer.scrollLeft;
        const currentPx = scrollLeft + mouseX;
        const mouseTime = currentPx / zoom;

        const zoomDelta = e.deltaY < 0 ? 1.25 : 0.8;
        const newZoom = Math.max(0.5, Math.min(250, Number((zoom * zoomDelta).toFixed(1))));

        if (newZoom !== zoom) {
          setZoom(newZoom);
          requestAnimationFrame(() => {
            const newPx = mouseTime * newZoom;
            scrollContainer.scrollLeft = Math.max(0, newPx - mouseX);
          });
        }
      } else {
        // Direct Mouse Wheel Horizontal Scroll (User Request #9)
        if (Math.abs(e.deltaY) > 0) {
          e.preventDefault();
          scrollContainer.scrollLeft += e.deltaY * 1.2;
        }
      }
    };

    scrollContainer.addEventListener('wheel', handleWheel, { passive: false });
    return () => scrollContainer.removeEventListener('wheel', handleWheel);
  }, [zoom]);

  // Scrubbing on ruler
  const handleRulerMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!tracksScrollRef.current) return;
    const rect = tracksScrollRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left + tracksScrollRef.current.scrollLeft;
    const newTime = Number(pxToTime(clickX).toFixed(2));
    onSeek(newTime);
    setIsScrubbing(true);
  };

  // Start marquee selection on track container (right-click or click on empty space)
  const handleTrackAreaMouseDown = (e: React.MouseEvent) => {
    if (activeTool === 'select') {
      const scrollEl = tracksScrollRef.current;
      if (!scrollEl) return;
      const rect = scrollEl.getBoundingClientRect();
      const x = e.clientX - rect.left + scrollEl.scrollLeft;
      const y = e.clientY - rect.top;

      setMarquee({
        startX: x,
        startY: y,
        currentX: x,
        currentY: y,
      });

      if (!e.shiftKey && !e.ctrlKey && !e.metaKey && e.button !== 2) {
        onSelectSegments([]);
      }
    }
  };

  // Global mouse handlers for scrubbing, dragging clips, and marquee box
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const scrollEl = tracksScrollRef.current;
      if (!scrollEl) return;
      const rect = scrollEl.getBoundingClientRect();

      // 1. Scrubbing
      if (isScrubbing) {
        const clickX = e.clientX - rect.left + scrollEl.scrollLeft;
        let newTime = pxToTime(clickX);
        if (snapping) {
          for (const s of segments) {
            if (Math.abs(s.start - newTime) < 0.2) {
              newTime = s.start;
              break;
            }
            if (Math.abs(s.end - newTime) < 0.2) {
              newTime = s.end;
              break;
            }
          }
        }
        onSeek(Number(newTime.toFixed(2)));
        return;
      }

      // 2. Marquee box selection
      if (marquee) {
        const x = e.clientX - rect.left + scrollEl.scrollLeft;
        const y = e.clientY - rect.top;
        setMarquee((prev) => (prev ? { ...prev, currentX: x, currentY: y } : null));

        const minX = Math.min(marquee.startX, x);
        const maxX = Math.max(marquee.startX, x);

        // Find segments within marquee horizontal bounds
        const insideIds: number[] = [];
        for (const seg of segments) {
          const segLeft = seg.start * zoom;
          const segRight = seg.end * zoom;
          if (segRight >= minX && segLeft <= maxX) {
            insideIds.push(seg.id);
          }
        }
        onSelectSegments(insideIds);
        return;
      }

      // 3. Dragging / Trimming clips
      if (dragAction && !subTrackLocked) {
        const deltaPx = e.clientX - dragAction.initialMouseX;
        const deltaTime = deltaPx / zoom;

        if (dragAction.type === 'move') {
          // Move all selected segments together
          const targetIds =
            selectedSegmentIds.length > 0 && selectedSegmentIds.includes(dragAction.targetId)
              ? selectedSegmentIds
              : [dragAction.targetId];

          const updated = segments.map((seg) => {
            if (targetIds.includes(seg.id)) {
              const initStart = dragAction.initialStarts[seg.id] ?? seg.start;
              const initEnd = dragAction.initialEnds[seg.id] ?? seg.end;
              const segDur = initEnd - initStart;
              let newStart = Math.max(0, initStart + deltaTime);
              let newEnd = newStart + segDur;

              if (snapping && Math.abs(currentTime - newStart) < 0.15) {
                newStart = currentTime;
                newEnd = newStart + segDur;
              }

              return {
                ...seg,
                start: Number(newStart.toFixed(2)),
                end: Number(newEnd.toFixed(2)),
              };
            }
            return seg;
          });

          onUpdateSegments(updated, false);
        } else if (dragAction.type === 'trim-start') {
          const seg = segments.find((s) => s.id === dragAction.targetId);
          if (!seg) return;
          const initStart = dragAction.initialStarts[seg.id] ?? seg.start;
          let newStart = Math.max(0, Math.min(seg.end - 0.2, initStart + deltaTime));
          if (snapping && Math.abs(currentTime - newStart) < 0.15) {
            newStart = currentTime;
          }
          onUpdateSegments(
            segments.map((s) =>
              s.id === seg.id ? { ...s, start: Number(newStart.toFixed(2)) } : s
            ),
            false
          );
        } else if (dragAction.type === 'trim-end') {
          const seg = segments.find((s) => s.id === dragAction.targetId);
          if (!seg) return;
          const initEnd = dragAction.initialEnds[seg.id] ?? seg.end;
          let newEnd = Math.max(seg.start + 0.2, initEnd + deltaTime);
          if (snapping && Math.abs(currentTime - newEnd) < 0.15) {
            newEnd = currentTime;
          }
          onUpdateSegments(
            segments.map((s) =>
              s.id === seg.id ? { ...s, end: Number(newEnd.toFixed(2)) } : s
            ),
            false
          );
        }
      }
    };

    const handleMouseUp = () => {
      setIsScrubbing(false);
      setMarquee(null);
      if (dragAction) {
        // Record final position in undo history
        onUpdateSegments(segments, true);
        setDragAction(null);
      }
    };

    if (isScrubbing || marquee || dragAction) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [
    isScrubbing,
    marquee,
    dragAction,
    zoom,
    segments,
    selectedSegmentIds,
    subTrackLocked,
    snapping,
    currentTime,
    pxToTime,
    onSeek,
    onSelectSegments,
    onUpdateSegments,
  ]);

  // Click on clip
  const handleClipClick = (e: React.MouseEvent, seg: SubtitleSegment) => {
    e.stopPropagation();

    if (e.shiftKey || e.ctrlKey || e.metaKey) {
      // Toggle in multi-selection
      if (selectedSegmentIds.includes(seg.id)) {
        onSelectSegments(selectedSegmentIds.filter((id) => id !== seg.id));
      } else {
        onSelectSegments([...selectedSegmentIds, seg.id]);
      }
      return;
    }

    onSelectSegments([seg.id]);

    if (activeTool === 'razor') {
      const scrollEl = tracksScrollRef.current;
      if (!scrollEl) return;
      const rect = scrollEl.getBoundingClientRect();
      const clickX = e.clientX - rect.left + scrollEl.scrollLeft;
      const clickTime = Number(pxToTime(clickX).toFixed(2));
      const splitRes = splitSegmentAtTime(seg, clickTime, segments.length + 1);
      if (splitRes) {
        const [s1, s2] = splitRes;
        const idx = segments.findIndex((s) => s.id === seg.id);
        const updated = [...segments.slice(0, idx), s1, s2, ...segments.slice(idx + 1)].map(
          (s, i) => ({ ...s, id: i + 1 })
        );
        onUpdateSegments(updated, true);
        onSeek(clickTime);
        onSelectSegments([s2.id]);
      }
    } else if (activeTool === 'delete') {
      const updated = segments
        .filter((s) => s.id !== seg.id)
        .map((s, idx) => ({ ...s, id: idx + 1 }));
      onUpdateSegments(updated, true);
      onSelectSegments([]);
    }
  };

  // Ticks calculation based on zoom level
  const renderRulerTicks = () => {
    let tickStep = 5;
    if (zoom >= 100) tickStep = 1;
    else if (zoom >= 40) tickStep = 2;
    else if (zoom >= 15) tickStep = 5;
    else if (zoom >= 5) tickStep = 15;
    else tickStep = 30; // for ultra zoomed out views

    const ticks = [];
    const count = Math.ceil(effectiveDuration / tickStep) + 2;

    for (let i = 0; i <= count; i++) {
      const sec = i * tickStep;
      if (sec > effectiveDuration + 5) break;
      const left = timeToPx(sec);

      ticks.push(
        <div
          key={sec}
          style={{ left: `${left}px` }}
          className="absolute top-0 bottom-0 flex flex-col justify-between pointer-events-none select-none"
        >
          <span className="text-[9.5px] font-mono text-[#78716C] pl-1 font-semibold">
            {formatTimecodePremiere(sec).slice(3, 8)}
          </span>
          <div className="w-[1px] h-2 bg-[#D5CFBF] self-start" />
        </div>
      );
    }
    return ticks;
  };

  // Fit all timeline to screen
  const handleFitScreen = () => {
    if (tracksScrollRef.current) {
      const viewWidth = tracksScrollRef.current.clientWidth - 40;
      setZoom(Math.max(2, Number((viewWidth / effectiveDuration).toFixed(2))));
    }
  };

  return (
    <div
      ref={containerRef}
      dir="ltr"
      className="flex flex-col h-full w-full bg-[#FAF9F7] border-t border-[#E5E0D8] select-none text-[#1C1C1E] overflow-hidden font-['Cairo',sans-serif]"
    >
      {/* Top Header: Clean & Lightweight Premiere Bar */}
      <div className="h-8 px-2 bg-white border-b border-[#E5E0D8] flex items-center justify-between text-xs shrink-0 shadow-2xs">
        {/* Left: Sequence Tag & Timecode */}
        <div className="flex items-center gap-2.5">
          <span className="px-2.5 py-0.5 bg-[#FAF9F7] border-t-2 border-[#E0532B] text-[#1C1C1E] font-bold text-[11px] rounded-t-lg border-x border-[#E5E0D8]">
            Sequence 01
          </span>

          <span className="font-mono font-bold text-xs text-[#1C1C1E] bg-[#FAF9F7] px-2.5 py-0.5 rounded-lg border border-[#E5E0D8] shadow-2xs">
            {formatTimecodePremiere(currentTime)}
          </span>
          <span className="text-[10px] text-[#78716C] font-mono hidden sm:inline">
            / {formatTimecodePremiere(effectiveDuration)}
          </span>

          {/* Undo / Redo Buttons */}
          <div className="flex items-center gap-0.5 border-l border-[#E5E0D8] pl-2 ml-1">
            <button
              onClick={onUndo}
              disabled={!canUndo}
              className={`p-1 rounded-lg transition ${
                canUndo ? 'text-[#554F47] hover:text-[#1C1C1E] hover:bg-[#F3EFEA]' : 'text-[#D5CFBF] cursor-not-allowed'
              }`}
              title="تراجع (Ctrl+Z)"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onRedo}
              disabled={!canRedo}
              className={`p-1 rounded-lg transition ${
                canRedo ? 'text-[#554F47] hover:text-[#1C1C1E] hover:bg-[#F3EFEA]' : 'text-[#D5CFBF] cursor-not-allowed'
              }`}
              title="إعادة (Ctrl+Y)"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Center: Minimal Multi-select status */}
        <div className="flex items-center gap-2 text-[11px]">
          {selectedSegmentIds.length > 1 ? (
            <span className="px-2.5 py-0.5 rounded-lg bg-[#FDF2EC] border border-[#FED7AA] text-[#C2410C] font-semibold">
              تم تحديد {selectedSegmentIds.length} مقاطع معاً
            </span>
          ) : (
            <span className="text-[#8D827A] text-[10.5px] hidden lg:inline font-normal">
              كليك وسحب لتحديد الكل | Alt + عجلة الماوس للزوم
            </span>
          )}
        </div>

        {/* Right: Quick Actions & Zoom */}
        <div className="flex items-center gap-1.5">
          {/* Snap Magnet */}
          <button
            onClick={() => setSnapping(!snapping)}
            className={`p-1 rounded-lg transition ${
              snapping ? 'bg-[#FDF2EC] text-[#E0532B] border border-[#FED7AA]' : 'text-[#78716C] hover:text-[#1C1C1E]'
            }`}
            title="المغناطيس والمحاذاة التلقائية"
          >
            <Magnet className="w-3.5 h-3.5" />
          </button>

          {/* Quick Cut Caption [S] */}
          <button
            onClick={onSplitAtPlayhead}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#FEF3EC] hover:bg-[#FDE7D9] border border-[#FED7AA] text-[#C2410C] rounded-lg text-[11px] font-bold transition shadow-2xs active:scale-95"
            title="تقسيم سطر الكابشن عند المؤشر [اختصار S]"
          >
            <Scissors className="w-3 h-3 text-[#EA580C]" />
            <span>قص كابشن [S]</span>
          </button>

          {/* Quick Split Video [C] */}
          {onSplitVideo && (
            <button
              onClick={onSplitVideo}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#F4F1FA] hover:bg-[#EBE5F7] border border-[#DDD6FE] text-[#6B21A8] rounded-lg text-[11px] font-bold transition shadow-2xs active:scale-95"
              title="قص وتقسيم مقطع الفيديو عند المؤشر [اختصار C]"
            >
              <Scissors className="w-3 h-3 text-[#9333EA]" />
              <span>قص فيديو [C]</span>
            </button>
          )}

          {/* Quick Merge Video Cuts [M] */}
          {onMergeCuts && (
            <button
              onClick={onMergeCuts}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#F0FDF4] hover:bg-[#DCFCE7] border border-[#BBF7D0] text-[#15803D] rounded-lg text-[11px] font-bold transition shadow-2xs active:scale-95"
              title="تجميع ودمج أجزاء الفيديو المقصوصة في مقطع واحد [اختصار M]"
            >
              <Layers className="w-3 h-3 text-[#16A34A]" />
              <span>تجميع [M]</span>
            </button>
          )}

          {/* Quick Delete [A] */}
          <button
            onClick={onDeleteSelected}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#FDECEE] hover:bg-[#FCD9DF] border border-[#FECDD3] text-[#BE123C] rounded-lg text-[11px] font-bold transition shadow-2xs active:scale-95"
            title="مسح الكابشن أو الجزء المحدد [Del أو A]"
          >
            <Trash2 className="w-3 h-3" />
            <span>حذف [A]</span>
          </button>

          {/* Add Caption */}
          <button
            onClick={onAddSegmentAtPlayhead}
            className="p-1 hover:text-[#1C1C1E] text-[#554F47] bg-white hover:bg-[#F3EFEA] border border-[#E5E0D8] rounded-lg transition shadow-2xs"
            title="إضافة سطر كابشن جديد"
          >
            <Plus className="w-3.5 h-3.5 text-[#16A34A]" />
          </button>

          {/* Zoom Slider */}
          <div className="flex items-center gap-1 bg-[#FAF9F7] px-2 py-0.5 rounded-lg border border-[#E5E0D8] shadow-2xs">
            <button
              onClick={() => setZoom((z) => Math.max(0.5, Number((z * 0.7).toFixed(1))))}
              className="p-0.5 hover:text-[#1C1C1E] text-[#78716C]"
              title="تصغير التايم لاين (Zoom Out)"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <input
              type="range"
              min={0.5}
              max={180}
              step={0.5}
              value={zoom}
              onChange={(e) => setZoom(parseFloat(e.target.value))}
              className="w-16 h-1 bg-[#E5E0D8] rounded appearance-none accent-[#E0532B] cursor-pointer"
            />
            <button
              onClick={() => setZoom((z) => Math.min(220, Number((z * 1.35).toFixed(1))))}
              className="p-0.5 hover:text-[#1C1C1E] text-[#78716C]"
              title="تكبير التايم لاين (Zoom In)"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
            <button
              onClick={handleFitScreen}
              className="px-1.5 py-0.5 text-[9.5px] font-bold bg-white hover:bg-[#F3EFEA] text-[#1C1C1E] rounded border border-[#E5E0D8] transition shadow-2xs"
              title="ملاءمة كامل الفيديو في الشاشة (Fit All)"
            >
              Fit
            </button>
          </div>
        </div>
      </div>

      {/* Main Multi-Track Layout: Left Tools + Track Headers + Multi-Track Canvas */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Tools Strip (Light SaaS Theme matching mediaLab style) */}
        <div className="w-9 bg-[#FAF9F7] border-r border-[#E5E0D8] flex flex-col items-center py-2 gap-1.5 z-20 shrink-0 select-none">
          <button
            onClick={() => setActiveTool('select')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'select'
                ? 'bg-[#E0532B] text-white shadow-2xs'
                : 'text-[#78716C] hover:text-[#1C1C1E] hover:bg-white'
            }`}
            title="أداة التحديد والتحريك (V)"
          >
            <MousePointer className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setActiveTool('razor')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'razor'
                ? 'bg-[#E0532B] text-white shadow-2xs'
                : 'text-[#78716C] hover:text-[#1C1C1E] hover:bg-white'
            }`}
            title="أداة شفرة القص (S)"
          >
            <Scissors className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setActiveTool('delete')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'delete'
                ? 'bg-[#E11D48] text-white shadow-2xs'
                : 'text-[#78716C] hover:text-[#E11D48] hover:bg-[#FDECEE]'
            }`}
            title="أداة الحذف المباشر (A)"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setActiveTool('hand')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'hand'
                ? 'bg-[#E0532B] text-white shadow-2xs'
                : 'text-[#78716C] hover:text-[#1C1C1E] hover:bg-white'
            }`}
            title="أداة التحريك (H)"
          >
            <Hand className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Track Headers Column (Pinned Left) */}
        <div className="w-28 sm:w-32 bg-[#FAF9F7] border-r border-[#E5E0D8] flex flex-col shrink-0 z-10 select-none">
          {/* Header Spacer matching Ruler (h-6 = 24px) */}
          <div className="h-6 bg-[#F3EFEA] border-b border-[#E5E0D8] flex items-center justify-between px-2 text-[9px] text-[#78716C] font-mono font-bold">
            <span>TRACKS</span>
            <span>M / L</span>
          </div>

          {/* CC Subtitles Header (h-14 = 56px) */}
          <div className="h-14 px-2 py-1.5 border-b border-[#E5E0D8] bg-[#FAF9F7] flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[10.5px] text-[#C2410C] font-mono flex items-center gap-1.5 bg-[#FEF3EC] px-1.5 py-0.5 rounded-md border border-[#FED7AA]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E0532B] inline-block" />
                CC
              </span>
              <button
                onClick={() => setSubTrackLocked(!subTrackLocked)}
                className="text-[#78716C] hover:text-[#1C1C1E] transition p-0.5"
              >
                {subTrackLocked ? <Lock className="w-3 h-3 text-[#C2410C]" /> : <Unlock className="w-3 h-3" />}
              </button>
            </div>
            <span className="text-[9.5px] text-[#78716C] font-medium">{segments.length} كابشن</span>
          </div>

          {/* V1 Video Header (h-12 = 48px) */}
          <div className="h-12 px-2 py-1.5 border-b border-[#E5E0D8] bg-[#FAF9F7] flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[10.5px] text-[#1D4ED8] font-mono flex items-center gap-1.5 bg-[#EFF6FF] px-1.5 py-0.5 rounded-md border border-[#BFDBFE]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#2563EB] inline-block" />
                V1
              </span>
              <button
                onClick={() => setVideoTrackMuted(!videoTrackMuted)}
                className="text-[#78716C] hover:text-[#1C1C1E] transition p-0.5"
              >
                {videoTrackMuted ? <EyeOff className="w-3 h-3 text-[#E11D48]" /> : <Eye className="w-3 h-3" />}
              </button>
            </div>
            <span className="text-[9.5px] text-[#78716C] font-medium">فيديو</span>
          </div>

          {/* A1 Audio Header (h-12 = 48px) */}
          <div className="h-12 px-2 py-1.5 bg-[#FAF9F7] flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[10.5px] text-[#0F766E] font-mono flex items-center gap-1.5 bg-[#F0FDF4] px-1.5 py-0.5 rounded-md border border-[#BBF7D0]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#0D9488] inline-block" />
                A1
              </span>
              <button
                onClick={() => setAudioTrackMuted(!audioTrackMuted)}
                className={`px-1.5 py-0.5 rounded text-[8.5px] font-bold transition ${
                  audioTrackMuted ? 'bg-[#E11D48] text-white' : 'bg-white text-[#554F47] hover:text-[#1C1C1E] border border-[#E5E0D8]'
                }`}
              >
                M
              </button>
            </div>
            <span className="text-[9.5px] text-[#78716C] font-medium">صوت</span>
          </div>
        </div>

        {/* Multi-Track Scroll Canvas (Clean Light SaaS Track Canvas) */}
        <div
          ref={tracksScrollRef}
          onMouseDown={handleTrackAreaMouseDown}
          dir="ltr"
          className="flex-1 overflow-x-auto overflow-y-hidden relative bg-[#F6F5F3] scrollbar-thin scrollbar-thumb-[#D5CFBF]"
        >
          <div style={{ width: `${timelineWidth}px` }} className="relative h-full select-none">
            {/* Top Time Ruler (h-6 = 24px) */}
            <div
              ref={rulerRef}
              onMouseDown={handleRulerMouseDown}
              className="h-6 bg-[#FAF9F7] border-b border-[#E5E0D8] relative cursor-pointer"
            >
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#E0532B] via-[#7C3AED] to-[#2563EB]" />
              {renderRulerTicks()}
            </div>

            {/* Track 1: CC Subtitle Track (h-14 = 56px) */}
            <div className="h-14 relative border-b border-[#E5E0D8] bg-[#FAF9F7]/60 overflow-hidden">
              {segments.map((seg) => {
                const clipLeft = timeToPx(seg.start);
                const clipWidth = Math.max(16, timeToPx(seg.end - seg.start));
                const isSelected = selectedSegmentIds.includes(seg.id);
                const isCurrentlyPlaying = currentTime >= seg.start && currentTime <= seg.end;

                return (
                  <div
                    key={seg.id}
                    onClick={(e) => handleClipClick(e, seg)}
                    onMouseDown={(e) => {
                      if (activeTool === 'select' && !subTrackLocked) {
                        e.stopPropagation();
                        if (!selectedSegmentIds.includes(seg.id) && !e.shiftKey && !e.ctrlKey) {
                          onSelectSegments([seg.id]);
                        }
                        const starts: Record<number, number> = {};
                        const ends: Record<number, number> = {};
                        for (const s of segments) {
                          starts[s.id] = s.start;
                          ends[s.id] = s.end;
                        }
                        setDragAction({
                          type: 'move',
                          targetId: seg.id,
                          initialMouseX: e.clientX,
                          initialStarts: starts,
                          initialEnds: ends,
                        });
                      }
                    }}
                    style={{
                      left: `${clipLeft}px`,
                      width: `${clipWidth}px`,
                    }}
                    className={`absolute top-1 bottom-1 rounded-lg flex flex-col overflow-hidden cursor-move transition-all ${
                      isSelected
                        ? 'bg-[#7C3AED] border-2 border-white shadow-md ring-2 ring-[#E0532B] z-20'
                        : isCurrentlyPlaying
                        ? 'bg-[#8B5CF6] border border-[#2563EB] z-10 shadow-xs'
                        : 'bg-[#8B5CF6] hover:bg-[#7C3AED] border border-[#7C3AED] shadow-2xs'
                    }`}
                  >
                    {/* Clip Top Header */}
                    <div className="h-3.5 bg-[#6D28D9]/40 px-1.5 flex items-center justify-between text-[8.5px] font-mono text-white/95 border-b border-white/20">
                      <span className="font-bold">CC {seg.id}</span>
                      <span className="text-[7.5px] text-white/80 hidden sm:inline" dir="ltr">
                        {(seg.end - seg.start).toFixed(1)}s
                      </span>
                    </div>

                    {/* Clip Text */}
                    <div className="flex-1 px-1.5 text-[10.5px] leading-tight text-white font-semibold truncate flex items-center">
                      <span className="truncate">{seg.text}</span>
                    </div>

                    {/* Left Trim Handle */}
                    <div
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        if (!subTrackLocked) {
                          const starts: Record<number, number> = {};
                          const ends: Record<number, number> = {};
                          for (const s of segments) {
                            starts[s.id] = s.start;
                            ends[s.id] = s.end;
                          }
                          setDragAction({
                            type: 'trim-start',
                            targetId: seg.id,
                            initialMouseX: e.clientX,
                            initialStarts: starts,
                            initialEnds: ends,
                          });
                        }
                      }}
                      className="absolute top-0 bottom-0 left-0 w-2 cursor-ew-resize hover:bg-white/40"
                    />

                    {/* Right Trim Handle */}
                    <div
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        if (!subTrackLocked) {
                          const starts: Record<number, number> = {};
                          const ends: Record<number, number> = {};
                          for (const s of segments) {
                            starts[s.id] = s.start;
                            ends[s.id] = s.end;
                          }
                          setDragAction({
                            type: 'trim-end',
                            targetId: seg.id,
                            initialMouseX: e.clientX,
                            initialStarts: starts,
                            initialEnds: ends,
                          });
                        }
                      }}
                      className="absolute top-0 bottom-0 right-0 w-2 cursor-ew-resize hover:bg-white/40"
                    />
                  </div>
                );
              })}
            </div>

            {/* Track 2: V1 Video Track (h-12 = 48px) - Soft distinct bar shapes (مسار الفيديو الرئيسي) */}
            <div className="h-12 relative border-b border-[#E5E0D8] bg-[#FAF9F7]/80 overflow-hidden">
              {(!videoCuts || videoCuts.length === 0) ? (
                <div
                  style={{ width: `${timeToPx(effectiveDuration)}px` }}
                  className="h-8 my-2 mx-1 bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] border border-[#1D4ED8] rounded-lg shadow-2xs flex items-center px-3 gap-2"
                >
                  <span className="text-[11px] font-bold text-white truncate">
                    مسار الفيديو الرئيسي ({effectiveDuration.toFixed(1)}s)
                  </span>
                </div>
              ) : (
                videoCuts.map((cut, idx) => {
                  const cutLeft = timeToPx(cut.start);
                  const cutWidth = Math.max(20, timeToPx(cut.end - cut.start));
                  const isCutSelected = selectedCutId === cut.id;
                  const isCurrent = currentTime >= cut.start && currentTime <= cut.end;

                  return (
                    <div
                      key={cut.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onSelectCut) onSelectCut(cut.id);
                      }}
                      style={{
                        left: `${cutLeft}px`,
                        width: `${cutWidth}px`,
                      }}
                      className={`absolute top-1 bottom-1 rounded-lg flex flex-col justify-between overflow-hidden cursor-pointer transition select-none shadow-2xs ${
                        isCutSelected
                          ? 'bg-[#2563EB] border-2 border-white shadow-md ring-2 ring-[#E0532B] z-20'
                          : isCurrent
                          ? 'bg-[#2563EB] border border-[#93C5FD] z-10'
                          : 'bg-[#3B82F6] hover:bg-[#2563EB] border border-[#2563EB]'
                      }`}
                      title={`مقطع فيديو ${idx + 1} (${cut.start.toFixed(1)}s - ${cut.end.toFixed(1)}s)`}
                    >
                      <div className="h-3.5 bg-[#1E40AF]/50 px-1.5 flex items-center justify-between text-[8.5px] text-white/95 border-b border-white/20">
                        <span className="font-bold truncate">{cut.label || `مقطع ${idx + 1}`}</span>
                        <span className="text-[7.5px] font-mono text-white/80" dir="ltr">
                          {(cut.end - cut.start).toFixed(1)}s
                        </span>
                      </div>
                      <div className="flex-1 px-1.5 flex items-center justify-between text-[9px] text-white font-medium">
                        <span className="truncate text-white/90 font-mono text-[8px]" dir="ltr">
                          {formatTimecodePremiere(cut.start)}
                        </span>
                        {isCutSelected && onDeleteCut && videoCuts.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteCut(cut.id);
                            }}
                            className="p-0.5 rounded bg-red-600 hover:bg-red-700 text-white text-[8px]"
                            title="حذف هذا المقطع المقصوص"
                          >
                            <Trash2 className="w-2.5 h-2.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Track 3: A1 Audio Track (h-12 = 48px) - Dialogue Waveform */}
            <div className="h-12 relative bg-[#FAF9F7]/60 flex items-center px-1 overflow-hidden">
              <div
                style={{ width: `${timeToPx(effectiveDuration)}px` }}
                className="h-8 bg-[#CCFBF1] border border-[#5EEAD4] rounded-lg relative overflow-hidden flex items-center shadow-2xs"
              >
                <div className="absolute inset-0 flex items-center justify-between px-2 opacity-80">
                  {Array.from({ length: Math.min(140, Math.ceil(timelineWidth / 8)) }).map((_, idx) => {
                    const ratio = idx / Math.min(140, Math.ceil(timelineWidth / 8));
                    const approxTime = ratio * effectiveDuration;
                    const hasSpeech = segments.some(
                      (s) => approxTime >= s.start && approxTime <= s.end
                    );
                    const heightPct = hasSpeech
                      ? 35 + Math.sin(idx * 7) * 25 + Math.cos(idx * 3) * 20
                      : 10;
                    return (
                      <div
                        key={idx}
                        style={{ height: `${Math.max(6, Math.min(90, heightPct))}%` }}
                        className={`w-1 rounded-full ${hasSpeech ? 'bg-[#0D9488]' : 'bg-[#14B8A6]/30'}`}
                      />
                    );
                  })}
                </div>
                <span className="relative z-10 text-[9.5px] font-mono text-[#0F766E] font-bold ml-2">
                  Dialogue Waveform
                </span>
              </div>
            </div>

            {/* Marquee Selection Rectangle Box */}
            {marquee && (
              <div
                style={{
                  left: `${Math.min(marquee.startX, marquee.currentX)}px`,
                  top: `${Math.min(marquee.startY, marquee.currentY)}px`,
                  width: `${Math.abs(marquee.currentX - marquee.startX)}px`,
                  height: `${Math.abs(marquee.currentY - marquee.startY)}px`,
                }}
                className="absolute border border-[#E0532B] bg-[#E0532B]/15 pointer-events-none z-40 rounded-md"
              />
            )}

            {/* Precision Blue Playhead Line */}
            <div
              style={{ left: `${timeToPx(currentTime)}px` }}
              className="absolute top-0 bottom-0 pointer-events-none z-30"
            >
              <div className="relative -left-2 top-0 w-4 h-6 flex flex-col items-center">
                <div className="w-4 h-3 bg-[#2563EB] text-white flex items-center justify-center rounded-t-xs shadow-xs">
                  <div className="w-1 h-1 bg-white rounded-full" />
                </div>
                <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[6px] border-t-[#2563EB]" />
              </div>
              <div className="w-[1.5px] h-full bg-[#2563EB] shadow-[0_0_5px_rgba(37,99,235,0.7)] -ml-[0.75px]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
