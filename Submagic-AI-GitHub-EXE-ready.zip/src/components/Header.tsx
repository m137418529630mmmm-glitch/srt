import React from 'react';
import { Sparkles, Video, Settings, Download, Film, Zap, CheckCircle, AlertTriangle } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenExport: () => void;
  onLoadSample: () => void;
  hasVideo: boolean;
  groqConnected: boolean;
  geminiConnected: boolean;
  segmentCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  onOpenExport,
  onLoadSample,
  hasVideo,
  groqConnected,
  geminiConnected,
  segmentCount,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#0B0F19]/90 backdrop-blur-md px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Logo and Brand: mediaLab publishing */}
        <div className="flex items-center gap-3">
          <div className="flex flex-col leading-none">
            <span className="font-sans font-bold text-xl text-[#18181B] tracking-tight">
              media<span className="font-extrabold">Lab</span>
            </span>
            <span className="font-sans font-medium text-xs text-[#27272A] -mt-0.5">
              publishing
            </span>
          </div>
          <div>
            <span className="text-[11px] font-semibold text-[#8D827A] uppercase tracking-wider hidden sm:block">
              VIDEO SUITE & CAPTION STUDIO
            </span>
          </div>
        </div>

        {/* API Status Pills */}
        <div className="hidden md:flex items-center gap-2 text-xs">
          <button
            onClick={onOpenSettings}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition ${
              groqConnected
                ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-amber-400'
            }`}
            title="Groq Whisper API Status"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-medium font-mono text-[11px]">Groq Whisper</span>
            {groqConnected ? (
              <CheckCircle className="w-3 h-3 text-emerald-400" />
            ) : (
              <span className="text-[10px] bg-amber-500/20 px-1.5 py-0.2 rounded text-amber-300">أضف مفتاحك</span>
            )}
          </button>

          <div
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30"
            title="Google Gemini API Status"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span className="font-medium text-[11px]">Gemini 3.8</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Load Sample button */}
          <button
            onClick={onLoadSample}
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 rounded-xl transition"
            title="تجربة فيديو عينة مع كابشن جاهز"
          >
            <Film className="w-4 h-4 text-purple-400" />
            <span>تجربة فيديو عينة</span>
          </button>

          {/* Settings button */}
          <button
            onClick={onOpenSettings}
            className="p-2 text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-700/70 border border-slate-700 rounded-xl transition"
            title="إعدادات API"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Render & Export Video button */}
          <button
            onClick={onOpenExport}
            disabled={!hasVideo || segmentCount === 0}
            className={`flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition shadow-lg ${
              hasVideo && segmentCount > 0
                ? 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 hover:brightness-110 shadow-emerald-500/25 active:scale-95 cursor-pointer'
                : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>رندر وتنزيل الفيديو ({segmentCount})</span>
          </button>
        </div>
      </div>
    </header>
  );
};
