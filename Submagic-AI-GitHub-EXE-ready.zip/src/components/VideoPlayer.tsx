import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Maximize2,
  Upload,
  Sparkles,
  Film,
  Scissors,
  Clock,
  Eye,
  EyeOff,
} from 'lucide-react';
import { SubtitleSegment, SubtitleStylePreset, CaptionVisibilityRange } from '../types';
import { formatTimeDisplay } from '../utils/srt';
import { drawSubtitlesOnCanvas } from '../utils/videoRenderer';

interface VideoPlayerProps {
  videoSrc: string | null;
  videoElementRef: React.RefObject<HTMLVideoElement | null>;
  segments: SubtitleSegment[];
  activePreset: SubtitleStylePreset;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  onTimeUpdate: (time: number) => void;
  onDurationChange: (duration: number) => void;
  onPlayPause: () => void;
  onSeek: (time: number) => void;
  onFileUpload: (file: File) => void;
  onLoadSample: () => void;
  captionVisibilityRange: CaptionVisibilityRange;
  onUpdateCaptionVisibilityRange: (range: CaptionVisibilityRange) => void;
  onTrimSilence: () => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  videoSrc,
  videoElementRef,
  segments,
  activePreset,
  currentTime,
  duration,
  isPlaying,
  onTimeUpdate,
  onDurationChange,
  onPlayPause,
  onSeek,
  onFileUpload,
  onLoadSample,
  captionVisibilityRange,
  onUpdateCaptionVisibilityRange,
  onTrimSilence,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [showRangeSettings, setShowRangeSettings] = useState(false);

  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '16:9' | 'auto'>('auto');

  // Handle video element time events
  const handleTimeUpdate = () => {
    if (videoElementRef.current) {
      onTimeUpdate(videoElementRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoElementRef.current) {
      onDurationChange(videoElementRef.current.duration);
      // Auto detect 9:16 vs 16:9
      const w = videoElementRef.current.videoWidth;
      const h = videoElementRef.current.videoHeight;
      if (h > w * 1.3) {
        setAspectRatio('9:16');
      } else if (w > h * 1.3) {
        setAspectRatio('16:9');
      }
    }
  };

  // Render subtitles on overlay canvas in real time
  const renderOverlay = useCallback(() => {
    const canvas = canvasRef.current;
    const video = videoElementRef.current;
    if (!canvas || !video) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Match canvas internal resolution to video source or container
    const width = video.videoWidth || 1080;
    const height = video.videoHeight || 1920;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const activeSeg = segments.find(
      (s) => currentTime >= s.start && currentTime <= s.end
    ) || null;

    drawSubtitlesOnCanvas({
      ctx,
      canvasWidth: width,
      canvasHeight: height,
      activeSegment: activeSeg,
      preset: activePreset,
      currentTime,
      captionVisibilityRange,
      autoHideSilence: true,
    });
  }, [currentTime, segments, activePreset, videoElementRef, captionVisibilityRange]);

  // Request animation frame for smooth animated subtitles during playback
  useEffect(() => {
    let animId: number;
    const loop = () => {
      renderOverlay();
      if (isPlaying) {
        animId = requestAnimationFrame(loop);
      }
    };
    renderOverlay();
    if (isPlaying) {
      animId = requestAnimationFrame(loop);
    }
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, renderOverlay]);

  // Drag and drop handlers
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('video/')) {
        onFileUpload(file);
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const toggleMute = () => {
    if (videoElementRef.current) {
      videoElementRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const cycleSpeed = () => {
    const speeds = [1, 1.25, 1.5, 2, 0.75];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setPlaybackSpeed(nextSpeed);
    if (videoElementRef.current) {
      videoElementRef.current.playbackRate = nextSpeed;
    }
  };

  const skipSeconds = (seconds: number) => {
    if (videoElementRef.current) {
      const newTime = Math.max(0, Math.min(duration, currentTime + seconds));
      videoElementRef.current.currentTime = newTime;
      onSeek(newTime);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0F172A]/70 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
      {/* Aspect Ratio & Quick Toolbar */}
      <div className="flex flex-wrap items-center justify-between px-4 py-2 bg-slate-900/60 border-b border-slate-800/80 text-xs gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-400 font-medium">أبعاد الشاشة:</span>
          <div className="flex bg-slate-800/80 p-0.5 rounded-lg border border-slate-700/60">
            <button
              onClick={() => setAspectRatio('9:16')}
              className={`px-2.5 py-1 rounded-md transition ${
                aspectRatio === '9:16'
                  ? 'bg-purple-600 text-white font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              9:16 (Shorts/Reels)
            </button>
            <button
              onClick={() => setAspectRatio('16:9')}
              className={`px-2.5 py-1 rounded-md transition ${
                aspectRatio === '16:9'
                  ? 'bg-purple-600 text-white font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              16:9 (عريض)
            </button>
            <button
              onClick={() => setAspectRatio('auto')}
              className={`px-2.5 py-1 rounded-md transition ${
                aspectRatio === 'auto'
                  ? 'bg-purple-600 text-white font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              تلقائي
            </button>
          </div>

          {/* Caption Visibility Range Button (طلب المستخدم: تحديد حتى أين يظهر الكلام) */}
          <button
            onClick={() => setShowRangeSettings(!showRangeSettings)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition ${
              captionVisibilityRange.enabled
                ? 'bg-cyan-600/30 text-cyan-300 border-cyan-500/50 font-bold'
                : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title="تحديد نطاق زمني مخصص لظهور الكابشن (اختياري)"
          >
            {captionVisibilityRange.enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>نطاق ظهور الكابشن</span>
          </button>

          {/* Trim Silence Button (طلب المستخدم: إخفاء الكابشن عند الصمت) */}
          <button
            onClick={onTrimSilence}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-300 hover:text-amber-300 transition text-[11px]"
            title="تقليم فترات الصمت لتجنب بقاء آخر كلمة ظاهرة عند التوقف عن الكلام"
          >
            <Scissors className="w-3 h-3 text-amber-400" />
            <span>تنظيف فترات الصمت</span>
          </button>
        </div>

        {videoSrc && (
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800/60 hover:bg-slate-800 transition"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>تغيير الفيديو</span>
          </button>
        )}
      </div>

      {/* Caption Visibility Range Settings Bar */}
      {showRangeSettings && (
        <div className="px-4 py-2.5 bg-slate-950/90 border-b border-cyan-500/30 flex flex-wrap items-center justify-between gap-3 text-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-slate-200">نطاق ظهور الكابشن في الفيديو:</span>
            <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 mr-2">
              <input
                type="checkbox"
                checked={captionVisibilityRange.enabled}
                onChange={(e) =>
                  onUpdateCaptionVisibilityRange({
                    ...captionVisibilityRange,
                    enabled: e.target.checked,
                  })
                }
                className="rounded accent-cyan-500"
              />
              <span>تفعيل التحديد الزمني</span>
            </label>
          </div>

          {captionVisibilityRange.enabled ? (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-slate-400 text-[11px]">من:</span>
              <input
                type="number"
                min={0}
                max={captionVisibilityRange.endTime - 1}
                value={captionVisibilityRange.startTime}
                onChange={(e) =>
                  onUpdateCaptionVisibilityRange({
                    ...captionVisibilityRange,
                    startTime: Math.max(0, parseFloat(e.target.value) || 0),
                  })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-center font-mono text-cyan-300"
              />

              <span className="text-slate-400 text-[11px]">إلى (ثانية):</span>
              <input
                type="number"
                min={captionVisibilityRange.startTime + 1}
                max={duration || 1800}
                value={captionVisibilityRange.endTime}
                onChange={(e) =>
                  onUpdateCaptionVisibilityRange({
                    ...captionVisibilityRange,
                    endTime: Math.max(captionVisibilityRange.startTime + 1, parseFloat(e.target.value) || 180),
                  })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-center font-mono text-cyan-300"
              />
              <span className="text-[10.5px] font-mono text-cyan-400/80 bg-slate-900/60 px-1.5 py-0.5 rounded" dir="ltr">
                {formatTimeDisplay(captionVisibilityRange.endTime)}
              </span>

              <div className="flex items-center gap-1 mr-1">
                <button
                  type="button"
                  onClick={() =>
                    onUpdateCaptionVisibilityRange({
                      enabled: true,
                      startTime: 0,
                      endTime: 60,
                    })
                  }
                  className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300 text-[10.5px] hover:bg-slate-800"
                >
                  أول دقيقة
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onUpdateCaptionVisibilityRange({
                      enabled: true,
                      startTime: 0,
                      endTime: 120,
                    })
                  }
                  className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300 text-[10.5px] hover:bg-slate-800"
                >
                  أول دقيقتين
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onUpdateCaptionVisibilityRange({
                      enabled: false,
                      startTime: 0,
                      endTime: duration || 999999,
                    })
                  }
                  className="px-2.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold text-[10.5px] hover:bg-emerald-900"
                >
                  كامل الفيديو ✨
                </button>
              </div>
            </div>
          ) : (
            <span className="text-slate-400 text-[11px]">الكابشن يظهر على كامل مدة الفيديو</span>
          )}
        </div>
      )}

      {/* Main Video Viewport */}
      <div
        ref={containerRef}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`relative flex-1 min-h-[360px] max-h-[580px] bg-black flex items-center justify-center overflow-hidden transition ${
          isDragging ? 'ring-2 ring-purple-500 bg-purple-950/20' : ''
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => {
            if (e.target.files && e.target.files[0]) {
              onFileUpload(e.target.files[0]);
            }
          }}
        />

        {videoSrc ? (
          <div
            className={`relative flex items-center justify-center max-w-full max-h-full ${
              aspectRatio === '9:16'
                ? 'aspect-[9/16] h-full mx-auto'
                : aspectRatio === '16:9'
                ? 'aspect-[16/9] w-full max-w-2xl'
                : 'h-full max-h-full'
            }`}
          >
            {/* The Video Element */}
            <video
              ref={videoElementRef}
              src={videoSrc}
              playsInline
              crossOrigin={
                videoSrc && !videoSrc.startsWith('blob:') && !videoSrc.startsWith('data:')
                  ? 'anonymous'
                  : undefined
              }
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onClick={onPlayPause}
              className="w-full h-full object-contain cursor-pointer select-none"
            />

            {/* Subtitle Canvas Overlay (mirrors video exactly) */}
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full pointer-events-none object-contain"
            />
          </div>
        ) : (
          /* Empty State / Upload Zone */
          <div className="flex flex-col items-center justify-center p-8 text-center max-w-md">
            <div className="w-16 h-16 rounded-2xl bg-purple-600/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-4 shadow-lg shadow-purple-600/10">
              <Upload className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 font-['Tajawal']">
              اسحب وأفلت الفيديو هنا
            </h3>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              يدعم مقاطع MP4 و WebM و MOV حتى دقة 4K. سنقوم باستخراج الصوت وتوليد ملف SRT وتصميم كابشن جذاب ورندره في ثوانٍ.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-5 py-2.5 text-xs font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-xl shadow-lg shadow-purple-600/25 transition active:scale-95"
              >
                اختيار فيديو من جهازك
              </button>

              <button
                onClick={onLoadSample}
                className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition"
              >
                <Film className="w-4 h-4 text-amber-400" />
                <span>تجربة فيديو عينة جاهز</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Playback Controls & Scrubber */}
      {videoSrc && (
        <div className="p-3 bg-slate-900/90 border-t border-slate-800 space-y-2">
          {/* Timeline Scrubber with Subtitle Marks */}
          <div className="relative group">
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.05}
              value={currentTime}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                onSeek(val);
                if (videoElementRef.current) {
                  videoElementRef.current.currentTime = val;
                }
              }}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-purple-500 transition focus:outline-none"
            />

            {/* Segment highlight ticks on the timeline */}
            {duration > 0 && (
              <div className="absolute inset-0 pointer-events-none flex items-center">
                {segments.map((seg) => {
                  const left = (seg.start / duration) * 100;
                  const width = ((seg.end - seg.start) / duration) * 100;
                  return (
                    <div
                      key={seg.id}
                      style={{ left: `${left}%`, width: `${width}%` }}
                      className="absolute h-1.5 bg-amber-400/50 rounded-full"
                    />
                  );
                })}
              </div>
            )}
          </div>

          {/* Time & Playback buttons */}
          <div className="flex items-center justify-between text-xs">
            {/* Play/Pause & Skips */}
            <div className="flex items-center gap-2">
              <button
                onClick={onPlayPause}
                className="w-9 h-9 rounded-xl bg-purple-600 hover:bg-purple-500 text-white flex items-center justify-center shadow-md shadow-purple-600/30 transition active:scale-90"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
              </button>

              <button
                onClick={() => skipSeconds(-2)}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                title="رجوع ثانيتين (-2s)"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={() => skipSeconds(2)}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                title="تقديم ثانيتين (+2s)"
              >
                <RotateCw className="w-4 h-4" />
              </button>

              {/* Time display */}
              <div className="font-mono text-slate-300 px-2 py-1 rounded bg-slate-800/80 border border-slate-700/50 text-[11px]" dir="ltr">
                <span>{formatTimeDisplay(currentTime)}</span>
                <span className="text-slate-500 mx-1">/</span>
                <span className="text-slate-500">{formatTimeDisplay(duration)}</span>
              </div>
            </div>

            {/* Secondary Controls (Speed & Mute) */}
            <div className="flex items-center gap-2">
              <button
                onClick={cycleSpeed}
                className="px-2 py-1 font-mono text-[11px] font-bold rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 transition"
                title="سرعة التشغيل"
              >
                {playbackSpeed}x
              </button>

              <button
                onClick={toggleMute}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                title={isMuted ? 'إلغاء كتم الصوت' : 'كتم الصوت'}
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
