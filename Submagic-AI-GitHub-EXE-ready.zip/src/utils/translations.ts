export type Language = 'en' | 'ar';

export interface Translations {
  // Header
  appTitle: string;
  subtitleCount: string;
  exportVideoMp4: string;
  settings: string;
  sampleVideo: string;
  languageToggle: string;
  videoSuite: string;

  // Tabs
  projectBin: string;
  captionsSrt: string;
  essentialGraphics: string;
  effectControls: string;

  // Program Monitor
  programMonitor: string;
  aspectRatio: string;
  aspectAuto: string;
  exportMp4Short: string;
  safeArea: string;
  greenScreen: string;
  dragDropTitle: string;
  dragDropSub: string;
  chooseFileBtn: string;
  loadSampleBtn: string;

  // Captions Toolbar
  generateGroq: string;
  transcribeAudio: string;
  transcribeOriginal: string;
  transcribeArabic: string;
  transcribeEnglish: string;
  translateCaptions: string;
  translateToArabic: string;
  translateToEnglish: string;
  translateToFrench: string;
  translateToSpanish: string;
  smartResegment: string;
  smartKeywords: string;
  featuredCaptions: string;
  grammarCheck: string;
  addSegment: string;
  downloadSrt: string;
  downloadVtt: string;
  downloadTxt: string;
  timingControl: string;
  timingControlHint: string;
  trimSilence: string;
  searchCaptions: string;
  noCaptions: string;
  clickKeywordHint: string;

  // Timeline
  sequence01: string;
  splitCaption: string;
  splitVideo: string;
  groupClips: string;
  deleteClip: string;
  zoomTimeline: string;
  fitTimeline: string;
  videoTrack: string;
  audioTrack: string;
  subTrack: string;
  undo: string;
  redo: string;
  mouseWheelHint: string;

  // Layout Controls
  layoutPreset: string;
  layoutDefault: string;
  layoutMonitorFocus: string;
  layoutTimelineFocus: string;
  resetLayout: string;

  // Processing
  processingTitle: string;
  cancel: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appTitle: 'AI Smart Subtitles & Video Studio',
    subtitleCount: 'captions',
    exportVideoMp4: 'Export Video (MP4)',
    settings: 'Settings & APIs',
    sampleVideo: 'Load Sample',
    languageToggle: 'العربية',
    videoSuite: 'VIDEO SUITE & CAPTIONS',

    projectBin: 'Project: Bin',
    captionsSrt: 'Captions & Subtitles',
    essentialGraphics: 'Essential Graphics',
    effectControls: 'Effect Controls',

    programMonitor: 'Program Monitor',
    aspectRatio: 'Aspect Ratio',
    aspectAuto: 'Auto',
    exportMp4Short: 'Export MP4',
    safeArea: 'Safe Margins',
    greenScreen: 'Green Screen',
    dragDropTitle: 'Drag & Drop Video or Audio Here',
    dragDropSub: 'Supports MP4, MOV, WebM, MP3, WAV, M4A with high fidelity speech sync',
    chooseFileBtn: 'Choose Video or Audio File',
    loadSampleBtn: 'Load Sample Demo Video',

    generateGroq: 'Generate with Groq Whisper',
    transcribeAudio: 'Transcribe Audio',
    transcribeOriginal: 'Transcribe Original Audio',
    transcribeArabic: 'Transcribe & Translate to Arabic',
    transcribeEnglish: 'Transcribe & Translate to English',
    translateCaptions: 'Translate Captions (Gemini AI)',
    translateToArabic: 'Translate to Arabic (العربية)',
    translateToEnglish: 'Translate to English (الإنجليزية)',
    translateToFrench: 'Translate to French (الفرنسية)',
    translateToSpanish: 'Translate to Spanish (الإسبانية)',
    smartResegment: 'Format & Group Sentences',
    smartKeywords: 'Smart Keyword Coloring',
    featuredCaptions: 'Featured Captions',
    grammarCheck: 'Grammar & Spell Check',
    addSegment: 'Add Subtitle Line',
    downloadSrt: 'Export SRT',
    downloadVtt: 'Download .VTT',
    downloadTxt: 'Download Text (.TXT)',
    timingControl: 'Timing & Audio Sync Offset',
    timingControlHint: '(Fix early or delayed speech)',
    trimSilence: 'Trim Silence Gaps 🧹',
    searchCaptions: 'Search in subtitles... 🔍',
    noCaptions: 'No subtitle segments yet',
    clickKeywordHint: 'Click to highlight key term:',

    sequence01: 'Sequence 01',
    splitCaption: 'Split Caption [S]',
    splitVideo: 'Split Video [C]',
    groupClips: 'Group [M]',
    deleteClip: 'Delete [A]',
    zoomTimeline: 'Zoom Timeline',
    fitTimeline: 'Fit',
    videoTrack: 'Main Video Track',
    audioTrack: 'Dialogue Waveform',
    subTrack: 'Captions Track',
    undo: 'Undo (Ctrl+Z)',
    redo: 'Redo (Ctrl+Y)',
    mouseWheelHint: 'Mouse wheel to scroll horizontally | Alt+Wheel to Zoom',

    layoutPreset: 'Layout',
    layoutDefault: 'Default',
    layoutMonitorFocus: 'Monitor Focus',
    layoutTimelineFocus: 'Timeline Focus',
    resetLayout: 'Reset Panels',

    processingTitle: 'Processing with AI...',
    cancel: 'Cancel',
  },
  ar: {
    appTitle: 'محرر وترجمة الكابشن المتزامن الذكي',
    subtitleCount: 'كابشن',
    exportVideoMp4: 'تصدير الفيديو (MP4)',
    settings: 'الإعدادات والذكاء الاصطناعي',
    sampleVideo: 'عينة تجريبية',
    languageToggle: 'English',
    videoSuite: 'منصة مونتاج وكابشن الفيديو',

    projectBin: 'Project: Bin',
    captionsSrt: 'Text / Subtitles (SRT)',
    essentialGraphics: 'Essential Graphics',
    effectControls: 'Effect Controls',

    programMonitor: 'برنامج المونيتور (Program Monitor)',
    aspectRatio: 'نسبة الأبعاد',
    aspectAuto: 'تلقائي',
    exportMp4Short: 'تصدير الفيديو (MP4)',
    safeArea: 'Safe Area',
    greenScreen: 'شاشة خضراء',
    dragDropTitle: 'اسحب وأفلت ملف الفيديو أو الصوت هنا',
    dragDropSub: 'يدعم صيغ MP4, MOV, WebM, MP3, WAV, M4A مع مزامنة نطق فورية',
    chooseFileBtn: 'اختيار ملف فيديو أو صوت',
    loadSampleBtn: 'تجربة عينة فيديو جاهزة',

    generateGroq: 'توليد بـ Groq Whisper',
    transcribeAudio: 'تفريغ صوتي',
    transcribeOriginal: '🎙️ تفريغ باللغة الأصلية',
    transcribeArabic: '🌐 تفريغ وترجمة للعربية',
    transcribeEnglish: '🇺🇸 تفريغ وترجمة للإنجليزية',
    translateCaptions: 'ترجمة الكابشن (Gemini AI)',
    translateToArabic: '🇸🇦 ترجمة إلى العربية',
    translateToEnglish: '🇺🇸 ترجمة إلى الإنجليزية',
    translateToFrench: '🇫🇷 ترجمة إلى الفرنسية',
    translateToSpanish: '🇪🇸 ترجمة إلى الإسبانية',
    smartResegment: 'تنسيق ودمج الجمل',
    smartKeywords: 'تلوين الكلمات الذكي',
    featuredCaptions: 'الكابشن المميز',
    grammarCheck: 'تدقيق لغوي',
    addSegment: 'إضافة سطر',
    downloadSrt: 'تحميل SRT',
    downloadVtt: 'تنزيل ملف .VTT',
    downloadTxt: 'تنزيل النص خام (.TXT)',
    timingControl: 'ضبط توقيت ومزامنة الكابشن',
    timingControlHint: '(إذا كان الكلام يظهر متأخراً أو متقدماً)',
    trimSilence: 'تحميل توقيت السكوت 🧹',
    searchCaptions: 'بحث في الكابشن... 🔍',
    noCaptions: 'لا توجد أسطر كابشن حالياً',
    clickKeywordHint: 'انقر لتحديد المصطلح البارز:',

    sequence01: 'Sequence 01',
    splitCaption: 'قص كابشن [S]',
    splitVideo: 'قص فيديو [C]',
    groupClips: 'تجميع [M]',
    deleteClip: 'حذف [A]',
    zoomTimeline: 'تكبير التايم لاين',
    fitTimeline: 'Fit',
    videoTrack: 'مسار الفيديو الرئيسي',
    audioTrack: 'Dialogue Waveform',
    subTrack: 'مسار الكابشن',
    undo: 'تراجع (Ctrl+Z)',
    redo: 'إعادة (Ctrl+Y)',
    mouseWheelHint: 'عجلة الماوس للتمرير يميناً ويساراً | Alt+العجلة للزووم',

    layoutPreset: 'تنسيق الواجهة',
    layoutDefault: 'افتراضي',
    layoutMonitorFocus: 'تركيز الشاشة',
    layoutTimelineFocus: 'تركيز التايم لاين',
    resetLayout: 'استعادة الأبعاد',

    processingTitle: 'جاري المعالجة بالذكاء الاصطناعي...',
    cancel: 'إلغاء',
  },
};
