import { SubtitleSegment, SubtitleStylePreset, SubtitleWord } from '../types';
import { CATEGORY_COLORS } from '../constants/presets';

interface DrawSubtitleOptions {
  ctx: CanvasRenderingContext2D;
  canvasWidth: number;
  canvasHeight: number;
  activeSegment: SubtitleSegment | null;
  preset: SubtitleStylePreset;
  currentTime: number;
  captionVisibilityRange?: {
    enabled: boolean;
    startTime: number;
    endTime: number;
  };
  autoHideSilence?: boolean;
  backgroundMode?: 'transparent' | 'greenscreen' | 'black';
}

export function drawSubtitlesOnCanvas({
  ctx,
  canvasWidth,
  canvasHeight,
  activeSegment,
  preset,
  currentTime,
  captionVisibilityRange,
  autoHideSilence = true,
  backgroundMode = 'transparent',
}: DrawSubtitleOptions) {
  if (backgroundMode === 'greenscreen') {
    ctx.fillStyle = '#00FF00';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
  } else if (backgroundMode === 'black') {
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
  }

  if (!activeSegment || !activeSegment.text) return;

  // 1. Caption Visibility Range filter (e.g. only first 3 minutes)
  if (captionVisibilityRange && captionVisibilityRange.enabled) {
    if (currentTime < captionVisibilityRange.startTime || currentTime > captionVisibilityRange.endTime) {
      return;
    }
  }

  // Prepare text words
  const rawWords = activeSegment.text.trim().split(/\s+/);
  if (rawWords.length === 0) return;

  // Strict speech synchronization: Appears when speech begins, vanishes immediately when speech stops
  if (currentTime < activeSegment.start || currentTime > activeSegment.end) {
    return;
  }

  ctx.save();

  // Scale font size proportionally to video height (base height 1080)
  const scale = canvasHeight / 1080;
  const fontSize = Math.max(18, Math.round(preset.fontSize * scale));
  const strokeWidth = Math.max(2, Math.round(preset.strokeWidth * scale));
  const shadowBlur = Math.round(preset.shadowBlur * scale);
  const shadowOffsetY = Math.round(preset.shadowOffsetY * scale);

  const isArabic = /[\u0600-\u06FF]/.test(activeSegment.text);
  const fontFamilies = isArabic
    ? 'Tajawal, Cairo, Arial, sans-serif'
    : (preset.fontFamily ? `${preset.fontFamily}, Tajawal, Cairo, Arial, sans-serif` : 'Montserrat, Tajawal, Cairo, sans-serif');
  ctx.font = `${preset.fontWeight} ${fontSize}px ${fontFamilies}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  const positionY = (canvasHeight * preset.positionY) / 100;
  const centerX = canvasWidth / 2;

  // Segment duration progress for subtle animations
  const segDuration = Math.max(0.1, activeSegment.end - activeSegment.start);
  const segProgress = Math.min(1, Math.max(0, (currentTime - activeSegment.start) / segDuration));

  // Build word objects with highlight info
  const keywordMap = new Map<string, string>();
  if (activeSegment.highlightKeywords) {
    for (const kw of activeSegment.highlightKeywords) {
      const cleanKw = kw.word.trim().replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '');
      const color = kw.color || CATEGORY_COLORS[kw.category] || preset.keywordColor;
      keywordMap.set(cleanKw.toLowerCase(), color);
    }
  }

  // Break words into clean, balanced lines (maximum 2 lines to avoid text piling)
  const lines: string[][] = [];
  if (rawWords.length <= 5) {
    // Single punchy line
    lines.push(rawWords);
  } else if (rawWords.length <= 10) {
    // Evenly split into 2 balanced lines
    const half = Math.ceil(rawWords.length / 2);
    lines.push(rawWords.slice(0, half));
    lines.push(rawWords.slice(half));
  } else {
    // If very long segment, cap to 2 lines of maxWordsPerLine or split
    const half = Math.ceil(rawWords.length / 2);
    lines.push(rawWords.slice(0, half));
    lines.push(rawWords.slice(half));
  }

  const lineHeight = fontSize * 1.35;
  const totalBlockHeight = lines.length * lineHeight;
  const startY = positionY - totalBlockHeight / 2 + lineHeight / 2;

  // Background box / pill if specified
  if (preset.backgroundColor && preset.backgroundColor !== 'transparent') {
    // Calculate max line width
    let maxLineWidth = 0;
    for (const line of lines) {
      const lineText = line.join(' ');
      const m = ctx.measureText(lineText);
      if (m.width > maxLineWidth) maxLineWidth = m.width;
    }

    const padX = preset.backgroundPadding * scale * 1.5;
    const padY = preset.backgroundPadding * scale;
    const boxX = centerX - maxLineWidth / 2 - padX;
    const boxY = positionY - totalBlockHeight / 2 - padY;
    const boxWidth = maxLineWidth + padX * 2;
    const boxHeight = totalBlockHeight + padY * 2;
    const radius = preset.backgroundRadius * scale;

    ctx.fillStyle = preset.backgroundColor;
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, radius);
    ctx.fill();
  }

  // Draw lines of words
  lines.forEach((lineWords, lineIndex) => {
    const y = startY + lineIndex * lineHeight;

    // Measure each word to position them correctly
    const spaceWidth = ctx.measureText(' ').width;
    const wordWidths = lineWords.map((word) => ctx.measureText(word).width);
    const totalLineWidth = wordWidths.reduce((a, b) => a + b, 0) + spaceWidth * (lineWords.length - 1);

    // Determine direction (RTL if contains Arabic characters)
    const isArabic = /[\u0600-\u06FF]/.test(activeSegment.text);
    let currentX = isArabic ? centerX + totalLineWidth / 2 : centerX - totalLineWidth / 2;
    const totalWords = rawWords.length;

    lineWords.forEach((word, wordIndex) => {
      const globalWordIdx = lines.slice(0, lineIndex).reduce((acc, l) => acc + l.length, 0) + wordIndex;
      const wordWidth = wordWidths[wordIndex];
      const cleanWord = word.replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '').toLowerCase();
      
      const isKeyword = keywordMap.has(cleanWord);
      const highlightColor = isKeyword ? keywordMap.get(cleanWord)! : preset.textColor;

      // Calculate exact speech onset for this word
      const wordStart = activeSegment.words?.[globalWordIdx]?.start ?? (activeSegment.start + (globalWordIdx / totalWords) * segDuration);
      const wordEnd = activeSegment.words?.[globalWordIdx]?.end ?? (wordStart + segDuration / totalWords);
      const hasBeenSpoken = currentTime >= (wordStart - 0.06);
      const isCurrentlySpoken = currentTime >= (wordStart - 0.06) && currentTime <= wordEnd;
      const timeSinceSpoken = currentTime - wordStart;
      const isSpeechBurst = hasBeenSpoken && timeSinceSpoken >= -0.06 && timeSinceSpoken < 0.38;

      // Word position
      const wordCenterX = isArabic ? currentX - wordWidth / 2 : currentX + wordWidth / 2;

      ctx.save();

      // Animations: Prominent keywords pop instantly the exact moment spoken!
      let wordScale = 1;
      if (isKeyword) {
        if (isSpeechBurst) {
          wordScale = 1.32 - (Math.max(0, timeSinceSpoken) / 0.38) * 0.16; // Snappy entrance pop!
        } else if (hasBeenSpoken) {
          wordScale = 1.08;
        } else {
          wordScale = 0.92;
        }
      } else if (isCurrentlySpoken && (preset.animation === 'pop' || preset.animation === 'karaoke')) {
        wordScale = 1.14;
      } else if (preset.animation === 'bounce') {
        const bounce = Math.sin(segProgress * Math.PI * 2) * 0.05;
        wordScale = 1 + (isKeyword ? 0.08 + bounce : bounce);
      }

      // Smooth speech synchronization opacity: unspoken words faint so prominent terms pop in immediately on speech!
      ctx.globalAlpha = hasBeenSpoken ? 1.0 : 0.15;

      ctx.translate(wordCenterX, y);
      if (wordScale !== 1) {
        ctx.scale(wordScale, wordScale);
      }

      // Keyword Pill Background badge if preset has keywordBgColor
      if (isKeyword && preset.keywordBgColor) {
        const pillPadX = 10 * scale;
        const pillPadY = 4 * scale;
        ctx.fillStyle = preset.keywordBgColor;
        ctx.beginPath();
        ctx.roundRect(
          -wordWidth / 2 - pillPadX,
          -fontSize / 2 - pillPadY,
          wordWidth + pillPadX * 2,
          fontSize + pillPadY * 2,
          12 * scale
        );
        ctx.fill();
      }

      // Clean, professional drop shadow with keyword radiance
      if (isKeyword) {
        ctx.shadowColor = `${highlightColor}90`;
        ctx.shadowBlur = Math.min(14, Math.max(6, shadowBlur * 0.9));
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = Math.max(2, shadowOffsetY);
      } else if (preset.animation === 'glow') {
        ctx.shadowColor = preset.shadowColor;
        ctx.shadowBlur = Math.min(10, shadowBlur * 0.6);
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = shadowOffsetY;
      } else {
        ctx.shadowColor = preset.shadowColor || 'rgba(0, 0, 0, 0.85)';
        ctx.shadowBlur = Math.min(8, shadowBlur);
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = Math.max(2, shadowOffsetY);
      }

      // Draw stroke first with the shadow
      if (preset.strokeWidth > 0) {
        ctx.strokeStyle = preset.strokeColor;
        ctx.lineWidth = isArabic ? Math.min(strokeWidth, Math.max(2, Math.round(fontSize * 0.08))) : strokeWidth;
        ctx.lineJoin = 'round';
        ctx.miterLimit = 2;
        ctx.strokeText(word, 0, 0);
      }

      // Clear shadow before drawing fill so the text letters are razor-sharp and crisp
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;

      // Draw text fill
      ctx.fillStyle = isKeyword ? highlightColor : preset.textColor;
      ctx.fillText(word, 0, 0);

      ctx.restore();

      // Advance X
      if (isArabic) {
        currentX -= wordWidth + spaceWidth;
      } else {
        currentX += wordWidth + spaceWidth;
      }
    });
  });

  ctx.restore();
}

import { Muxer, ArrayBufferTarget } from 'mp4-muxer';
import { formatTimeSRT } from './srt';

export type ExportQualityPreset = 'ultra' | 'high' | 'balanced' | 'compact';

export interface VideoMetadata {
  width: number;
  height: number;
  fps: number;
  duration: number;
  aspectRatio: number;
  videoCodec?: string;
  pixFmt?: string;
  bitrate?: number;
  audio?: {
    codec?: string;
    sampleRate?: number;
    channels?: number;
    bitrate?: number;
  } | null;
}

export interface ExportVideoOptions {
  videoElement: HTMLVideoElement;
  videoFile?: File | null;
  segments: SubtitleSegment[];
  preset: SubtitleStylePreset;
  onProgress: (
    progress: number,
    currentTime: number,
    duration: number,
    frameStats?: { currentFrame: number; totalFrames: number; fps: number }
  ) => void;
  signal?: AbortSignal;
  captionVisibilityRange?: {
    enabled: boolean;
    startTime: number;
    endTime: number;
  };
  renderRange?: {
    startTime: number;
    endTime: number;
  };
  backgroundMode?: 'auto' | 'video' | 'greenscreen' | 'black';
  aspectRatio?: 'auto' | '9:16' | '16:9';
  fps?: number;
  quality?: ExportQualityPreset;
}

// Calculate mathematically optimal bitrate based on resolution, framerate, and quality profile
export function calculateOptimalBitrate(
  width: number,
  height: number,
  fps: number = 30,
  quality: ExportQualityPreset = 'high'
): number {
  const pixelCount = width * height;

  // Bits-Per-Pixel (BPP) calibrated for H.264 High Profile:
  // ultra: broadcast master CRF 17-18
  // high: pristine quality / YouTube master CRF 20
  // balanced: web & mobile social CRF 23
  // compact: compressed CRF 26
  const bppMap: Record<ExportQualityPreset, number> = {
    ultra: 0.22,
    high: 0.16,
    balanced: 0.11,
    compact: 0.07,
  };

  const bpp = bppMap[quality] || 0.16;
  const fpsFactor = Math.pow(Math.max(15, fps) / 30, 0.75);
  let calculatedBps = Math.round(pixelCount * 30 * bpp * fpsFactor);

  if (pixelCount >= 3840 * 2160) {
    calculatedBps = Math.max(20_000_000, Math.min(50_000_000, calculatedBps));
  } else if (pixelCount >= 2560 * 1440) {
    calculatedBps = Math.max(14_000_000, Math.min(32_000_000, calculatedBps));
  } else if (pixelCount >= 1920 * 1080) {
    calculatedBps = Math.max(8_000_000, Math.min(22_000_000, calculatedBps));
  } else if (pixelCount >= 1280 * 720) {
    calculatedBps = Math.max(4_000_000, Math.min(10_000_000, calculatedBps));
  } else {
    calculatedBps = Math.max(1_500_000, Math.min(5_000_000, calculatedBps));
  }

  return calculatedBps;
}

// Video Metadata Prober: combines authoritative client video track inspection with server FFprobe
export async function probeVideoMetadata(
  videoElement: HTMLVideoElement,
  videoFile?: File | null
): Promise<VideoMetadata> {
  // Ensure metadata is loaded if element just mounted
  if (videoElement.readyState < 1 && (videoElement.src || videoElement.currentSrc)) {
    await new Promise<void>((r) => {
      const onMeta = () => {
        videoElement.removeEventListener('loadedmetadata', onMeta);
        r();
      };
      videoElement.addEventListener('loadedmetadata', onMeta, { once: true });
      setTimeout(r, 600);
    });
  }

  const elementWidth = videoElement.videoWidth || 0;
  const elementHeight = videoElement.videoHeight || 0;
  const elementDuration =
    isFinite(videoElement.duration) && videoElement.duration > 0 ? videoElement.duration : 0;

  // 1. Detect native container frame rate directly from browser MediaStreamTrack settings
  let detectedFps = 30;
  try {
    const stream = (videoElement as any).captureStream
      ? (videoElement as any).captureStream()
      : (videoElement as any).mozCaptureStream
      ? (videoElement as any).mozCaptureStream()
      : null;
    const track = stream?.getVideoTracks()?.[0];
    const settings = track?.getSettings ? track.getSettings() : null;
    if (settings && typeof settings.frameRate === 'number' && settings.frameRate > 0) {
      detectedFps = Math.round(settings.frameRate * 100) / 100;
    }
    track?.stop?.();
  } catch {
    // client detection fallback
  }

  // 2. Query FFprobe on server if available
  try {
    let probeUrl = '/api/video/probe';
    let options: RequestInit = { method: 'GET' };

    if (videoFile) {
      const sliceSize = Math.min(videoFile.size, 4 * 1024 * 1024);
      const slice = videoFile.slice(0, sliceSize);
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(slice);
      });

      probeUrl = '/api/video/probe';
      options = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoBase64: base64 }),
      };
    } else {
      const src = videoElement.src || videoElement.currentSrc;
      if (src && src.includes('sample.mp4')) {
        probeUrl = '/api/video/probe?path=public/sample.mp4';
      }
    }

    const res = await fetch(probeUrl, options);
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.width && data.height) {
        return {
          width: data.width,
          height: data.height,
          fps: data.fps || detectedFps || 30,
          duration: data.duration || elementDuration,
          aspectRatio: data.width / data.height,
          videoCodec: data.videoCodec,
          pixFmt: data.pixFmt,
          bitrate: data.bitrate,
          audio: data.audio,
        };
      }
    }
  } catch (err) {
    console.warn('[Probe] FFprobe fallback to client metadata:', err);
  }

  const w = elementWidth || 1080;
  const h = elementHeight || 1920;
  return {
    width: w,
    height: h,
    fps: detectedFps || 30,
    duration: elementDuration,
    aspectRatio: w / h,
  };
}

async function getAudioBufferForVideo(
  videoElement: HTMLVideoElement,
  videoFile?: File | null
): Promise<AudioBuffer | null> {
  try {
    let arrayBuffer: ArrayBuffer;
    if (videoFile) {
      arrayBuffer = await videoFile.arrayBuffer();
    } else {
      const src = videoElement.src || videoElement.currentSrc;
      if (!src) return null;
      const response = await fetch(src);
      arrayBuffer = await response.arrayBuffer();
    }
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const decoded = await audioContext.decodeAudioData(arrayBuffer);
    audioContext.close();
    return decoded;
  } catch (err) {
    console.warn('Audio decoding skipped/failed:', err);
    return null;
  }
}

// Rock-solid Frame-accurate Seek: Eliminates race conditions, duplicate frames, dropped frames, and VSync stalls!
export const seekToTime = (video: HTMLVideoElement, targetTime: number): Promise<void> => {
  return new Promise((resolve) => {
    // If already at target within sub-millisecond precision and data ready
    if (Math.abs(video.currentTime - targetTime) < 0.0005 && video.readyState >= 2) {
      resolve();
      return;
    }

    let isDone = false;
    let timer: any = null;

    const cleanup = () => {
      if (isDone) return;
      isDone = true;
      if (timer) clearTimeout(timer);
      video.removeEventListener('seeked', onSeeked);
      video.removeEventListener('error', onError);
      resolve();
    };

    const onSeeked = () => {
      // WHATWG HTML5 §4.8.12.9: On 'seeked', readyState >= HAVE_CURRENT_DATA,
      // and internal frame buffer at targetTime is ready for drawImage!
      cleanup();
    };

    const onError = () => {
      cleanup();
    };

    video.addEventListener('seeked', onSeeked, { once: true });
    video.addEventListener('error', onError, { once: true });

    try {
      video.currentTime = targetTime;
    } catch {
      cleanup();
      return;
    }

    // Safety timeout in case seek stalls or hits invalid timestamp
    timer = setTimeout(cleanup, 1200);
  });
};

// Calculate minimum required AVC level based on macroblock count and rate
function getMinimumAvcLevelHex(width: number, height: number, fps: number = 30): string {
  const mbWidth = Math.ceil(width / 16);
  const mbHeight = Math.ceil(height / 16);
  const totalMBs = mbWidth * mbHeight;
  const mbps = totalMBs * fps;

  // Level thresholds according to ITU-T H.264 specification:
  if (totalMBs > 22080 || mbps > 983040) return '34'; // Level 5.2 (4K 60fps)
  if (totalMBs > 8704 || mbps > 522240) return '33';  // Level 5.1 (4K 30fps)
  if (totalMBs > 8192 || mbps > 245760) return '2a';  // Level 4.2 (1080p 60fps)
  if (totalMBs > 3600 || mbps > 108000) return '29';  // Level 4.1 (1080p 30fps)
  return '1f'; // Level 3.1 (720p safe, NEVER Level 3.0 / 0x1E!)
}

// Select optimal AVC High Profile codec for maximum sharpness and compression efficiency
async function getBestAvcCodec(
  width: number,
  height: number,
  fps: number = 30,
  bitrate: number = 10_000_000
): Promise<string> {
  const minLevelHex = getMinimumAvcLevelHex(width, height, fps);
  const minLevelNum = parseInt(minLevelHex, 16);

  // Ordered candidate levels from highest down to minimum required level (NEVER below!)
  const candidateLevels = ['34', '33', '32', '2a', '29', '28', '20', '1f'].filter(
    (lvl) => parseInt(lvl, 16) >= minLevelNum
  );

  const candidateCodecs: string[] = [];

  // High Profile (6400) - Maximum Sharpness & Detail
  for (const lvl of candidateLevels) {
    candidateCodecs.push(`avc1.6400${lvl}`);
  }
  // Main Profile (4d40)
  for (const lvl of candidateLevels) {
    candidateCodecs.push(`avc1.4d40${lvl}`);
  }
  // Baseline Profile (42e0)
  for (const lvl of candidateLevels) {
    candidateCodecs.push(`avc1.42e0${lvl}`);
  }

  if (typeof VideoEncoder !== 'undefined' && typeof VideoEncoder.isConfigSupported === 'function') {
    for (const codec of candidateCodecs) {
      try {
        const support = await VideoEncoder.isConfigSupported({
          codec,
          width,
          height,
          bitrate,
          framerate: fps,
        });
        if (support.supported && support.config?.codec) {
          return support.config.codec;
        }
      } catch {
        // continue trying next codec candidate
      }
    }
  }

  // Safe fallback matching or exceeding required level
  return `avc1.6400${Math.max(minLevelNum, 0x29).toString(16)}`;
}

// Studio Master FFmpeg Export via server
export async function exportVideoWithFFmpegServer({
  videoElement,
  videoFile,
  segments,
  onProgress,
  signal,
  renderRange,
  backgroundMode = 'video',
  crf = 19,
}: {
  videoElement: HTMLVideoElement;
  videoFile?: File | null;
  segments: SubtitleSegment[];
  preset: SubtitleStylePreset;
  onProgress: (progress: number, currentTime: number, duration: number) => void;
  signal?: AbortSignal;
  renderRange?: { startTime: number; endTime: number };
  backgroundMode?: 'video' | 'greenscreen' | 'black';
  crf?: number;
}): Promise<string> {
  // Format segments into standard SRT content, shifted by render start time so subtitles sync with trimmed output
  const shiftTime = renderRange?.startTime || 0;
  const filteredSegments = segments.filter((seg) => {
    if (!renderRange) return true;
    return seg.end >= renderRange.startTime && seg.start <= (renderRange.endTime || Infinity);
  });

  const srtContent = filteredSegments
    .map((seg, idx) => {
      const s = formatTimeSRT(Math.max(0, seg.start - shiftTime));
      const e = formatTimeSRT(Math.max(0.1, seg.end - shiftTime));
      return `${idx + 1}\n${s} --> ${e}\n${seg.text}\n`;
    })
    .join('\n');

  let videoBase64: string | undefined;
  let videoPath: string | undefined;

  if (videoFile) {
    videoBase64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const res = reader.result as string;
        resolve(res.replace(/^data:[^;]+;base64,/, ''));
      };
      reader.onerror = reject;
      reader.readAsDataURL(videoFile);
    });
  } else {
    const src = videoElement.src || videoElement.currentSrc;
    if (src && src.includes('sample.mp4')) {
      videoPath = 'public/sample.mp4';
    }
  }

  onProgress(10, 0, renderRange?.endTime || 10);

  const res = await fetch('/api/video/render-ffmpeg', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      videoPath,
      videoBase64,
      srtContent,
      startTime: renderRange?.startTime || 0,
      endTime: renderRange?.endTime,
      crf,
      exportBackground: backgroundMode,
    }),
    signal,
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`FFmpeg server export failed: ${errText}`);
  }

  onProgress(90, renderRange?.endTime || 10, renderRange?.endTime || 10);
  const blob = await res.blob();
  onProgress(100, renderRange?.endTime || 10, renderRange?.endTime || 10);
  return URL.createObjectURL(blob);
}

export async function exportVideoWithBurnedSubtitles({
  videoElement,
  videoFile,
  segments,
  preset,
  onProgress,
  signal,
  captionVisibilityRange,
  renderRange,
  backgroundMode = 'auto',
  aspectRatio = 'auto',
  fps: requestedFps,
  quality = 'high',
}: ExportVideoOptions): Promise<string> {
  const origMutedState = videoElement.muted;
  videoElement.muted = true;
  videoElement.pause();

  // Detect true original metadata (width, height, fps, etc.)
  const metadata = await probeVideoMetadata(videoElement, videoFile);

  let videoWidth = metadata.width || videoElement.videoWidth || 0;
  let videoHeight = metadata.height || videoElement.videoHeight || 0;
  const fps = requestedFps || metadata.fps || 30;

  const isAudioOnly = !videoWidth || !videoHeight;
  const effectiveBgMode =
    backgroundMode === 'auto'
      ? isAudioOnly
        ? 'greenscreen'
        : 'video'
      : backgroundMode;

  let canvasWidth = videoWidth;
  let canvasHeight = videoHeight;

  if (isAudioOnly || canvasWidth === 0 || canvasHeight === 0) {
    if (aspectRatio === '16:9') {
      canvasWidth = 1920;
      canvasHeight = 1080;
    } else {
      // 9:16 standard for reels / shorts / tiktok
      canvasWidth = 1080;
      canvasHeight = 1920;
    }
  } else if (aspectRatio === '9:16' && canvasWidth > canvasHeight) {
    canvasWidth = 1080;
    canvasHeight = 1920;
  } else if (aspectRatio === '16:9' && canvasHeight > canvasWidth) {
    canvasWidth = 1920;
    canvasHeight = 1080;
  }

  // Ensure even dimensions required by H.264 video encoding standards
  if (canvasWidth % 2 !== 0) canvasWidth += 1;
  if (canvasHeight % 2 !== 0) canvasHeight += 1;

  const canvas = document.createElement('canvas');
  canvas.width = canvasWidth;
  canvas.height = canvasHeight;

  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) {
    videoElement.muted = origMutedState;
    throw new Error('Could not create canvas 2D rendering context');
  }

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // Calculate exact render range boundaries
  const totalVideoDuration =
    metadata.duration > 0
      ? metadata.duration
      : videoElement.duration && isFinite(videoElement.duration) && videoElement.duration > 0
      ? videoElement.duration
      : segments.length > 0
      ? Math.max(...segments.map((s) => s.end))
      : 10;

  const renderStart = Math.max(0, renderRange?.startTime ?? 0);
  const renderEnd = Math.min(totalVideoDuration, renderRange?.endTime ?? totalVideoDuration);
  const renderSpan = Math.max(0.1, renderEnd - renderStart);

  // Calculate dynamic bitrate based on resolution, fps, and quality tier
  const targetBitrate = calculateOptimalBitrate(canvasWidth, canvasHeight, fps, quality);

  // Check if WebCodecs VideoEncoder & mp4-muxer are supported for Fast Offline Render
  const supportsWebCodecs = typeof VideoEncoder !== 'undefined' && typeof VideoFrame !== 'undefined';

  if (supportsWebCodecs) {
    try {
      // Find optimal AVC High Profile codec matching resolution and target bitrate
      const selectedCodec = await getBestAvcCodec(canvasWidth, canvasHeight, fps, targetBitrate);

      // 1. Fetch and decode audio buffer for fast MP4 muxing
      const audioBuffer = await getAudioBufferForVideo(videoElement);

      // 2. Setup MP4 Muxer
      const muxer = new Muxer({
        target: new ArrayBufferTarget(),
        video: {
          codec: 'avc',
          width: canvasWidth,
          height: canvasHeight,
        },
        audio:
          audioBuffer && audioBuffer.numberOfChannels > 0
            ? {
                codec: 'aac',
                numberOfChannels: Math.min(2, audioBuffer.numberOfChannels),
                sampleRate: audioBuffer.sampleRate,
              }
            : undefined,
        fastStart: 'in-memory',
      });

      // 3. Configure VideoEncoder with High Profile & VBR (Variable Bitrate)
      let videoEncoderError: any = null;
      const videoEncoder = new VideoEncoder({
        output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
        error: (e) => {
          console.error('VideoEncoder error:', e);
          videoEncoderError = e;
        },
      });

      const encoderConfig: VideoEncoderConfig = {
        codec: selectedCodec,
        width: canvasWidth,
        height: canvasHeight,
        bitrate: targetBitrate,
        framerate: fps,
        bitrateMode: 'variable',
        latencyMode: 'quality',
      };

      try {
        const supportCheck = await VideoEncoder.isConfigSupported(encoderConfig);
        if (!supportCheck.supported) {
          delete encoderConfig.latencyMode;
          const retryCheck = await VideoEncoder.isConfigSupported(encoderConfig);
          if (!retryCheck.supported) {
            delete encoderConfig.bitrateMode;
          }
        }
      } catch {
        delete encoderConfig.latencyMode;
        delete encoderConfig.bitrateMode;
      }

      videoEncoder.configure(encoderConfig);

      // 4. Encode Audio Track with strict timestamp synchronization
      if (audioBuffer && audioBuffer.numberOfChannels > 0 && typeof AudioEncoder !== 'undefined') {
        try {
          const channels = Math.min(2, audioBuffer.numberOfChannels);
          const sampleRate = audioBuffer.sampleRate;
          const audioBitrate = channels === 1 ? 128_000 : 192_000;

          const audioEncoder = new AudioEncoder({
            output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
            error: (e) => console.error('AudioEncoder error:', e),
          });

          audioEncoder.configure({
            codec: 'mp4a.40.2',
            numberOfChannels: channels,
            sampleRate: sampleRate,
            bitrate: audioBitrate,
          });

          const startSample = Math.floor(renderStart * sampleRate);
          const endSample = Math.min(audioBuffer.length, Math.ceil(renderEnd * sampleRate));
          const totalRenderSamples = Math.max(0, endSample - startSample);

          // Standard 100ms chunks (smooth memory pacing)
          const chunkSize = Math.min(4096, Math.max(1024, Math.floor(sampleRate / 10)));
          for (let offset = 0; offset < totalRenderSamples; offset += chunkSize) {
            if (signal?.aborted) break;
            const frameCount = Math.min(chunkSize, totalRenderSamples - offset);
            const pcmData = new Float32Array(frameCount * channels);

            for (let channel = 0; channel < channels; channel++) {
              const channelData = audioBuffer.getChannelData(channel);
              const channelOffset = channel * frameCount;
              const sourceOffset = startSample + offset;
              for (let i = 0; i < frameCount; i++) {
                pcmData[channelOffset + i] = channelData[sourceOffset + i] || 0;
              }
            }

            const timestampUs = Math.round((offset / sampleRate) * 1_000_000);
            const audioData = new AudioData({
              format: 'f32-planar',
              sampleRate: sampleRate,
              numberOfChannels: channels,
              numberOfFrames: frameCount,
              timestamp: timestampUs,
              data: pcmData,
            });

            audioEncoder.encode(audioData);
            audioData.close();
          }

          await audioEncoder.flush();
        } catch (audioErr) {
          console.warn('AudioEncoder failed, proceeding with video-only track:', audioErr);
        }
      }

      // 5. High-Precision Frame-Stepping Loop (Frame-Accurate & Stutter-Free!)
      const totalFrames = Math.ceil(renderSpan * fps);
      const startTimeMs = performance.now();
      const keyframeInterval = Math.max(15, Math.round(fps * 2)); // 2-second GOP

      for (let frameIdx = 0; frameIdx < totalFrames; frameIdx++) {
        if (signal?.aborted) {
          videoElement.muted = origMutedState;
          throw new Error('Export cancelled by user');
        }
        if (videoEncoderError) {
          throw videoEncoderError;
        }

        const currentTime = renderStart + frameIdx / fps;

        // Step videoElement to precise frame time with presented-frame guarantee
        if (!isAudioOnly && effectiveBgMode === 'video') {
          await seekToTime(videoElement, currentTime);
        }

        // Draw canvas background or video frame
        if (effectiveBgMode === 'greenscreen') {
          ctx.fillStyle = '#00FF00';
          ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        } else if (effectiveBgMode === 'black' || isAudioOnly) {
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        } else {
          // 1:1 original mapping or aspect ratio fitting
          if (videoWidth === canvasWidth && videoHeight === canvasHeight) {
            ctx.drawImage(videoElement, 0, 0, canvasWidth, canvasHeight);
          } else {
            const scale = Math.min(canvasWidth / (videoWidth || 1080), canvasHeight / (videoHeight || 1920));
            const drawW = (videoWidth || 1080) * scale;
            const drawH = (videoHeight || 1920) * scale;
            const offsetX = (canvasWidth - drawW) / 2;
            const offsetY = (canvasHeight - drawH) / 2;
            ctx.fillStyle = '#000000';
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);
            ctx.drawImage(videoElement, offsetX, offsetY, drawW, drawH);
          }
        }

        // Find active segment
        const activeSegment =
          segments.find((seg) => currentTime >= seg.start && currentTime <= seg.end) || null;

        // Draw styled subtitles
        drawSubtitlesOnCanvas({
          ctx,
          canvasWidth,
          canvasHeight,
          activeSegment,
          preset,
          currentTime,
          captionVisibilityRange,
          autoHideSilence: true,
        });

        // Exact non-drifting microsecond timestamps
        const timestampUs = Math.round((frameIdx * 1_000_000) / fps);
        const durationUs = Math.round(1_000_000 / fps);
        const videoFrame = new VideoFrame(canvas, { 
          timestamp: timestampUs,
          duration: durationUs,
        });
        const keyFrame = frameIdx % keyframeInterval === 0;
        videoEncoder.encode(videoFrame, { keyFrame });
        videoFrame.close();

        // Calculate progress & FPS stats (throttled every 3 frames or final frame to maximize encode throughput)
        const shouldUpdateProgress = frameIdx % 3 === 0 || frameIdx === totalFrames - 1;
        if (shouldUpdateProgress) {
          const elapsedSec = (performance.now() - startTimeMs) / 1000;
          const currentFps = Math.max(1, Math.round((frameIdx + 1) / Math.max(0.01, elapsedSec)));
          const progressPercent = Math.min(100, Math.max(0, ((frameIdx + 1) / totalFrames) * 100));

          onProgress(progressPercent, currentTime - renderStart, renderSpan, {
            currentFrame: frameIdx + 1,
            totalFrames,
            fps: currentFps,
          });
          // Yield to browser event loop
          await new Promise((r) => setTimeout(r, 0));
        }

        // Bounded queue backpressure: throttle when encoder buffer grows
        if (videoEncoder.encodeQueueSize > 4) {
          await new Promise((r) => {
            const checkQueue = () => {
              if (videoEncoder.encodeQueueSize <= 1) {
                r(null);
              } else {
                setTimeout(checkQueue, 2);
              }
            };
            checkQueue();
          });
        }
      }

      await videoEncoder.flush();
      muxer.finalize();

      videoElement.muted = origMutedState;

      const mp4Buffer = muxer.target.buffer;
      const mp4Blob = new Blob([mp4Buffer], { type: 'video/mp4' });
      return URL.createObjectURL(mp4Blob);
    } catch (fastExportErr) {
      console.warn('Fast offline export error, attempting FFmpeg server render:', fastExportErr);
      try {
        return await exportVideoWithFFmpegServer({
          videoElement,
          videoFile,
          segments,
          preset,
          onProgress: (p, c, d) => onProgress(p, c, d),
          signal,
          renderRange,
          backgroundMode: effectiveBgMode === 'greenscreen' ? 'greenscreen' : effectiveBgMode === 'black' ? 'black' : 'video',
        });
      } catch (ffErr) {
        console.warn('FFmpeg server fallback also failed, falling back to stream recorder:', ffErr);
      }
    }
  }

  // --- Fallback Pipeline: MediaRecorder ---
  let audioContext: AudioContext | null = null;
  let audioDest: MediaStreamAudioDestinationNode | null = null;
  let sourceNode: MediaElementAudioSourceNode | null = null;

  try {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (!(videoElement as any).__audioSourceNode) {
      sourceNode = audioContext.createMediaElementSource(videoElement);
      (videoElement as any).__audioSourceNode = sourceNode;
    } else {
      sourceNode = (videoElement as any).__audioSourceNode;
    }

    audioDest = audioContext.createMediaStreamDestination();
    if (sourceNode && audioDest) {
      sourceNode.connect(audioDest);
    }
  } catch (err) {
    console.warn('Audio capture setup warning:', err);
  }

  // Canvas Stream with matching FPS
  const canvasStream = canvas.captureStream(fps);
  const outputTracks = [...canvasStream.getVideoTracks()];
  if (audioDest && audioDest.stream.getAudioTracks().length > 0) {
    outputTracks.push(...audioDest.stream.getAudioTracks());
  }

  const combinedStream = new MediaStream(outputTracks);

  let mimeType = 'video/mp4;codecs=avc1.64002a,mp4a.40.2';
  if (!MediaRecorder.isTypeSupported(mimeType)) {
    mimeType = 'video/mp4;codecs=avc1.42E02A,mp4a.40.2';
  }
  if (!MediaRecorder.isTypeSupported(mimeType)) {
    mimeType = 'video/mp4';
  }
  if (!MediaRecorder.isTypeSupported(mimeType)) {
    mimeType = 'video/webm;codecs=h264,opus';
  }
  if (!MediaRecorder.isTypeSupported(mimeType)) {
    mimeType = 'video/webm;codecs=vp9,opus';
  }
  if (!MediaRecorder.isTypeSupported(mimeType)) {
    mimeType = 'video/webm';
  }

  const recorder = new MediaRecorder(combinedStream, {
    mimeType: MediaRecorder.isTypeSupported(mimeType) ? mimeType : undefined,
    videoBitsPerSecond: targetBitrate,
  });

  const recordedChunks: Blob[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data && event.data.size > 0) {
      recordedChunks.push(event.data);
    }
  };

  return new Promise(async (resolve, reject) => {
    let animationFrameId: number;

    const cleanup = () => {
      cancelAnimationFrame(animationFrameId);
      videoElement.pause();
      videoElement.muted = origMutedState;
    };

    signal?.addEventListener('abort', () => {
      cleanup();
      if (recorder.state !== 'inactive') recorder.stop();
      reject(new Error('Export cancelled by user'));
    });

    recorder.onstop = () => {
      cleanup();
      const outputBlob = new Blob(recordedChunks, { type: mimeType });
      const videoUrl = URL.createObjectURL(outputBlob);
      resolve(videoUrl);
    };

    recorder.onerror = (e) => {
      cleanup();
      reject(e);
    };

    // Seek to custom start
    videoElement.currentTime = renderStart;
    await new Promise((r) => {
      const onSeeked = () => {
        videoElement.removeEventListener('seeked', onSeeked);
        r(null);
      };
      videoElement.addEventListener('seeked', onSeeked);
    });

    recorder.start(100);
    await videoElement.play();

    const renderLoop = () => {
      if (signal?.aborted) return;

      const currentTime = videoElement.currentTime;

      if (effectiveBgMode === 'greenscreen') {
        ctx.fillStyle = '#00FF00';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (effectiveBgMode === 'black' || isAudioOnly) {
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else {
        if (videoWidth === canvas.width && videoHeight === canvas.height) {
          ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
        } else {
          const scale = Math.min(canvas.width / (videoWidth || 1080), canvas.height / (videoHeight || 1920));
          const drawW = (videoWidth || 1080) * scale;
          const drawH = (videoHeight || 1920) * scale;
          const offsetX = (canvas.width - drawW) / 2;
          const offsetY = (canvas.height - drawH) / 2;
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(videoElement, offsetX, offsetY, drawW, drawH);
        }
      }

      const activeSegment =
        segments.find((seg) => currentTime >= seg.start && currentTime <= seg.end) || null;

      drawSubtitlesOnCanvas({
        ctx,
        canvasWidth: canvas.width,
        canvasHeight: canvas.height,
        activeSegment,
        preset,
        currentTime,
        captionVisibilityRange,
        autoHideSilence: true,
      });

      const progress = Math.min(100, Math.max(0, ((currentTime - renderStart) / renderSpan) * 100));
      onProgress(progress, currentTime - renderStart, renderSpan);

      if (videoElement.ended || currentTime >= renderEnd - 0.05) {
        recorder.stop();
      } else {
        animationFrameId = requestAnimationFrame(renderLoop);
      }
    };

    animationFrameId = requestAnimationFrame(renderLoop);
  });
}

