import { SubtitleSegment, KeywordHighlight } from '../types';

export function formatTimeSRT(totalSeconds: number): string {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const milliseconds = Math.floor((totalSeconds - Math.floor(totalSeconds)) * 1000);

  const pad = (n: number, z = 2) => String(n).padStart(z, '0');
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)},${pad(milliseconds, 3)}`;
}

export function formatTimeDisplay(totalSeconds: number): string {
  if (isNaN(totalSeconds) || totalSeconds < 0) totalSeconds = 0;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const ms = Math.floor((totalSeconds - Math.floor(totalSeconds)) * 10);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(minutes)}:${pad(seconds)}.${ms}`;
}

// Adobe Premiere Pro standard timecode format: 00:01:05:18 (Hours:Minutes:Seconds:Frames)
export function formatTimecodePremiere(totalSeconds: number, fps = 30): string {
  if (isNaN(totalSeconds) || totalSeconds < 0) totalSeconds = 0;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const frames = Math.floor((totalSeconds - Math.floor(totalSeconds)) * fps);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}:${pad(frames)}`;
}

// Split a subtitle segment at a specific timestamp (for shortcut 's' / razor tool)
export function splitSegmentAtTime(
  seg: SubtitleSegment,
  splitTime: number,
  nextId: number
): [SubtitleSegment, SubtitleSegment] | null {
  const duration = seg.end - seg.start;
  if (duration < 0.2) {
    return null; // Segment is too short to split further
  }

  // If splitTime is outside or too close to edge, split in the middle or clamp safely
  let cleanTime = Number(splitTime.toFixed(2));
  if (cleanTime <= seg.start + 0.05 || cleanTime >= seg.end - 0.05) {
    cleanTime = Number((seg.start + duration / 2).toFixed(2));
  }

  const words = seg.text.trim().split(/\s+/).filter(Boolean);

  if (words.length <= 1) {
    // Single word: duplicate with split timing
    return [
      {
        ...seg,
        end: cleanTime,
      },
      {
        ...seg,
        id: nextId,
        start: cleanTime,
      },
    ];
  }

  // Calculate ratio of time passed
  const ratio = Math.max(0.1, Math.min(0.9, (cleanTime - seg.start) / duration));
  const splitIndex = Math.max(1, Math.min(words.length - 1, Math.round(words.length * ratio)));

  const part1Words = words.slice(0, splitIndex);
  const part2Words = words.slice(splitIndex);

  const seg1: SubtitleSegment = {
    id: seg.id,
    start: seg.start,
    end: cleanTime,
    text: part1Words.join(' '),
    highlightKeywords: seg.highlightKeywords?.filter((kw) =>
      part1Words.some((w) => w.includes(kw.word) || kw.word.includes(w))
    ),
  };

  const seg2: SubtitleSegment = {
    id: nextId,
    start: cleanTime,
    end: seg.end,
    text: part2Words.join(' '),
    highlightKeywords: seg.highlightKeywords?.filter((kw) =>
      part2Words.some((w) => w.includes(kw.word) || kw.word.includes(w))
    ),
  };

  return [seg1, seg2];
}

export function parseSRTTime(timeString: string): number {
  const normalized = timeString.trim().replace(',', '.');
  const parts = normalized.split(':');
  if (parts.length === 3) {
    const hours = parseFloat(parts[0]);
    const minutes = parseFloat(parts[1]);
    const seconds = parseFloat(parts[2]);
    return hours * 3600 + minutes * 60 + seconds;
  } else if (parts.length === 2) {
    const minutes = parseFloat(parts[0]);
    const seconds = parseFloat(parts[1]);
    return minutes * 60 + seconds;
  }
  return parseFloat(normalized) || 0;
}

export function parseSRT(srtContent: string): SubtitleSegment[] {
  const normalized = srtContent.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const blocks = normalized.split(/\n\n+/);
  const segments: SubtitleSegment[] = [];

  for (let i = 0; i < blocks.length; i++) {
    const lines = blocks[i].split('\n').map((l) => l.trim()).filter(Boolean);
    if (lines.length < 2) continue;

    let timeLineIdx = 1;
    if (lines[0].includes('-->')) {
      timeLineIdx = 0;
    }

    const timeLine = lines[timeLineIdx];
    if (!timeLine || !timeLine.includes('-->')) continue;

    const [startStr, endStr] = timeLine.split('-->').map((s) => s.trim());
    const start = parseSRTTime(startStr);
    const end = parseSRTTime(endStr);
    const text = lines.slice(timeLineIdx + 1).join(' ').trim();

    if (!text) continue;

    segments.push({
      id: segments.length + 1,
      start,
      end,
      text,
      highlightKeywords: detectRuleBasedKeywords(text),
    });
  }

  return segments;
}

export function generateSRT(segments: SubtitleSegment[]): string {
  return segments
    .map((seg, idx) => {
      const startStr = formatTimeSRT(seg.start);
      const endStr = formatTimeSRT(seg.end);
      return `${idx + 1}\n${startStr} --> ${endStr}\n${seg.text}\n`;
    })
    .join('\n');
}

export function generateVTT(segments: SubtitleSegment[]): string {
  const body = segments
    .map((seg, idx) => {
      const startStr = formatTimeSRT(seg.start).replace(',', '.');
      const endStr = formatTimeSRT(seg.end).replace(',', '.');
      return `${idx + 1}\n${startStr} --> ${endStr}\n${seg.text}\n`;
    })
    .join('\n');
  return `WEBVTT\n\n${body}`;
}

export function downloadFile(content: string, filename: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Fast rule-based keyword detection for viral shorts & reels
export function detectRuleBasedKeywords(text: string): KeywordHighlight[] {
  const words = text.split(/\s+/);
  const highlights: KeywordHighlight[] = [];

  const yellowKeywords = new Set([
    'السر', 'سر', 'أسرار', 'النتيجة', 'نتائج', 'أهم', 'فرصة', 'الذهبية', 'أفضل',
    'secret', 'key', 'important', 'best', 'viral', 'money', 'results', 'golden',
    'قوة', 'الأول', 'أقوى', 'القمة', 'حقيقي', 'الحقيقي', 'مليون', 'مليار', 'أينشتاين', 'نيوتن', 'زويل'
  ]);

  const redKeywords = new Set([
    'خطأ', 'الخطأ', 'كارثة', 'قاتل', 'القاتل', 'خطر', 'الخطر', 'انتبه', 'احذر', 'مستحيل',
    'لا', 'أبدا', 'فشل', 'mistake', 'danger', 'deadly', 'wrong', 'fail', 'stop', 'warning', 'destroy',
    // Weapons & Military (أسلحة وعتاد)
    'كلاشينكوف', 'صاروخ', 'صواريخ', 'دبابة', 'دبابات', 'سلاح', 'أسلحة', 'نووي', 'قنبلة', 'مسيرة',
    'درون', 'كينجال', 'إسكندر', 'هيمارس', 'باتريوت', 'سوخوي', 'أبرامز', 'رادار', 'بارود', 'لغم', 'بندقية',
    // Diseases & Health (أمراض وفيروسات وأوبئة)
    'سرطان', 'السرطان', 'سكري', 'السكري', 'كورونا', 'كوفيد', 'فيروس', 'فيروسات', 'بكتيريا',
    'طاعون', 'كوليرا', 'ألزهايمر', 'جلطة', 'وباء', 'ورم', 'مرض'
  ]);

  const cyanKeywords = new Set([
    'ذكاء', 'الذكاء', 'اصطناعي', 'الاصطناعي', 'تقنية', 'جديد', 'مجان', 'مجانا',
    'ai', 'smart', 'new', 'free', 'tech', 'system', 'tool', 'future', 'مستقبل',
    'روبوت', 'تلسكوب', 'ناسا', 'فضاء', 'كوانتم', 'خوارزمية', 'لقاح', 'علاج', 'دواء'
  ]);

  const greenKeywords = new Set([
    'نجاح', 'للنجاح', 'ربح', 'أرباح', 'مضاعفة', 'ابدأ', 'فوز', 'سهل', 'بسهولة', 'تطور',
    'win', 'success', 'growth', 'start', 'profit', 'easy', 'gain', 'earn'
  ]);

  for (const rawWord of words) {
    const clean = rawWord.replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '');
    if (!clean) continue;

    // Check numbers, percentages, currency, multipliers (e.g. 10X, 100%, $500, 100k)
    if (/\d+[%$€£xXkKmM]?|\b\d+\b/.test(clean)) {
      highlights.push({ word: rawWord, category: 'yellow' });
      continue;
    }

    const lower = clean.toLowerCase();
    if (yellowKeywords.has(lower)) {
      highlights.push({ word: rawWord, category: 'yellow' });
    } else if (redKeywords.has(lower)) {
      highlights.push({ word: rawWord, category: 'red' });
    } else if (cyanKeywords.has(lower)) {
      highlights.push({ word: rawWord, category: 'cyan' });
    } else if (greenKeywords.has(lower)) {
      highlights.push({ word: rawWord, category: 'green' });
    }
  }

  // If no keywords matched, pick the longest word if short phrase
  if (highlights.length === 0 && words.length > 0 && words.length <= 5) {
    const longest = [...words].sort((a, b) => b.length - a.length)[0];
    if (longest && longest.length > 3) {
      highlights.push({ word: longest, category: 'yellow' });
    }
  }

  return highlights;
}

// 1. Strict Local Orthographic & Spelling Correction (STRICT NO-REPHRASE - لا يغير أي معنى أو كلمة أبداً)
// Only fixes typo letters (ة vs ه, Hamzat, punctuation attachment, Ya' vs Alif Maqsura)
export function fixLinguisticOrthographyLocal(segments: SubtitleSegment[]): {
  segments: SubtitleSegment[];
  corrections: Array<{ segmentId: number; original: string; corrected: string; reason: string }>;
} {
  const corrections: Array<{ segmentId: number; original: string; corrected: string; reason: string }> = [];

  const updatedSegments = segments.map((seg) => {
    let text = seg.text;
    const originalText = text;

    // A. Fix standalone prepositions and common phrases with missing hamza or alif maqsura
    // e.g., "ان شاء الله" -> "إن شاء الله"
    if (/(\bان\s+شاء\s+الله\b)/.test(text)) {
      text = text.replace(/\bان\s+شاء\s+الله\b/g, 'إن شاء الله');
      corrections.push({
        segmentId: seg.id,
        original: 'ان شاء الله',
        corrected: 'إن شاء الله',
        reason: 'تصحيح همزة القطع',
      });
    }

    // "الي" when followed by noun or standalone preposition -> "إلى"
    text = text.replace(/(^|\s)الي(\s|$)/g, '$1إلى$2');

    // "علي" when used as preposition e.g. "علي هذا", "علي كل" -> "على"
    text = text.replace(/(^|\s)علي(\s+(هذا|هذه|كل|أن|ما|الفيديو|القناة|اليوتيوب|الإنترنت))/g, '$1على$2');

    // "حتي" -> "حتى"
    text = text.replace(/(^|\s)حتي(\s|$)/g, '$1حتى$2');

    // "اذا" -> "إذا"
    text = text.replace(/(^|\s)اذا(\s|$)/g, '$1إذا$2');

    // B. Fix Ta' marbuta (ة vs ه) in well-known Islamic & Arabic words without touching slang
    const taMarbutaPairs: [RegExp, string, string][] = [
      [/\bورحمه\b/g, 'ورحمة', 'تصحيح تاء مربوطة في (ورحمة)'],
      [/\bمقدمه\b/g, 'مقدمة', 'تصحيح تاء مربوطة في (مقدمة)'],
      [/\bنهايه\b/g, 'نهاية', 'تصحيح تاء مربوطة في (نهاية)'],
      [/\bفكره\b/g, 'فكرة', 'تصحيح تاء مربوطة في (فكرة)'],
      [/\bقناه\b/g, 'قناة', 'تصحيح تاء مربوطة في (قناة)'],
      [/\bحياه\b/g, 'حياة', 'تصحيح تاء مربوطة في (حياة)'],
      [/\bطريقه\b/g, 'طريقة', 'تصحيح تاء مربوطة في (طريقة)'],
      [/\bخطوه\b/g, 'خطوة', 'تصحيح تاء مربوطة في (خطوة)'],
      [/\bنتيجه\b/g, 'نتيجة', 'تصحيح تاء مربوطة في (نتيجة)'],
      [/\bتجربه\b/g, 'تجربة', 'تصحيح تاء مربوطة في (تجربة)'],
    ];

    for (const [pattern, replacement, reason] of taMarbutaPairs) {
      if (pattern.test(text)) {
        text = text.replace(pattern, replacement);
        corrections.push({
          segmentId: seg.id,
          original: replacement.replace(/ة$/, 'ه'),
          corrected: replacement,
          reason,
        });
      }
    }

    // C. Punctuation spacing (remove space before commas, periods, question marks)
    text = text.replace(/\s+([،,؛;:!؟?.])/g, '$1');
    // Normalize English comma to Arabic comma in Arabic text
    if (/[\u0600-\u06FF]/.test(text)) {
      text = text.replace(/,/g, '،');
    }
    // Remove duplicate whitespace
    text = text.replace(/[ \t]+/g, ' ').trim();

    return {
      ...seg,
      text,
    };
  });

  return { segments: updatedSegments, corrections };
}

// 2. Smart Resegmenting & Cohesion (تجميع العبارات والتحيات المقطوعة ومنع تراكم الأسطر)
export function smartResegmentLocal(segments: SubtitleSegment[]): SubtitleSegment[] {
  if (segments.length <= 1) return segments;

  const result: SubtitleSegment[] = [];
  let i = 0;

  while (i < segments.length) {
    const cur = segments[i];
    const next = i + 1 < segments.length ? segments[i + 1] : null;

    // Check if greeting is broken: e.g. "السلام عليكم ورحمه" + "الله وبركاته"
    if (
      next &&
      /السلام\s+عليكم(\s+ورحم[ةه])?$/i.test(cur.text.trim()) &&
      /^(ورحم[ةه]\s+)?الله\s+وبركاته/i.test(next.text.trim())
    ) {
      const mergedText = 'السلام عليكم ورحمة الله وبركاته';
      result.push({
        id: result.length + 1,
        start: cur.start,
        end: next.end,
        text: mergedText,
        highlightKeywords: [
          { word: 'السلام', category: 'yellow' },
          { word: 'وبركاته', category: 'yellow' },
        ],
      });
      i += 2;
      continue;
    }

    // Check if greeting "السلام عليكم" is split from "ورحمة الله وبركاته"
    if (
      next &&
      /السلام\s+عليكم$/i.test(cur.text.trim()) &&
      /^(ورحم[ةه]\s+الله\s+وبركاته)/i.test(next.text.trim())
    ) {
      result.push({
        id: result.length + 1,
        start: cur.start,
        end: next.end,
        text: 'السلام عليكم ورحمة الله وبركاته',
        highlightKeywords: [
          { word: 'السلام', category: 'yellow' },
          { word: 'وبركاته', category: 'yellow' },
        ],
      });
      i += 2;
      continue;
    }

    // Check if segment is a tiny orphan word (< 2 words) with small time gap (< 0.9s)
    const curWords = cur.text.trim().split(/\s+/).filter(Boolean);
    if (curWords.length <= 2 && next && next.start - cur.end < 0.9) {
      const nextWords = next.text.trim().split(/\s+/).filter(Boolean);
      if (curWords.length + nextWords.length <= 7) {
        // Merge them cleanly
        result.push({
          id: result.length + 1,
          start: cur.start,
          end: next.end,
          text: `${cur.text.trim()} ${next.text.trim()}`,
          highlightKeywords: [
            ...(cur.highlightKeywords || []),
            ...(next.highlightKeywords || []),
          ].slice(0, 3),
        });
        i += 2;
        continue;
      }
    }

    // Normal segment
    result.push({
      ...cur,
      id: result.length + 1,
    });
    i++;
  }

  return splitLongSegments(result, 5);
}

// 2b. Auto-Split Long Segments into Short Punchy Segments (طلب المستخدم: الكلام كتير اوي خليه يقسم الكلام وميطلعش بره الفريم)
// Splits any segment exceeding maxWords (default 4-5 words) into short sequential segments with proportional timing
export function splitLongSegments(segments: SubtitleSegment[], maxWords = 5): SubtitleSegment[] {
  if (!segments || segments.length === 0) return [];

  const result: SubtitleSegment[] = [];

  for (const seg of segments) {
    const rawWords = seg.text.trim().split(/\s+/).filter(Boolean);
    if (rawWords.length <= maxWords) {
      result.push({
        ...seg,
        id: result.length + 1,
      });
      continue;
    }

    // Split words into chunks of maxWords
    const totalWords = rawWords.length;
    const chunkCount = Math.ceil(totalWords / maxWords);
    const duration = Math.max(0.6, seg.end - seg.start);
    const timePerWord = duration / totalWords;

    let wordOffset = 0;
    for (let c = 0; c < chunkCount; c++) {
      const chunkWordsCount = Math.min(maxWords, totalWords - wordOffset);
      const chunkWords = rawWords.slice(wordOffset, wordOffset + chunkWordsCount);
      const chunkText = chunkWords.join(' ');

      const chunkStart = Number((seg.start + wordOffset * timePerWord).toFixed(2));
      const chunkEnd = c === chunkCount - 1
        ? seg.end
        : Number((seg.start + (wordOffset + chunkWordsCount) * timePerWord).toFixed(2));

      // Filter matching keywords
      const chunkKeywords = seg.highlightKeywords?.filter((kw) =>
        chunkWords.some((w) => w.toLowerCase().includes(kw.word.toLowerCase()) || kw.word.toLowerCase().includes(w.toLowerCase()))
      ) || detectRuleBasedKeywords(chunkText);

      result.push({
        id: result.length + 1,
        start: chunkStart,
        end: Math.max(chunkStart + 0.4, chunkEnd),
        text: chunkText,
        highlightKeywords: chunkKeywords,
      });

      wordOffset += chunkWordsCount;
    }
  }

  return result;
}

// 3. Trim Silence Gaps (طلب المستخدم: إخفاء الكابشن عند الصمت وعدم بقاء آخر كلمة معلقة)
export function trimSilenceGaps(segments: SubtitleSegment[], lingerDelay = 0.35): SubtitleSegment[] {
  return segments.map((seg) => {
    // If word timestamps exist, speech ends at last word's end + lingerDelay
    if (seg.words && seg.words.length > 0) {
      const lastWord = seg.words[seg.words.length - 1];
      const speechEnd = Number((lastWord.end + lingerDelay).toFixed(2));
      return {
        ...seg,
        end: Math.min(seg.end, Math.max(seg.start + 0.6, speechEnd)),
      };
    }

    // Otherwise calculate natural duration based on Arabic/English words
    const words = seg.text.trim().split(/\s+/).filter(Boolean);
    // Average speech is ~2.8 words per second
    const estimatedSpokenDuration = Number((words.length * 0.38 + lingerDelay).toFixed(2));
    const cappedEnd = Number((seg.start + Math.max(1.0, estimatedSpokenDuration)).toFixed(2));

    return {
      ...seg,
      end: Math.min(seg.end, cappedEnd),
    };
  });
}

// Convert AudioBuffer into standard 16kHz mono WAV for high-accuracy Whisper / Gemini transcription
export function audioBufferToWav(buffer: AudioBuffer, targetSampleRate = 16000): Promise<Blob> {
  const numChannels = 1; // mono is ideal for speech transcription
  const offlineCtx = new OfflineAudioContext(numChannels, (buffer.duration * targetSampleRate) | 0, targetSampleRate);
  
  const source = offlineCtx.createBufferSource();
  source.buffer = buffer;
  source.connect(offlineCtx.destination);
  source.start(0);

  return new Promise((resolve) => {
    offlineCtx.startRendering().then((renderedBuffer) => {
      const channelData = renderedBuffer.getChannelData(0);
      const dataLength = channelData.length * 2;
      const wavBuffer = new ArrayBuffer(44 + dataLength);
      const view = new DataView(wavBuffer);

      // RIFF header
      writeString(view, 0, 'RIFF');
      view.setUint32(4, 36 + dataLength, true);
      writeString(view, 8, 'WAVE');
      writeString(view, 12, 'fmt ');
      view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
      view.setUint16(20, 1, true); // AudioFormat (1 for PCM)
      view.setUint16(22, numChannels, true); // NumChannels
      view.setUint32(24, targetSampleRate, true); // SampleRate
      view.setUint32(28, targetSampleRate * numChannels * 2, true); // ByteRate
      view.setUint16(32, numChannels * 2, true); // BlockAlign
      view.setUint16(34, 16, true); // BitsPerSample
      writeString(view, 36, 'data');
      view.setUint32(40, dataLength, true);

      // Write PCM samples
      let offset = 44;
      for (let i = 0; i < channelData.length; i++) {
        const s = Math.max(-1, Math.min(1, channelData[i]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
        offset += 2;
      }

      resolve(new Blob([wavBuffer], { type: 'audio/wav' }));
    });
  });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// Helper to convert Blob to Base64
export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Slices an AudioBuffer from startSec to endSec
export function sliceAudioBuffer(
  audioContext: BaseAudioContext,
  sourceBuffer: AudioBuffer,
  startSec: number,
  endSec: number
): AudioBuffer {
  const startOffset = Math.floor(startSec * sourceBuffer.sampleRate);
  const endOffset = Math.min(
    sourceBuffer.length,
    Math.floor(endSec * sourceBuffer.sampleRate)
  );
  const frameCount = Math.max(1, endOffset - startOffset);

  const sliced = audioContext.createBuffer(
    sourceBuffer.numberOfChannels,
    frameCount,
    sourceBuffer.sampleRate
  );

  for (let ch = 0; ch < sourceBuffer.numberOfChannels; ch++) {
    const channelData = sourceBuffer.getChannelData(ch);
    const subData = channelData.subarray(startOffset, endOffset);
    sliced.copyToChannel(subData, ch);
  }

  return sliced;
}

export interface AudioChunk {
  index: number;
  totalChunks: number;
  minuteNumber: number;
  formattedRange: string;
  startTime: number;
  endTime: number;
  audioBlob: Blob;
  audioBase64: string;
}

// Client-side chunked audio extraction (طلب المستخدم: يقسم الفويس ويعالجه دقيقة بدقيقة)
// Splits audio into 60-second (1 minute) pieces (~1.9MB WAV each), perfectly optimized for Groq & Gemini
export async function extractAudioChunksFromVideo(
  videoFile: File | Blob,
  chunkDurationSec = 60
): Promise<AudioChunk[]> {
  const arrayBuffer = await videoFile.arrayBuffer();
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();

  try {
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    const totalDuration = audioBuffer.duration;

    // If audio is under chunk limit, return a single chunk directly
    if (totalDuration <= chunkDurationSec) {
      const wavBlob = await audioBufferToWav(audioBuffer, 16000);
      const audioBase64 = await blobToBase64(wavBlob);
      return [
        {
          index: 0,
          totalChunks: 1,
          minuteNumber: 1,
          formattedRange: `${formatTimeDisplay(0)} - ${formatTimeDisplay(totalDuration)}`,
          startTime: 0,
          endTime: totalDuration,
          audioBlob: wavBlob,
          audioBase64,
        },
      ];
    }

    // Split into chunks of chunkDurationSec (default 60s / 1 min)
    const chunks: AudioChunk[] = [];
    const totalChunks = Math.ceil(totalDuration / chunkDurationSec);

    for (let i = 0; i < totalChunks; i++) {
      const start = i * chunkDurationSec;
      const end = Math.min(totalDuration, (i + 1) * chunkDurationSec);

      const slicedBuffer = sliceAudioBuffer(audioContext, audioBuffer, start, end);
      const wavBlob = await audioBufferToWav(slicedBuffer, 16000);
      const audioBase64 = await blobToBase64(wavBlob);

      chunks.push({
        index: i,
        totalChunks,
        minuteNumber: i + 1,
        formattedRange: `${formatTimeDisplay(start)} - ${formatTimeDisplay(end)}`,
        startTime: start,
        endTime: end,
        audioBlob: wavBlob,
        audioBase64,
      });
    }

    return chunks;
  } finally {
    audioContext.close();
  }
}

// Client-side audio extraction from video (backward compatible)
export async function extractAudioFromVideo(
  videoFile: File | Blob
): Promise<{ audioBlob: Blob; audioBase64: string }> {
  const chunks = await extractAudioChunksFromVideo(videoFile, 150);
  return {
    audioBlob: chunks[0].audioBlob,
    audioBase64: chunks[0].audioBase64,
  };
}

// Comprehensive smart entity & focal highlights extractor (Weapons, Diseases, Medical, People, Science, Tech, Places, Metrics, and Semantic Fallback)
// طلب المستخدم: "كتابات للاشياء المهمه بس: اسم سلاح، اسم مرض، اسماء اشخاص، دول، ارقام... متزدش عن 3 كلمات وتسيب 3 او 4 ثواني بعد ما يقول بس يظهر اول ما يقول الكلمه"
export function extractKeyHighlightsLocal(segments: SubtitleSegment[]): SubtitleSegment[] {
  if (!segments || segments.length === 0) return [];

  const highlights: SubtitleSegment[] = [];

  // 1. Weapons & Military Gear (أسلحة وعتاد عسكري وحربي)
  const weaponsPattern =
    /\b(كلاشينكوف|بندقية|مسدس|رشاش|آر\s*بي\s*جي|RPG|صاروخ|صواريخ|كينجال|إسكندر|هيمارس|HIMARS|باتريوت|مسيرة|مسيرات|درون|طائرة\s*(?:مسيرة|حربية|مقاتلة|شبحية)?|إف[- ]?16|F[- ]?16|إف[- ]?35|F[- ]?35|سوخوي|ميج|دبابة|دبابات|أبرامز|تي[- ]?90|بارود|نووي|سلاح\s*(?:نووي|كيميائي|بيولوجي|خفيف|ثقيل)?|قنبلة|قنابل|لغم|ألغام|مدفع|مدافع|راجمة|ذخيرة|فرقاطة|غواصة|طوربيد|كروز|باليستي|دفاع\s*جوي|رادار|كاتيوشا|قناصة|هاون|مدرعة|سلاح)\b/i;

  // 2. Diseases, Medical, Health, Viruses & Biology (أمراض، فيروسات، أوبئة، ومصطلحات طبية)
  const medicalPattern =
    /\b(سرطان|السرطان|سكري|السكري|مرض\s*السكري|كورونا|كوفيد(?:[- ]?19)?|إنفلونزا|كوليرا|طاعون|ألزهايمر|الزهايمر|جلطة|سكتة\s*قلبية|أزمة\s*قلبية|فيروس|فيروسات|بكتيريا|لقاح|لقاحات|علاج|دواء|أدوية|ضغط\s*الدم|عدوى|وباء|أوبئة|متلازمة|شلل|ورم|أورام|جراحة|استئصال|فشل\s*كلوي|كبد|رئة|جهاز\s*المناعة|مناعة|نزيف|كسور|أشعة|مضاد\s*حيوي|فيتامين|هرمون|جينات|DNA|كوليسترول|حساسية|التهاب|مرض)\b/i;

  // 3. Prominent People & Historical Figures (أعلام وشخصيات وقادة وتخصصات)
  const honorificPeoplePattern =
    /\b(?:الدكتور|البروفيسور|الرئيس|الملك|الشيخ|العالم|القائد|الجنرال|الباحث|المهندس|المخترع|الكاتب|الفيلسوف|الإمبراطور|الوزير|السفير|البطل|صاحب|مؤسس|مدرب|اللاعب)\s+[\u0621-\u064A\w]+(?:\s+[\u0621-\u064A\w]+)?\b/i;

  const famousPeoplePattern =
    /\b(أينشتاين|نيوتن|تسلا|نيكولا\s*تسلا|أديسون|جاليليو|ستيف\s*جوبز|إيلون\s*ماسك|بيل\s*جيتس|مارك\s*زوكربيرج|هتلر|نابليون|تشرشل|الإسكندر\s*الأكبر|صلاح\s*الدين|خالد\s*بن\s*الوليد|ابن\s*سينا|الخوارزمي|البيروني|أحمد\s*زويل|مجدي\s*يعقوب|فاروق\s*الباز|غاندي|مانديلا|محمد\s*صلاح|ميسي|رونالدو|مستر\s*بيست)\b/i;

  // 4. Inventions, Science, Tech & Space (تكنولوجيا، فضاء، اختراعات، مفاهيم علمية)
  const scienceTechPattern =
    /\b(ذكاء\s*اصطناعي|الذكاء\s*الاصطناعي|روبوت|روبوتات|تلسكوب|جيمس\s*ويب|هابل|قمر\s*صناعي|أقمار\s*صناعية|ناسا|NASA|فضاء|صاروخ\s*فضائي|كوانتم|فيزياء|ذرة|مفاعل\s*نووي|طاقة\s*شمسية|بطارية|ليزر|شريحة|معالج|إنترنت|خوارزمية|تطبيق|هاتف|آيفون|أندرويد|محرك|سيارة\s*كهربائية|أبل|مايكروسوفت|جوجل|شات\s*جي\s*بي\s*تي|ChatGPT)\b/i;

  // 5. Countries, Cities, Landmarks & Geography (دول، مدن، معالم ومضائق)
  const countryPlacesPattern =
    /\b(مصر|السعودية|المملكة\s*العربية\s*السعودية|الإمارات|دبي|أبوظبي|الرياض|القاهرة|قطر|الدوحة|الكويت|البحرين|عمان|مسقط|الأردن|عمان|فلسطين|القدس|غزة|لبنان|بيروت|سوريا|دمشق|العراق|بغداد|اليمن|صنعاء|المغرب|الرباط|الجزائر|تونس|ليبيا|طرابلس|السودان|الخرطوم|أمريكا|الولايات\s*المتحدة|واشنطن|نيويورك|بريطانيا|إنجلترا|لندن|فرنسا|باريس|ألمانيا|برلين|روسيا|موسكو|الصين|بكين|اليابان|طوكيو|تركيا|إسطنبول|كندا|أستراليا|إيطاليا|روما|إسبانيا|مدريد|إيران|طهران|مضيق\s*هرمز|باب\s*المندب|قناة\s*السويس)\b/i;

  // 6. Numbers, Metrics, Currency, Dimensions & Stats (أرقام ومقاسات وأسعار وأطوال وأوزان)
  const numberMetricPattern =
    /\b(\d+[\d,.]*\s*(?:%|٪|مليون|مليار|ترليون|ألف|دولار|جنيه|ريال|درهم|يورو|سم|متر|كم|كم\/س|طن|كجم|كيلو|سنة|سنوات|عام|أعوام|ساعة|ساعات|دقيقة|دقائق|ضعف|أضعاف|درجة|مئوية)?|\b\d+\b)\b/i;

  const writtenNumbers =
    /\b(واحد|اثنان|ثلاثة|أربعة|خمسة|ستة|سبعة|ثمانية|تسعة|عشرة|عشرين|ثلاثين|أربعين|خمسين|ستين|سبعين|ثمانين|تسعين|مائة|مئة|ألف|مليون|مليار)\s*(?:دولار|جنيه|ريال|متر|كيلو|سنة|ضعف)?\b/;

  // 7. Superlatives & Viral Hooks (أكبر، أسرع، أطول...)
  const superlativesPattern =
    /\b(الأسرع|الأكبر|الأطول|الأضخم|الأعلى|الأقوى|الأصغر|الأول|الرقم\s*القياسي|السر\s*الأكبر|أكبر\s*خطأ|الحل\s*السحري|الخدعة\s*الكبرى|الكارثة|النجاح\s*الخارق|الفرصة\s*الذهبية)\b/i;

  // Arabic Stopwords to filter out in the fallback heuristic
  const ARABIC_STOPWORDS = new Set([
    'في', 'من', 'إلى', 'على', 'عن', 'مع', 'هذا', 'هذه', 'هؤلاء', 'ذلك', 'تلك', 'الذي', 'التي',
    'الذين', 'اللواتي', 'كان', 'كانت', 'يكون', 'تكون', 'أن', 'إن', 'إنما', 'لكن', 'هل', 'لا',
    'ما', 'لم', 'لن', 'هو', 'هي', 'هم', 'هن', 'نحن', 'أنا', 'أنت', 'أنتم', 'قال', 'يقول',
    'تقول', 'جدا', 'أيضا', 'كل', 'بعض', 'بعد', 'قبل', 'عند', 'حيث', 'بين', 'خلال', 'نحو',
    'غير', 'سوى', 'فقط', 'ثم', 'أو', 'أم', 'حتى', 'إذا', 'لو', 'لولا', 'يا', 'أيها', 'قد',
    'لقد', 'تم', 'تمت', 'جعل', 'أصبح', 'صار', 'مثل', 'نفس', 'ذات', 'video', 'the', 'and', 'to', 'of', 'in'
  ]);

  for (const seg of segments) {
    const text = seg.text.trim();
    if (!text) continue;

    const words = text.split(/\s+/).filter(Boolean);
    if (words.length === 0) continue;

    let matchPhrase = '';
    let category: 'yellow' | 'red' | 'cyan' | 'green' = 'yellow';

    // Priority 1: Weapons
    const weaponMatch = text.match(weaponsPattern);
    if (weaponMatch) {
      matchPhrase = weaponMatch[0];
      category = 'red';
    }

    // Priority 2: Diseases / Medical
    if (!matchPhrase) {
      const medMatch = text.match(medicalPattern);
      if (medMatch) {
        matchPhrase = medMatch[0];
        category = 'red';
      }
    }

    // Priority 3: Science & Tech
    if (!matchPhrase) {
      const techMatch = text.match(scienceTechPattern);
      if (techMatch) {
        matchPhrase = techMatch[0];
        category = 'cyan';
      }
    }

    // Priority 4: Numbers, Statistics, Measurements
    if (!matchPhrase) {
      const numMatch = text.match(numberMetricPattern) || text.match(writtenNumbers);
      if (numMatch && numMatch[0].length > 1) {
        matchPhrase = numMatch[0];
        category = 'yellow';
      }
    }

    // Priority 5: People (Honorifics or Names)
    if (!matchPhrase) {
      const peopleMatch = text.match(honorificPeoplePattern) || text.match(famousPeoplePattern);
      if (peopleMatch) {
        matchPhrase = peopleMatch[0];
        category = 'yellow';
      }
    }

    // Priority 6: Countries & Places
    if (!matchPhrase) {
      const countryMatch = text.match(countryPlacesPattern);
      if (countryMatch) {
        matchPhrase = countryMatch[0];
        category = 'green';
      }
    }

    // Priority 7: Superlatives & Hooks
    if (!matchPhrase) {
      const superMatch = text.match(superlativesPattern);
      if (superMatch) {
        matchPhrase = superMatch[0];
        category = 'yellow';
      }
    }

    // Priority 8: Intelligent Semantic Heuristic Fallback (لأي جملة لا تطابق القوائم المباشرة)
    // يستخرج أهم مفهوم/اسم علم/كلمة معرفة بالـ أو مصطلح إنجليزي لضمان عدم خلو أي مقطع مفصلي من الكلمات المهمة
    if (!matchPhrase) {
      // Find candidate meaningful content words
      const candidates: { word: string; index: number; score: number }[] = [];
      words.forEach((w, idx) => {
        const clean = w.replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '');
        if (!clean || ARABIC_STOPWORDS.has(clean) || clean.length < 3) return;

        let score = clean.length;
        // Latin/English technical acronyms or model numbers get high priority
        if (/^[A-Za-z0-9_-]+$/.test(clean)) score += 10;
        // Arabic definite article 'الـ' with substantive noun
        if (clean.startsWith('ال') && clean.length >= 5) score += 6;
        candidates.push({ word: clean, index: idx, score });
      });

      if (candidates.length > 0) {
        candidates.sort((a, b) => b.score - a.score);
        const best = candidates[0];
        // If there's an adjacent word forming an Idafa or modifier, combine up to 2 words
        const nextWord = words[best.index + 1]?.replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '');
        if (nextWord && !ARABIC_STOPWORDS.has(nextWord) && nextWord.length >= 3) {
          matchPhrase = `${best.word} ${nextWord}`;
        } else {
          matchPhrase = best.word;
        }
        category = 'yellow';
      }
    }

    // If we have a match phrase, calculate exact timing and format concise 1-3 words
    if (matchPhrase) {
      // Trim to strictly 1 to 3 words
      const phraseWords = matchPhrase.trim().split(/\s+/).filter(Boolean).slice(0, 3);
      const cleanPhrase = phraseWords.join(' ');

      // Find match word index in segment
      let matchWordIndex = words.findIndex((w) =>
        w.toLowerCase().includes(phraseWords[0].toLowerCase())
      );
      if (matchWordIndex === -1) matchWordIndex = 0;

      // Calculate start time with proactive lead-in (طلب المستخدم: أول ما يقول الكلمة تظهر على طول ولا تتأخر أبداً)
      let highlightStart = seg.start;
      if (seg.words && seg.words.length > 0) {
        // Groq word-level timestamp exact match
        const matchedWordObj = seg.words.find(
          (w) =>
            w.word.toLowerCase().includes(phraseWords[0].toLowerCase()) ||
            phraseWords[0].toLowerCase().includes(w.word.toLowerCase())
        );
        if (matchedWordObj) {
          // Appear 0.22s before the word acoustic center so the viewer sees it the split-second it begins
          highlightStart = Math.max(seg.start, Number((matchedWordObj.start - 0.22).toFixed(2)));
        } else if (matchWordIndex < seg.words.length) {
          highlightStart = Math.max(seg.start, Number((seg.words[matchWordIndex].start - 0.22).toFixed(2)));
        }
      } else {
        // Without Groq (Gemini or manual SRT): proportional time estimation with 0.28s anticipation
        const wordRatio = words.length > 0 ? matchWordIndex / words.length : 0;
        const rawTime = seg.start + (seg.end - seg.start) * wordRatio - 0.28;
        highlightStart = Math.max(seg.start, Number(rawTime.toFixed(2)));
      }

      // Duration: 3.5 seconds (طلب المستخدم الصريح: تسيب 3 او 4 ثواني بعد ما يقول بس يظهر اول ما يقول الكلمه)
      const highlightEnd = Number((highlightStart + 3.5).toFixed(2));

      // Prevent awkward overlaps with previous highlight
      const prev = highlights[highlights.length - 1];
      if (prev && highlightStart < prev.end) {
        prev.end = Number(Math.max(prev.start + 1.2, highlightStart - 0.1).toFixed(2));
      }

      highlights.push({
        id: highlights.length + 1,
        start: highlightStart,
        end: highlightEnd,
        text: cleanPhrase,
        highlightKeywords: [
          {
            word: cleanPhrase,
            category,
          },
        ],
      });
    }
  }

  return highlights;
}
