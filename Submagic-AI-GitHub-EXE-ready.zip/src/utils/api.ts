/**
 * Safe API fetch helper that guarantees:
 * 1. NEVER crashes with: "Unexpected token '<', "<html><hea"... is not valid JSON"
 * 2. Safely detects HTML error responses (502, 504, 404, or reverse-proxy pages) and converts them into clean error messages
 * 3. Gracefully handles network failures
 */
export async function safeApiFetch<T = any>(
  url: string,
  options?: RequestInit
): Promise<{ ok: boolean; status: number; data?: T; error?: string }> {
  try {
    const customGeminiKey =
      typeof window !== 'undefined'
        ? localStorage.getItem('submagic_gemini_key') || ''
        : '';
    const customGroqKey =
      typeof window !== 'undefined'
        ? localStorage.getItem('submagic_groq_key') || ''
        : '';

    const customHeaders: Record<string, string> = {
      Accept: 'application/json',
    };
    if (customGeminiKey) {
      customHeaders['x-gemini-api-key'] = customGeminiKey;
    }
    if (customGroqKey) {
      customHeaders['x-groq-api-key'] = customGroqKey;
    }

    const res = await fetch(url, {
      ...options,
      headers: {
        ...customHeaders,
        ...(options?.headers || {}),
      },
    });

    const rawText = await res.text();

    // Check if the response is HTML rather than JSON
    const trimmed = rawText.trim();
    if (trimmed.startsWith('<') || trimmed.toLowerCase().includes('<html')) {
      const statusText =
        res.status === 413
          ? 'حجم المقطع الصوتي كبير جداً بالنسبة للخادم'
          : res.status === 502 || res.status === 503 || res.status === 504
          ? 'خادم المعالجة تحت ضغط مؤقت، يرجى المحاولة بعد قليل'
          : res.status === 404
          ? 'مسار الخدمة غير موجود بالخادم'
          : `الخادم أرجع استجابة غير متوقعة (رمز ${res.status})`;

      return {
        ok: false,
        status: res.status,
        error: statusText,
      };
    }

    // Try parsing as JSON
    let parsed: any;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      return {
        ok: false,
        status: res.status,
        error: rawText.slice(0, 120) || 'استجابة غير صالحة من الخادم',
      };
    }

    if (!res.ok) {
      return {
        ok: false,
        status: res.status,
        error: parsed?.error || parsed?.message || `فشل الطلب (${res.status})`,
      };
    }

    return {
      ok: true,
      status: res.status,
      data: parsed,
    };
  } catch (netErr: any) {
    return {
      ok: false,
      status: 0,
      error: netErr?.message || 'تعذر الاتصال بالخادم، تحقق من الاتصال بالإنترنت',
    };
  }
}
