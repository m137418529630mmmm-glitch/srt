export interface KeywordHighlight {
  word: string;
  category: 'yellow' | 'red' | 'cyan' | 'green' | 'purple' | 'orange' | 'custom';
  color?: string;
}

export interface SubtitleWord {
  word: string;
  start: number;
  end: number;
  isKeyword?: boolean;
  color?: string;
}

export interface SubtitleSegment {
  id: number;
  start: number; // in seconds
  end: number; // in seconds
  text: string;
  highlightKeywords?: KeywordHighlight[];
  words?: SubtitleWord[];
}

export type SubtitleAnimation = 'none' | 'pop' | 'bounce' | 'glow' | 'karaoke';

export type TimelineTool = 'select' | 'razor' | 'delete' | 'hand' | 'zoom';

export interface VideoCutSegment {
  id: string;
  start: number;
  end: number;
  label?: string;
  isDeleted?: boolean;
}

export interface SubtitleStylePreset {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  fontFamily: string;
  fontSize: number; // base font size in px (scaled with canvas/container)
  fontWeight: string;
  textColor: string;
  strokeColor: string;
  strokeWidth: number;
  shadowColor: string;
  shadowBlur: number;
  shadowOffsetY: number;
  backgroundColor: string; // e.g. 'transparent', '#000000a0'
  backgroundPadding: number;
  backgroundRadius: number;
  keywordColor: string;
  keywordSecondaryColor: string;
  keywordBgColor?: string;
  textTransform: 'uppercase' | 'none' | 'capitalize';
  positionY: number; // percentage from top (e.g. 78 for lower-third)
  animation: SubtitleAnimation;
  maxWordsPerLine: number;
  badgeStyle?: 'none' | 'pill' | 'box' | 'underline';
  previewBgGradient: string;
  category?: 'creators' | 'social' | 'arabic' | 'cinematic' | 'neon';
}

export interface CorrectionItem {
  segmentId: number;
  original: string;
  corrected: string;
  reason?: string;
}

export interface CaptionVisibilityRange {
  enabled: boolean;
  startTime: number;
  endTime: number;
}

export interface SilenceSettings {
  autoHide: boolean;
  lingerDelay: number; // seconds after speech ends before caption vanishes (default 0.35s)
}

export interface RenderProgress {
  status: 'idle' | 'rendering' | 'completed' | 'error';
  progress: number; // 0 to 100
  currentTime: number;
  duration: number;
  error?: string;
  videoUrl?: string;
}
