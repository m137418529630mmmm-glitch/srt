import React, { useState, useRef, useEffect, useCallback } from 'react';
import { PremiereHeader } from './components/PremiereHeader';
import { ProgramMonitor } from './components/ProgramMonitor';
import { ProjectInspector } from './components/ProjectInspector';
import { Timeline } from './components/Timeline';
import { ExportModal } from './components/ExportModal';
import { SettingsModal } from './components/SettingsModal';
import { Language, translations } from './utils/translations';
import {
  SubtitleSegment,
  SubtitleStylePreset,
  CaptionVisibilityRange,
  VideoCutSegment,
} from './types';
import { SUBTITLE_PRESETS } from './constants/presets';
import { SAMPLE_VIDEO_URL, SAMPLE_SEGMENTS_AR } from './constants/sampleData';
import {
  extractAudioFromVideo,
  extractAudioChunksFromVideo,
  detectRuleBasedKeywords,
  fixLinguisticOrthographyLocal,
  smartResegmentLocal,
  extractKeyHighlightsLocal,
  trimSilenceGaps,
  splitSegmentAtTime,
  splitLongSegments,
  formatTimeDisplay,
} from './utils/srt';
import { safeApiFetch } from './utils/api';
import { AlertCircle, CheckCircle2, Loader2, Sparkles, Scissors, Trash2, GripHorizontal, GripVertical, X } from 'lucide-react';

export default function App() {
  // User explicitly requested to remove the demo video: clean start with no sample video or sample segments
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const videoElementRef = useRef<HTMLVideoElement | null>(null);

  const [segments, setSegments] = useState<SubtitleSegment[]>([]);
  const [selectedSegmentIds, setSelectedSegmentIds] = useState<number[]>([]);
  const [activePreset, setActivePreset] = useState<SubtitleStylePreset>(SUBTITLE_PRESETS[0]);
  const [showCustomizer, setShowCustomizer] = useState(false);

  // Undo / Redo History Stacks
  const [history, setHistory] = useState<SubtitleSegment[][]>([]);
  const [redoStack, setRedoStack] = useState<SubtitleSegment[][]>([]);

  // Toggle option for linguistic error correction
  const [isGrammarEnabled, setIsGrammarEnabled] = useState(true);

  // Caption visibility range (طلب المستخدم: شيل مدة ظهور الكابشن 3 دقائق بس - تظهر طوال مدة الفيديو)
  const [captionVisibilityRange, setCaptionVisibilityRange] = useState<CaptionVisibilityRange>({
    enabled: false,
    startTime: 0,
    endTime: 999999, // Full duration by default
  });

  // Video editing state: Clips / Cuts (قص وتجميع الفيديو)
  const [videoCuts, setVideoCuts] = useState<VideoCutSegment[]>([]);
  const [selectedCutId, setSelectedCutId] = useState<string | null>(null);

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // API Config (Groq & Gemini)
  const [groqKey, setGroqKey] = useState<string>(() => {
    return localStorage.getItem('submagic_groq_key') || '';
  });
  const [geminiKey, setGeminiKey] = useState<string>(() => {
    return localStorage.getItem('submagic_gemini_key') || '';
  });
  const [geminiConnected, setGeminiConnected] = useState(true);
  // Mode: Full transcript vs Smart Keywords Only (Weapons, Diseases, People, Numbers, etc.)
  const [isKeywordsOnlyMode, setIsKeywordsOnlyMode] = useState<boolean>(false);
  const [fullTranscriptBackup, setFullTranscriptBackup] = useState<SubtitleSegment[] | null>(null);

  // Audio-Only & Green Screen Chroma Key rendering state (طلب المستخدم: لما اديك ملف صوت بس ارندر بجرين اسكرين)
  const [isAudioOnly, setIsAudioOnly] = useState<boolean>(false);
  const [backgroundMode, setBackgroundMode] = useState<'video' | 'greenscreen' | 'black'>('video');

  // Language state (Default to English LTR as requested: "وخلي الانجليزي هو الاساسي")
  const [lang, setLang] = useState<Language>(() => {
    return (localStorage.getItem('app_language') as Language) || 'en';
  });

  const handleToggleLanguage = () => {
    const nextLang: Language = lang === 'en' ? 'ar' : 'en';
    setLang(nextLang);
    localStorage.setItem('app_language', nextLang);
  };

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Resizable Layout Dimensions (User Request #1)
  const [topHeightPercent, setTopHeightPercent] = useState<number>(() => {
    const saved = localStorage.getItem('layout_top_height');
    return saved ? parseFloat(saved) : 55;
  });
  const [leftWidthPercent, setLeftWidthPercent] = useState<number>(() => {
    const saved = localStorage.getItem('layout_left_width');
    return saved ? parseFloat(saved) : 50;
  });
  const [layoutPreset, setLayoutPreset] = useState<'default' | 'monitor' | 'timeline'>('default');

  const handleSelectLayoutPreset = (preset: 'default' | 'monitor' | 'timeline') => {
    setLayoutPreset(preset);
    if (preset === 'default') {
      setTopHeightPercent(55);
      setLeftWidthPercent(50);
    } else if (preset === 'monitor') {
      setTopHeightPercent(65);
      setLeftWidthPercent(60);
    } else if (preset === 'timeline') {
      setTopHeightPercent(38);
      setLeftWidthPercent(50);
    }
  };

  // Draggable Splitter Handlers
  const mainContainerRef = useRef<HTMLDivElement | null>(null);
  const topWorkspaceRef = useRef<HTMLDivElement | null>(null);

  const handleVerticalResize = (e: React.MouseEvent) => {
    e.preventDefault();
    const container = mainContainerRef.current;
    if (!container) return;

    const onMouseMove = (moveEvent: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const relativeY = moveEvent.clientY - rect.top;
      const newPercent = Math.max(25, Math.min(80, (relativeY / rect.height) * 100));
      setTopHeightPercent(newPercent);
      localStorage.setItem('layout_top_height', newPercent.toString());
    };

    const onMouseUp = () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };

  const handleHorizontalResize = (e: React.MouseEvent) => {
    e.preventDefault();
    const workspace = topWorkspaceRef.current;
    if (!workspace) return;

    const onMouseMove = (moveEvent: MouseEvent) => {
      const rect = workspace.getBoundingClientRect();
      const relativeX = moveEvent.clientX - rect.left;
      const isRtl = lang === 'ar';
      const pct = (relativeX / rect.width) * 100;
      const newPercent = Math.max(20, Math.min(80, isRtl ? 100 - pct : pct));
      setLeftWidthPercent(newPercent);
      localStorage.setItem('layout_left_width', newPercent.toString());
    };

    const onMouseUp = () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };

  // AI Progress Indicator state & Loading states (User Request #3)
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isProcessingAI, setIsProcessingAI] = useState(false);
  const [statusNotification, setStatusNotification] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
  } | null>(null);
  const [aiProgress, setAiProgress] = useState<number>(0);
  const [aiStep, setAiStep] = useState<string | null>(null);

  // Check server API status on mount safely
  useEffect(() => {
    safeApiFetch('/api/status').then((res) => {
      if (res.ok && res.data && res.data.geminiConfigured !== undefined) {
        setGeminiConnected(res.data.geminiConfigured);
      }
    });
  }, []);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setStatusNotification({ message, type });
    setTimeout(() => {
      setStatusNotification(null);
    }, 4000);
  };

  // State update wrapper with History Recording
  const updateSegmentsWithHistory = useCallback(
    (newSegments: SubtitleSegment[], recordHistory = true) => {
      if (recordHistory) {
        setHistory((prev) => [...prev.slice(-30), segments]);
        setRedoStack([]);
      }
      setSegments(newSegments);
    },
    [segments]
  );

  // UNDO (Ctrl+Z)
  const handleUndo = useCallback(() => {
    if (history.length === 0) {
      showToast('لا توجد عمليات سابقة للتراجع عنها', 'info');
      return;
    }
    const previousState = history[history.length - 1];
    setHistory((h) => h.slice(0, h.length - 1));
    setRedoStack((r) => [...r, segments]);
    setSegments(previousState);
    showToast('تراجع (Ctrl+Z) ↩️', 'info');
  }, [history, segments]);

  // REDO (Ctrl+Y / Ctrl+Shift+Z)
  const handleRedo = useCallback(() => {
    if (redoStack.length === 0) {
      showToast('لا توجد عمليات للإعادة', 'info');
      return;
    }
    const nextState = redoStack[redoStack.length - 1];
    setRedoStack((r) => r.slice(0, r.length - 1));
    setHistory((h) => [...h, segments]);
    setSegments(nextState);
    showToast('إعادة (Ctrl+Y) ↪️', 'info');
  }, [redoStack, segments]);

  const handleSaveGroqKey = (key: string) => {
    setGroqKey(key);
    localStorage.setItem('submagic_groq_key', key);
    showToast('تم حفظ مفتاح Groq بنجاح!', 'success');
  };

  const handleSaveGeminiKey = (key: string) => {
    setGeminiKey(key);
    localStorage.setItem('submagic_gemini_key', key);
    showToast(key ? 'تم حفظ مفتاح Google Gemini بنجاح!' : 'تم مسح مفتاح Gemini واستعادة الوضع الافتراضي', 'success');
  };

  // Media File Upload (Video or Audio: MP4, WebM, MP3, WAV, M4A, etc.)
  const handleFileUpload = (file: File) => {
    setVideoFile(file);
    const objectUrl = URL.createObjectURL(file);
    setVideoSrc(objectUrl);
    updateSegmentsWithHistory([], true);
    setFullTranscriptBackup(null);
    setIsKeywordsOnlyMode(false);
    setSelectedSegmentIds([]);
    setCurrentTime(0);

    const isAudio =
      file.type.startsWith('audio/') ||
      /\.(mp3|wav|m4a|aac|ogg|flac|wma)$/i.test(file.name);
    setIsAudioOnly(isAudio);

    if (isAudio) {
      setBackgroundMode('greenscreen');
      showToast(`تم تحميل ملف الصوت: ${file.name}. تم تفعيل الشاشة الخضراء (Green Screen) تلقائياً 🟢`, 'success');
    } else {
      setBackgroundMode('video');
      showToast(`تم تحميل الفيديو: ${file.name}.`, 'info');
    }
  };

  // Load Sample Demo Video
  const handleLoadSample = () => {
    setVideoSrc(SAMPLE_VIDEO_URL);
    setVideoFile(null);
    setIsAudioOnly(false);
    setBackgroundMode('video');
    updateSegmentsWithHistory(SAMPLE_SEGMENTS_AR, true);
    setFullTranscriptBackup(SAMPLE_SEGMENTS_AR);
    setIsKeywordsOnlyMode(false);
    setSelectedSegmentIds([1]);
    setCurrentTime(0);
    if (videoElementRef.current) {
      videoElementRef.current.currentTime = 0;
    }
    showToast('تم تحميل الفيديو العينة ومسارات الكابشن والصوت في التايم لاين!', 'success');
  };

  const handleToggleGreenScreen = () => {
    setBackgroundMode((prev) =>
      prev === 'greenscreen' ? (isAudioOnly ? 'black' : 'video') : 'greenscreen'
    );
    showToast(
      backgroundMode === 'greenscreen'
        ? 'تم إيقاف الشاشة الخضراء'
        : 'تم تفعيل الشاشة الخضراء (Green Screen Chroma Key #00FF00) 🟢',
      'info'
    );
  };

  // Play / Pause toggle
  const handlePlayPause = useCallback(() => {
    const video = videoElementRef.current;
    if (!video) return;
    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      video.play().then(() => setIsPlaying(true)).catch(console.error);
    }
  }, [isPlaying]);

  // Seek
  const handleSeek = useCallback((time: number) => {
    setCurrentTime(time);
    if (videoElementRef.current) {
      videoElementRef.current.currentTime = time;
    }
  }, []);

  // 1. SHORTCUT 'S': Split / Cut segment at playhead (أو س)
  const handleSplitAtPlayhead = useCallback(() => {
    let targetSeg = segments.find((s) => currentTime >= s.start && currentTime <= s.end);
    if (!targetSeg && selectedSegmentIds.length > 0) {
      targetSeg = segments.find((s) => s.id === selectedSegmentIds[0]);
    }
    if (!targetSeg && segments.length > 0) {
      targetSeg = [...segments].sort(
        (a, b) => Math.abs(a.start - currentTime) - Math.abs(b.start - currentTime)
      )[0];
    }

    if (!targetSeg) {
      showToast('يرجى تحريك المؤشر فوق سطر كابشن لقطعه', 'info');
      return;
    }

    let splitTime = currentTime;
    if (splitTime <= targetSeg.start + 0.05 || splitTime >= targetSeg.end - 0.05) {
      splitTime = targetSeg.start + (targetSeg.end - targetSeg.start) / 2;
    }

    const splitRes = splitSegmentAtTime(targetSeg, splitTime, segments.length + 1);
    if (!splitRes) {
      showToast('المقطع قصير جداً ولا يمكن تقسيمه أكثر', 'info');
      return;
    }

    const [seg1, seg2] = splitRes;
    const idx = segments.findIndex((s) => s.id === targetSeg.id);
    const updated = [
      ...segments.slice(0, idx),
      seg1,
      seg2,
      ...segments.slice(idx + 1),
    ].map((s, i) => ({ ...s, id: i + 1 }));

    updateSegmentsWithHistory(updated, true);
    setSelectedSegmentIds([seg2.id]);
    showToast(`تم قص الكابشن عند ${splitTime.toFixed(2)}s (اختصار S) ✂️`, 'success');
  }, [currentTime, selectedSegmentIds, segments, updateSegmentsWithHistory]);

  // 2. SHORTCUT 'A': Delete all selected segments or segment under playhead (أو ش)
  const handleDeleteSelected = useCallback(() => {
    let idsToDelete = selectedSegmentIds;
    if (idsToDelete.length === 0) {
      const underPlayhead = segments.find((s) => currentTime >= s.start && currentTime <= s.end);
      if (underPlayhead) {
        idsToDelete = [underPlayhead.id];
      }
    }

    if (idsToDelete.length === 0) {
      showToast('لا يوجد كابشن محدد للمسح (حدد مقطعاً أو اسحب بالماوس للتحديد واضغط A)', 'info');
      return;
    }

    const updated = segments
      .filter((s) => !idsToDelete.includes(s.id))
      .map((s, idx) => ({ ...s, id: idx + 1 }));

    updateSegmentsWithHistory(updated, true);
    setSelectedSegmentIds([]);
    showToast(`تم مسح ${idsToDelete.length} كابشن بنجاح (اختصار A) 🗑️`, 'info');
  }, [selectedSegmentIds, currentTime, segments, updateSegmentsWithHistory]);

  // Add new caption segment at playhead
  const handleAddSegmentAtPlayhead = useCallback(() => {
    const start = Number(currentTime.toFixed(2));
    const end = Number(Math.min(duration || start + 3, start + 2.5).toFixed(2));
    const newSeg: SubtitleSegment = {
      id: segments.length + 1,
      start,
      end,
      text: 'نص كابشن جديد',
      highlightKeywords: [{ word: 'جديد', category: 'yellow' }],
    };
    const updated = [...segments, newSeg].sort((a, b) => a.start - b.start).map((s, idx) => ({ ...s, id: idx + 1 }));
    updateSegmentsWithHistory(updated, true);
    setSelectedSegmentIds([newSeg.id]);
    showToast('تمت إضافة سطر كابشن جديد عند موضع المؤشر!', 'success');
  }, [currentTime, duration, segments, updateSegmentsWithHistory]);

  // Synchronize initial video cut when video duration is detected
  useEffect(() => {
    if (duration > 0 && videoCuts.length === 0) {
      setVideoCuts([{ id: 'cut-1', start: 0, end: Number(duration.toFixed(2)), label: 'مقطع فيديو 1' }]);
    }
  }, [duration, videoCuts.length]);

  // Video Editing: Split Video Cut at Playhead (قص وتقسيم الفيديو عند المؤشر)
  const handleSplitVideo = useCallback(() => {
    if (duration <= 0) {
      showToast('يرجى تحميل ملف فيديو أو صوت لتعديل وقص المقاطع', 'info');
      return;
    }

    const currentCuts =
      videoCuts.length > 0
        ? videoCuts
        : [{ id: 'cut-1', start: 0, end: Number(duration.toFixed(2)), label: 'مقطع فيديو 1' }];

    const targetIdx = currentCuts.findIndex(
      (c) => currentTime >= c.start && currentTime <= c.end
    );
    if (targetIdx === -1) {
      showToast('المؤشر ليس داخل مقطع فيديو صالح للقص', 'info');
      return;
    }

    const cut = currentCuts[targetIdx];
    if (currentTime - cut.start < 0.2 || cut.end - currentTime < 0.2) {
      showToast('الموضع قريب جداً من بداية أو نهاية المقطع (الحد الأدنى 0.2 ثانية)', 'info');
      return;
    }

    const splitTime = Number(currentTime.toFixed(2));
    const cutA: VideoCutSegment = {
      ...cut,
      id: `cut-${Date.now()}-1`,
      end: splitTime,
      label: `مقطع ${targetIdx + 1}`,
    };
    const cutB: VideoCutSegment = {
      id: `cut-${Date.now()}-2`,
      start: splitTime,
      end: cut.end,
      label: `مقطع ${targetIdx + 2}`,
    };

    const updated = [
      ...currentCuts.slice(0, targetIdx),
      cutA,
      cutB,
      ...currentCuts.slice(targetIdx + 1),
    ];
    setVideoCuts(updated);
    setSelectedCutId(cutB.id);
    showToast(`تم قص وتقسيم الفيديو عند ${formatTimeDisplay(currentTime)} بنجاح! ✂️`, 'success');
  }, [currentTime, duration, videoCuts]);

  // Video Editing: Delete Video Cut (حذف مقطع مقصوص)
  const handleDeleteVideoCut = useCallback(
    (cutId: string) => {
      if (videoCuts.length <= 1) {
        showToast('لا يمكن حذف مقطع الفيديو الوحيد', 'info');
        return;
      }
      const updated = videoCuts.filter((c) => c.id !== cutId);
      setVideoCuts(updated);
      setSelectedCutId(null);
      showToast('تم حذف مقطع الفيديو المحدد 🗑️', 'info');
    },
    [videoCuts]
  );

  // Video Editing: Merge Video Cuts (تجميع ودمج المقاطع)
  const handleMergeVideoCuts = useCallback(() => {
    if (videoCuts.length <= 1) {
      showToast('لا توجد مقاطع متعددة لدمجها حالياً', 'info');
      return;
    }

    const sorted = [...videoCuts].sort((a, b) => a.start - b.start);
    const merged: VideoCutSegment[] = [];
    let current = { ...sorted[0] };

    for (let i = 1; i < sorted.length; i++) {
      const next = sorted[i];
      if (Math.abs(current.end - next.start) <= 0.2) {
        current.end = Math.max(current.end, next.end);
      } else {
        merged.push(current);
        current = { ...next };
      }
    }
    merged.push(current);

    setVideoCuts(merged.map((m, idx) => ({ ...m, label: `مقطع مجمع ${idx + 1}` })));
    setSelectedCutId(merged[0]?.id || null);
    showToast(`تم تجميع ودمج مقاطع الفيديو في ${merged.length} مقطع بنجاح! 🔗`, 'success');
  }, [videoCuts]);

  // Keyboard Shortcuts Listener (Ctrl+Z, Ctrl+Y, Ctrl+A, S, C, M, A, Space, Arrows)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable ||
        target.closest('input') ||
        target.closest('textarea')
      ) {
        return;
      }

      // 1. Ctrl+Z / Cmd+Z -> Undo
      if ((e.ctrlKey || e.metaKey) && (e.code === 'KeyZ' || e.key === 'z' || e.key === 'Z' || e.key === 'ئ')) {
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
        return;
      }

      // 2. Ctrl+Y / Cmd+Y -> Redo
      if ((e.ctrlKey || e.metaKey) && (e.code === 'KeyY' || e.key === 'y' || e.key === 'Y' || e.key === 'غ')) {
        e.preventDefault();
        handleRedo();
        return;
      }

      // 3. Ctrl+A -> Select All clips
      if ((e.ctrlKey || e.metaKey) && (e.code === 'KeyA' || e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        setSelectedSegmentIds(segments.map((s) => s.id));
        showToast(`تم تحديد جميع المقاطع (${segments.length}) 🎯`, 'info');
        return;
      }

      // 4. S / س -> Split Caption at playhead
      if (e.code === 'KeyS' || e.key === 's' || e.key === 'S' || e.key === 'س') {
        e.preventDefault();
        handleSplitAtPlayhead();
        return;
      }

      // 4b. C / ؤ -> Split Video Cut at playhead (قص وتقسيم الفيديو)
      if (e.code === 'KeyC' || e.key === 'c' || e.key === 'C' || e.key === 'ؤ') {
        e.preventDefault();
        handleSplitVideo();
        return;
      }

      // 4c. M / ة -> Merge Video Cuts (تجميع المقاطع)
      if (e.code === 'KeyM' || e.key === 'm' || e.key === 'M' || e.key === 'ة') {
        e.preventDefault();
        handleMergeVideoCuts();
        return;
      }

      // 5. A / ش / Delete / Backspace -> Delete selected
      if (
        e.code === 'KeyA' ||
        e.key === 'a' ||
        e.key === 'A' ||
        e.key === 'ش' ||
        e.code === 'Delete' ||
        e.code === 'Backspace'
      ) {
        e.preventDefault();
        if (selectedCutId) {
          handleDeleteVideoCut(selectedCutId);
        } else {
          handleDeleteSelected();
        }
        return;
      }

      // 6. Space -> Play / Pause
      if (e.code === 'Space') {
        e.preventDefault();
        handlePlayPause();
        return;
      }

      // 7. Left Arrow -> Frame back (0.1s)
      if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handleSeek(Math.max(0, currentTime - 0.1));
        return;
      }

      // 8. Right Arrow -> Frame forward (0.1s)
      if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleSeek(Math.min(duration, currentTime + 0.1));
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    handleUndo,
    handleRedo,
    handleSplitAtPlayhead,
    handleSplitVideo,
    handleMergeVideoCuts,
    handleDeleteSelected,
    handleDeleteVideoCut,
    selectedCutId,
    handlePlayPause,
    handleSeek,
    currentTime,
    duration,
    segments,
    selectedSegmentIds,
  ]);

  // 1. Transcribe with Groq Whisper API (دقيقة بدقيقة - 60 ثانية لكل جزء)
  const handleGenerateGroq = async () => {
    if (!groqKey) {
      setIsSettingsOpen(true);
      showToast('يرجى إدخال مفتاح Groq API لتفعيل نموذج Whisper فائق السرعة', 'error');
      return;
    }

    if (!videoSrc) {
      showToast('يرجى اختيار ملف فيديو أو صوت أولاً', 'error');
      return;
    }

    setIsTranscribing(true);
    showToast('جاري استخراج الصوت وتجهيز الكابشن عبر Groq Whisper (دقيقة بدقيقة)...', 'info');

    try {
      let mediaBlob: Blob;
      if (videoFile) {
        mediaBlob = videoFile;
      } else {
        const res = await fetch(videoSrc);
        mediaBlob = await res.blob();
      }

      // Automatically chunk audio into 60s (1 minute) pieces (طلب المستخدم: يقسم الفويس ويعالجه دقيقة بدقيقة)
      const chunks = await extractAudioChunksFromVideo(mediaBlob, 60);
      const allSegments: SubtitleSegment[] = [];

      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        if (chunks.length > 1) {
          showToast(`جاري استخراج الكابشن: الدقيقة ${i + 1} من ${chunks.length} (${chunk.formattedRange})...`, 'info');
        }

        const res = await safeApiFetch('/api/groq/transcribe', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-groq-api-key': groqKey,
          },
          body: JSON.stringify({
            audioBase64: chunk.audioBase64,
            mimeType: 'audio/wav',
            model: 'whisper-large-v3-turbo',
          }),
        });

        if (!res.ok) {
          throw new Error(res.error || `فشل في استخراج الكابشن من الدقيقة ${i + 1}`);
        }

        const data = res.data;
        if (data?.segments && data.segments.length > 0) {
          const chunkSegments = data.segments.map((seg: any) => ({
            ...seg,
            start: Number((seg.start + chunk.startTime).toFixed(2)),
            end: Number((seg.end + chunk.startTime).toFixed(2)),
            words: (seg.words || []).map((w: any) => ({
              ...w,
              start: Number((w.start + chunk.startTime).toFixed(2)),
              end: Number((w.end + chunk.startTime).toFixed(2)),
            })),
          }));
          allSegments.push(...chunkSegments);
        }
      }

      if (allSegments.length > 0) {
        const reindexed = allSegments.map((s, idx) => ({ ...s, id: idx + 1 }));
        updateSegmentsWithHistory(reindexed, true);
        setSelectedSegmentIds([reindexed[0].id]);
        showToast(`تم استخراج ${reindexed.length} مقطع كابشن متزامن في التايم لاين بنجاح!`, 'success');
      } else {
        showToast('لم يتم اكتشاف أي كلام في المقطع الصوتي', 'info');
      }
    } catch (err: any) {
      console.error('Groq transcription error:', err);
      showToast(err.message || 'حدث خطأ أثناء الاتصال بـ Groq API', 'error');
    } finally {
      setIsTranscribing(false);
    }
  };

  // 2. Transcribe & Optional Translate with Gemini Audio (دقيقة بدقيقة - 60 ثانية لكل جزء)
  const handleGenerateGemini = async (translateTo?: string) => {
    if (!videoSrc) {
      showToast('يرجى اختيار ملف فيديو أو صوت أولاً', 'error');
      return;
    }

    setIsTranscribing(true);
    const actionText = translateTo
      ? `جاري تفريغ الصوت وترجمته إلى ${translateTo} عبر Gemini AI (دقيقة بدقيقة)...`
      : 'جاري استخراج الكابشن الصوتي عبر Gemini AI (دقيقة بدقيقة)...';
    showToast(actionText, 'info');

    try {
      let mediaBlob: Blob;
      if (videoFile) {
        mediaBlob = videoFile;
      } else {
        const res = await fetch(videoSrc);
        mediaBlob = await res.blob();
      }

      // Automatically chunk audio into 60s (1 minute) pieces
      const chunks = await extractAudioChunksFromVideo(mediaBlob, 60);
      const allSegments: SubtitleSegment[] = [];

      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        if (chunks.length > 1) {
          showToast(`جاري معالجة الصوت عبر Gemini: الدقيقة ${i + 1} من ${chunks.length} (${chunk.formattedRange})...`, 'info');
        }

        const res = await safeApiFetch('/api/gemini/transcribe', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-gemini-api-key': geminiKey,
          },
          body: JSON.stringify({
            audioBase64: chunk.audioBase64,
            mimeType: 'audio/wav',
            translateTo: translateTo || undefined,
          }),
        });

        if (!res.ok) {
          throw new Error(res.error || `فشل توليد الكابشن عبر Gemini للدقيقة ${i + 1}`);
        }

        const data = res.data;
        if (data?.segments && data.segments.length > 0) {
          const chunkSegments = data.segments.map((seg: any) => {
            const rawKeywords = Array.isArray(seg.keywords) ? seg.keywords : [];
            const highlightKeywords =
              rawKeywords.length > 0
                ? rawKeywords.map((kw: any) => ({
                    word: typeof kw === 'string' ? kw : kw.word,
                    category: typeof kw === 'object' && kw.category ? kw.category : 'yellow',
                  }))
                : detectRuleBasedKeywords(seg.text);

            const startSec = typeof seg.start === 'number' ? seg.start : parseFloat(seg.start) || 0;
            const endSec = typeof seg.end === 'number' ? seg.end : parseFloat(seg.end) || (startSec + 2);

            return {
              ...seg,
              start: Number((startSec + chunk.startTime).toFixed(2)),
              end: Number((endSec + chunk.startTime).toFixed(2)),
              highlightKeywords,
              words: (seg.words || []).map((w: any) => {
                const wStart = typeof w.start === 'number' ? w.start : parseFloat(w.start) || 0;
                const wEnd = typeof w.end === 'number' ? w.end : parseFloat(w.end) || (wStart + 0.3);
                return {
                  ...w,
                  start: Number((wStart + chunk.startTime).toFixed(2)),
                  end: Number((wEnd + chunk.startTime).toFixed(2)),
                };
              }),
            };
          });
          allSegments.push(...chunkSegments);
        }
      }

      if (allSegments.length > 0) {
        const splitted = splitLongSegments(allSegments, 5);
        const reindexed = splitted.map((s, idx) => ({ ...s, id: idx + 1 }));
        updateSegmentsWithHistory(reindexed, true);
        setSelectedSegmentIds([reindexed[0].id]);
        if (videoElementRef.current) {
          videoElementRef.current.currentTime = reindexed[0].start;
        }
        setCurrentTime(reindexed[0].start);
        showToast(
          translateTo
            ? `تم استخراج وترجمة ${reindexed.length} مقطع كابشن متزامن عبر Gemini بنجاح!`
            : `تم توليد ${reindexed.length} مقطع كابشن متزامن عبر Gemini بنجاح!`,
          'success'
        );
      } else {
        showToast('لم يتم اكتشاف أي كلام في المقطع الصوتي', 'info');
      }
    } catch (err: any) {
      console.error('Gemini error:', err);
      showToast(err.message || 'حدث خطأ في توليد الكابشن عبر Gemini', 'error');
    } finally {
      setIsTranscribing(false);
    }
  };

  // 3. Smart Keyword Detection with Gemini (مع دعم تلقائي فوري للمحرك المحلي عند 503)
  const handleDetectSmartKeywords = async () => {
    if (segments.length === 0) return;

    setIsProcessingAI(true);
    showToast('جاري كشف الكلمات المفتاحية وتلوينها...', 'info');

    try {
      const res = await safeApiFetch('/api/gemini/smart-keywords', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          segments,
          style: 'viral',
        }),
      });

      if (res.ok && res.data?.segments && res.data.segments.length > 0) {
        setSegments(res.data.segments);
        showToast('تم تلوين الكلمات المفتاحية بالذكاء الاصطناعي بنجاح! ✨', 'success');
        return;
      }
      throw new Error(res.error || 'local fallback');
    } catch (err: any) {
      console.warn('Gemini keywords warning, using instant local engine:', err?.message || err);
      const localUpdated = segments.map((seg) => ({
        ...seg,
        highlightKeywords: detectRuleBasedKeywords(seg.text),
      }));
      setSegments(localUpdated);
      showToast('تم تلوين الكلمات المفتاحية بنجاح عبر المحرك الذكي الداخلي! ✨', 'success');
    } finally {
      setIsProcessingAI(false);
    }
  };

  // 4. Translate Subtitles with Gemini
  const handleTranslate = async (targetLanguage: string) => {
    if (segments.length === 0) return;

    setIsProcessingAI(true);
    showToast(`جاري ترجمة الكابشن إلى ${targetLanguage}...`, 'info');

    try {
      const res = await safeApiFetch('/api/gemini/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          segments,
          targetLanguage,
        }),
      });

      if (!res.ok) {
        throw new Error(res.error || 'فشلت الترجمة مؤقتاً');
      }

      if (res.data?.segments) {
        const mapped = res.data.segments.map((seg: any, idx: number) => {
          const rawKeywords = Array.isArray(seg.keywords) ? seg.keywords : [];
          const highlightKeywords =
            rawKeywords.length > 0
              ? rawKeywords.map((kw: any) => ({
                  word: typeof kw === 'string' ? kw : kw.word,
                  category: typeof kw === 'object' && kw.category ? kw.category : 'yellow',
                }))
              : (seg.highlightKeywords && seg.highlightKeywords.length > 0 ? seg.highlightKeywords : detectRuleBasedKeywords(seg.text));
          return {
            ...seg,
            id: seg.id || idx + 1,
            start: typeof seg.start === 'number' ? seg.start : parseFloat(seg.start) || 0,
            end: typeof seg.end === 'number' ? seg.end : parseFloat(seg.end) || 0,
            highlightKeywords,
          };
        });
        const splitted = splitLongSegments(mapped, 5);
        const reindexed = splitted.map((s, idx) => ({ ...s, id: idx + 1 }));
        updateSegmentsWithHistory(reindexed, true);
        if (reindexed.length > 0) {
          setSelectedSegmentIds([reindexed[0].id]);
          if (videoElementRef.current) {
            videoElementRef.current.currentTime = reindexed[0].start;
          }
          setCurrentTime(reindexed[0].start);
        }
        showToast(`تمت الترجمة وتقسيم السطور بنجاح إلى ${targetLanguage}! 🌐`, 'success');
      }
    } catch (err: any) {
      console.error('Translation error:', err);
      showToast(err.message || 'حدث خطأ أثناء الترجمة', 'error');
    } finally {
      setIsProcessingAI(false);
    }
  };

  // 5. AI Spell Check & Linguistic Correction (Strict letter typo fix, no rephrase)
  const handleFixGrammar = async () => {
    if (segments.length === 0) return;

    if (!isGrammarEnabled) {
      showToast('التدقيق الإملائي معطّل حالياً. اضغط على "التدقيق: مفعل" لتشغيله.', 'info');
      return;
    }

    setIsProcessingAI(true);
    showToast('جاري تدقيق الأحرف الإملائية (التاء المربوطة والهمزات) دون تغيير أي كلمة أو معنى...', 'info');

    try {
      const res = await safeApiFetch('/api/gemini/grammar-fix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ segments }),
      });

      if (res.ok && res.data?.segments) {
        setSegments(res.data.segments);
        const count = res.data.corrections ? res.data.corrections.length : 0;
        if (count > 0) {
          showToast(`تم تصحيح ${count} خطأ إملائي بنجاح دون تغيير أي معنى! ✨`, 'success');
        } else {
          showToast('النص سليم إملائياً بالفعل، وتم الإبقاء عليه كما هو بالحرف! 👍', 'success');
        }
        return;
      }
      throw new Error(res.error || 'local fallback');
    } catch (err: any) {
      console.warn('Gemini grammar-fix warning, applying local orthography checker:', err?.message || err);
      const localResult = fixLinguisticOrthographyLocal(segments);
      setSegments(localResult.segments);
      if (localResult.corrections.length > 0) {
        showToast(`تم تصحيح ${localResult.corrections.length} خطأ إملائي محلياً دون أي تعديل في المعنى! ✨`, 'success');
      } else {
        showToast('تم فحص النص وتأكيد سلامته الإملائية مع الحفاظ على كل كلمة! 👍', 'success');
      }
    } finally {
      setIsProcessingAI(false);
    }
  };

  // 6. Smart Sentence Restructuring & Idiom Grouping
  const handleSmartResegment = async () => {
    if (segments.length === 0) return;

    setIsProcessingAI(true);
    showToast('جاري تجميع الجمل المترابطة والتحيات لمنع التقطيع الخاطئ والأسطر المتراكمة...', 'info');

    try {
      const res = await safeApiFetch('/api/gemini/smart-resegment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ segments }),
      });

      if (res.ok && res.data?.segments && res.data.segments.length > 0) {
        const splitted = splitLongSegments(res.data.segments, 5);
        const reindexed = splitted.map((s, idx) => ({ ...s, id: idx + 1 }));
        setSegments(reindexed);
        showToast(`تمت إعادة تنظيم وتقسيم الكابشن إلى ${reindexed.length} مقطع متماسك بدقة! 🧩`, 'success');
        return;
      }
      throw new Error(res.error || 'local fallback');
    } catch (err: any) {
      console.warn('Smart resegment API warning, using instant local grouping:', err?.message || err);
      const localResult = smartResegmentLocal(segments);
      const splitted = splitLongSegments(localResult, 5);
      const reindexed = splitted.map((s, idx) => ({ ...s, id: idx + 1 }));
      setSegments(reindexed);
      showToast(`تم تنسيق وتقسيم الجمل بنجاح عبر المحرك الذكي الداخلي! 🧩`, 'success');
    } finally {
      setIsProcessingAI(false);
    }
  };

  // 7. Global Time-Shift
  const handleShiftAllTime = (delta: number) => {
    if (segments.length === 0) return;

    const updated = segments.map((seg) => {
      const newStart = Math.max(0, Number((seg.start + delta).toFixed(2)));
      const newEnd = Math.max(newStart + 0.1, Number((seg.end + delta).toFixed(2)));
      return {
        ...seg,
        start: newStart,
        end: newEnd,
      };
    });

    updateSegmentsWithHistory(updated, true);
    const signText = delta < 0 ? `تقديم كل الكابشن بمقدار ${Math.abs(delta)} ثانية` : `تأخير كل الكابشن بمقدار ${delta} ثانية`;
    showToast(`تم ${signText} لضبط المزامنة مع الكلام! ⏱️`, 'info');
  };

  // 8. Auto-Trim Silence Gaps
  const handleTrimSilence = () => {
    if (segments.length === 0) return;
    const trimmed = trimSilenceGaps(segments, 0.32);
    updateSegmentsWithHistory(trimmed, true);
    showToast('تم تقليم فترات الصمت لتختفي الكلمات فور توقف المتحدث عن الكلام! 🧹', 'success');
  };

  // 9. Extract Key Highlights Only (Weapons, Diseases, People, Countries, Numbers, Science, Tech, 1-3 words, 3.5s duration)
  // طلب المستخدم الصريح: "كتابات للاشياء المهمه بس: اسم سلاح، اسم مرض، اسماء اشخاص، دول، ارقام... متزدش عن 3 كلمات وتسيب 3 او 4 ثواني بعد ما يقول بس يظهر اول ما يقول الكلمه"
  const handleExtractKeyHighlights = async () => {
    // If we're not currently in keywords mode or if backup is empty, save the full transcript!
    const sourceSegments =
      !isKeywordsOnlyMode && segments.length > 0
        ? segments
        : fullTranscriptBackup && fullTranscriptBackup.length > 0
        ? fullTranscriptBackup
        : segments;

    if (sourceSegments.length === 0) {
      showToast('لا توجد مقاطع كابشن حالياً لاستخراج الكلمات الهامة منها', 'info');
      return;
    }

    if (!fullTranscriptBackup || fullTranscriptBackup.length === 0) {
      setFullTranscriptBackup(sourceSegments);
    }

    setIsProcessingAI(true);
    showToast('جاري استخراج المصطلحات والكلمات المفتاحية البارزة بالذكاء الاصطناعي... 🎯', 'info');

    try {
      const res = await safeApiFetch('/api/gemini/extract-highlights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ segments: sourceSegments }),
      });

      if (res.ok && res.data?.segments && res.data.segments.length > 0) {
        updateSegmentsWithHistory(res.data.segments, true);
        setSelectedSegmentIds([res.data.segments[0].id]);
        setIsKeywordsOnlyMode(true);
        showToast(`تم استخراج ${res.data.segments.length} من المصطلحات والكلمات البارزة (تظهر 3.5 ثوانٍ عند نطقها)! 🎯`, 'success');
        return;
      }
      throw new Error('Local fallback');
    } catch (err: any) {
      console.warn('Using smart local highlight extractor:', err?.message || err);
      const localHighlights = extractKeyHighlightsLocal(sourceSegments);
      if (localHighlights.length > 0) {
        updateSegmentsWithHistory(localHighlights, true);
        setSelectedSegmentIds([localHighlights[0].id]);
        setIsKeywordsOnlyMode(true);
        showToast(`تم استخراج ${localHighlights.length} من المصطلحات والكلمات البارزة بنجاح! 🎯`, 'success');
      } else {
        showToast('لم يتم العثور على كلمات واضحة، تم الإبقاء على النص الأصلي', 'info');
      }
    } finally {
      setIsProcessingAI(false);
    }
  };

  // Toggle between Full Transcript and Smart Keywords Only
  const handleToggleKeywordsOnlyMode = () => {
    if (isKeywordsOnlyMode) {
      if (fullTranscriptBackup && fullTranscriptBackup.length > 0) {
        updateSegmentsWithHistory(fullTranscriptBackup, true);
        setIsKeywordsOnlyMode(false);
        showToast('تمت العودة إلى وضع الكابشن الكامل (جميع الكلمات) 📝', 'info');
      } else {
        setIsKeywordsOnlyMode(false);
        showToast('تم إيقاف وضع الكلمات المهمة', 'info');
      }
    } else {
      handleExtractKeyHighlights();
    }
  };

  return (
    <div
      ref={mainContainerRef}
      className="h-screen w-screen bg-[#F6F5F3] text-[#1C1C1E] flex flex-col overflow-hidden select-none"
    >
      {/* 1. Premiere Pro Header Bar */}
      <PremiereHeader
        lang={lang}
        onToggleLanguage={handleToggleLanguage}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        onLoadSample={handleLoadSample}
        segmentCount={segments.length}
        layoutPreset={layoutPreset}
        onSelectLayoutPreset={handleSelectLayoutPreset}
      />

      {/* Real-time AI Processing Progress Banner (User Request #3) */}
      {(isTranscribing || isProcessingAI) && (
        <div className="bg-[#FAF0EC] border-b border-[#FED7AA] px-4 py-2 flex items-center justify-between text-xs z-40 shadow-xs animate-in slide-in-from-top duration-200">
          <div className="flex items-center gap-3 w-full max-w-2xl">
            <Loader2 className="w-4 h-4 animate-spin text-[#E0532B] shrink-0" />
            <div className="space-y-0.5 flex-1">
              <div className="flex items-center justify-between font-bold text-[#1C1C1E]">
                <span>{translations[lang].processingTitle}</span>
                {aiProgress > 0 && <span className="text-[#E0532B] font-mono">{aiProgress}%</span>}
              </div>
              {/* Progress Bar */}
              <div className="w-full bg-[#E5E0D8] rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-[#E0532B] to-[#F97316] h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.max(12, aiProgress)}%` }}
                />
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              setIsTranscribing(false);
              setIsProcessingAI(false);
            }}
            className="text-[11px] text-[#78716C] hover:text-[#1C1C1E] px-2 py-1 rounded-md bg-white border border-[#E5E0D8] transition shadow-2xs"
          >
            {translations[lang].cancel}
          </button>
        </div>
      )}

      {/* Floating Toast Notification Banner */}
      {statusNotification && (
        <div
          className={`absolute top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-2 shadow-xl transition-all border backdrop-blur-md ${
            statusNotification.type === 'success'
              ? 'bg-emerald-50/95 border-emerald-300 text-emerald-800'
              : statusNotification.type === 'error'
              ? 'bg-rose-50/95 border-rose-300 text-rose-800'
              : 'bg-white/95 border-[#E5E0D8] text-[#1C1C1E]'
          }`}
        >
          {statusNotification.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
          {statusNotification.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-600" />}
          {statusNotification.type === 'info' && <Sparkles className="w-4 h-4 text-amber-500" />}
          <span className="font-semibold">{statusNotification.message}</span>
        </div>
      )}

      {/* 2. Main Resizable Layout Grid (User Request #1) */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Area: Program Monitor & Project Inspector */}
        <div
          ref={topWorkspaceRef}
          style={{ height: `${topHeightPercent}%` }}
          className="flex flex-col md:flex-row overflow-hidden relative"
        >
          {/* Program Monitor Pane */}
          <div
            style={{ width: `${leftWidthPercent}%` }}
            className="h-full overflow-hidden flex flex-col min-w-[200px]"
          >
            <ProgramMonitor
              lang={lang}
              videoSrc={videoSrc}
              videoElementRef={videoElementRef}
              segments={segments}
              activePreset={activePreset}
              currentTime={currentTime}
              duration={duration}
              isPlaying={isPlaying}
              onTimeUpdate={setCurrentTime}
              onDurationChange={setDuration}
              onPlayPause={handlePlayPause}
              onSeek={handleSeek}
              onFileUpload={handleFileUpload}
              onLoadSample={handleLoadSample}
              onSplitAtPlayhead={handleSplitAtPlayhead}
              onDeleteSelected={handleDeleteSelected}
              onOpenExport={() => setIsExportOpen(true)}
              captionVisibilityRange={captionVisibilityRange}
              isAudioOnly={isAudioOnly}
              backgroundMode={backgroundMode}
              onToggleGreenScreen={handleToggleGreenScreen}
              onSplitVideo={handleSplitVideo}
              onMergeVideoCuts={handleMergeVideoCuts}
            />
          </div>

          {/* Draggable Vertical Splitter Handle */}
          <div
            onMouseDown={handleHorizontalResize}
            onDoubleClick={() => handleSelectLayoutPreset('default')}
            className="w-1.5 hover:w-2 bg-[#E5E0D8] hover:bg-[#E0532B] cursor-col-resize flex items-center justify-center transition-all z-20 group shrink-0"
            title={lang === 'en' ? 'Drag to resize player / inspector | Double click to reset' : 'اسحب لتعديل عرض الشاشة / لوحة التحكم | نقر مزدوج للضبط الافتراضي'}
          >
            <GripVertical className="w-3 h-3 text-[#A8A29E] group-hover:text-white" />
          </div>

          {/* Project Inspector Pane */}
          <div className="flex-1 h-full overflow-hidden flex flex-col min-w-[220px]">
            <ProjectInspector
              lang={lang}
              segments={segments}
              selectedSegmentId={selectedSegmentIds[0] ?? null}
              currentTime={currentTime}
              duration={duration}
              activePreset={activePreset}
              videoSrc={videoSrc}
              videoFile={videoFile}
              showCustomizer={showCustomizer}
              captionVisibilityRange={captionVisibilityRange}
              isGrammarEnabled={isGrammarEnabled}
              isTranscribing={isTranscribing}
              isProcessingAI={isProcessingAI}
              groqConnected={Boolean(groqKey)}
              onUpdateSegments={updateSegmentsWithHistory}
              onSeek={handleSeek}
              onSelectSegment={(id) => setSelectedSegmentIds(id ? [id] : [])}
              onSelectPreset={setActivePreset}
              onToggleCustomizer={() => setShowCustomizer(!showCustomizer)}
              onGenerateGroq={handleGenerateGroq}
              onGenerateGemini={handleGenerateGemini}
              onDetectSmartKeywords={handleDetectSmartKeywords}
              onTranslate={handleTranslate}
              onFixGrammar={handleFixGrammar}
              onToggleGrammar={() => setIsGrammarEnabled(!isGrammarEnabled)}
              onSmartResegment={handleSmartResegment}
              onShiftAllTime={handleShiftAllTime}
              onExtractKeyHighlights={handleExtractKeyHighlights}
              onTrimSilence={handleTrimSilence}
              onUpdateCaptionVisibilityRange={setCaptionVisibilityRange}
              onLoadSample={handleLoadSample}
              onFileUpload={handleFileUpload}
              isKeywordsOnlyMode={isKeywordsOnlyMode}
              onToggleKeywordsOnlyMode={handleToggleKeywordsOnlyMode}
            />
          </div>
        </div>

        {/* Draggable Horizontal Splitter Handle */}
        <div
          onMouseDown={handleVerticalResize}
          onDoubleClick={() => handleSelectLayoutPreset('default')}
          className="h-1.5 hover:h-2 bg-[#E5E0D8] hover:bg-[#E0532B] cursor-row-resize flex items-center justify-center transition-all z-20 group shrink-0"
          title={lang === 'en' ? 'Drag to resize top workspace / timeline | Double click to reset' : 'اسحب لتعديل ارتفاع التايم لاين | نقر مزدوج للضبط الافتراضي'}
        >
          <GripHorizontal className="w-3 h-3 text-[#A8A29E] group-hover:text-white" />
        </div>

        {/* Bottom Area: Full-Width Interactive Timeline */}
        <div className="flex-1 overflow-hidden flex flex-col min-h-[120px]">
          <Timeline
            lang={lang}
            duration={duration}
            currentTime={currentTime}
            segments={segments}
            selectedSegmentIds={selectedSegmentIds}
            isPlaying={isPlaying}
            canUndo={history.length > 0}
            canRedo={redoStack.length > 0}
            onUndo={handleUndo}
            onRedo={handleRedo}
            onSeek={handleSeek}
            onSelectSegments={setSelectedSegmentIds}
            onUpdateSegments={updateSegmentsWithHistory}
            onSplitAtPlayhead={handleSplitAtPlayhead}
            onDeleteSelected={handleDeleteSelected}
            onAddSegmentAtPlayhead={handleAddSegmentAtPlayhead}
            videoCuts={videoCuts}
            selectedCutId={selectedCutId}
            onSelectCut={setSelectedCutId}
            onSplitVideo={handleSplitVideo}
            onDeleteCut={handleDeleteVideoCut}
            onMergeCuts={handleMergeVideoCuts}
          />
        </div>
      </div>

      {/* Settings Modal (Groq API Key / Gemini) */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        groqKey={groqKey}
        onSaveGroqKey={handleSaveGroqKey}
        geminiKey={geminiKey}
        onSaveGeminiKey={handleSaveGeminiKey}
        geminiConnected={geminiConnected}
      />

      {/* Export / Burn Subtitles Modal */}
      <ExportModal
        lang={lang}
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        videoElement={videoElementRef.current}
        videoFile={videoFile}
        segments={segments}
        activePreset={activePreset}
        duration={duration}
        captionVisibilityRange={captionVisibilityRange}
        isAudioOnly={isAudioOnly}
        initialBackgroundMode={backgroundMode}
      />
    </div>
  );
}
