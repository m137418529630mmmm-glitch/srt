import { SubtitleSegment } from '../types';

export const SAMPLE_VIDEO_URL = '/sample.mp4';
export const SAMPLE_VIDEO_FALLBACK = '/sample.mp4';

export const SAMPLE_SEGMENTS_AR: SubtitleSegment[] = [
  {
    id: 1,
    start: 0.2,
    end: 2.8,
    text: 'هذا هو السر الحقيقي للنجاح اليوم',
    highlightKeywords: [
      { word: 'السر', category: 'yellow' },
      { word: 'للنجاح', category: 'green' },
    ],
    words: [
      { word: 'هذا', start: 0.2, end: 0.6 },
      { word: 'هو', start: 0.6, end: 1.0 },
      { word: 'السر', start: 1.0, end: 1.6, isKeyword: true, color: '#FFE600' },
      { word: 'الحقيقي', start: 1.6, end: 2.1 },
      { word: 'للنجاح', start: 2.1, end: 2.5, isKeyword: true, color: '#22C55E' },
      { word: 'اليوم', start: 2.5, end: 2.8 },
    ],
  },
  {
    id: 2,
    start: 2.9,
    end: 5.6,
    text: 'معظم الناس يرتكبون هذا الخطأ القاتل',
    highlightKeywords: [
      { word: 'الخطأ', category: 'red' },
      { word: 'القاتل', category: 'red' },
    ],
    words: [
      { word: 'معظم', start: 2.9, end: 3.4 },
      { word: 'الناس', start: 3.4, end: 3.9 },
      { word: 'يرتكبون', start: 3.9, end: 4.5 },
      { word: 'هذا', start: 4.5, end: 4.8 },
      { word: 'الخطأ', start: 4.8, end: 5.2, isKeyword: true, color: '#EF4444' },
      { word: 'القاتل', start: 5.2, end: 5.6, isKeyword: true, color: '#EF4444' },
    ],
  },
  {
    id: 3,
    start: 5.8,
    end: 8.7,
    text: 'باستخدام الذكاء الاصطناعي يمكنك مضاعفة نتائجك 10X',
    highlightKeywords: [
      { word: 'الذكاء', category: 'cyan' },
      { word: 'الاصطناعي', category: 'cyan' },
      { word: '10X', category: 'yellow' },
    ],
    words: [
      { word: 'باستخدام', start: 5.8, end: 6.3 },
      { word: 'الذكاء', start: 6.3, end: 6.8, isKeyword: true, color: '#00F0FF' },
      { word: 'الاصطناعي', start: 6.8, end: 7.3, isKeyword: true, color: '#00F0FF' },
      { word: 'يمكنك', start: 7.3, end: 7.7 },
      { word: 'مضاعفة', start: 7.7, end: 8.1 },
      { word: 'نتائجك', start: 8.1, end: 8.4 },
      { word: '10X', start: 8.4, end: 8.7, isKeyword: true, color: '#FFE600' },
    ],
  },
  {
    id: 4,
    start: 8.9,
    end: 12.0,
    text: 'ابدأ الآن ولا تفوت هذه الفرصة الذهبية',
    highlightKeywords: [
      { word: 'ابدأ', category: 'green' },
      { word: 'الفرصة', category: 'yellow' },
      { word: 'الذهبية', category: 'yellow' },
    ],
    words: [
      { word: 'ابدأ', start: 8.9, end: 9.4, isKeyword: true, color: '#22C55E' },
      { word: 'الآن', start: 9.4, end: 9.9 },
      { word: 'ولا', start: 9.9, end: 10.3 },
      { word: 'تفوت', start: 10.3, end: 10.7 },
      { word: 'هذه', start: 10.7, end: 11.0 },
      { word: 'الفرصة', start: 11.0, end: 11.5, isKeyword: true, color: '#FFE600' },
      { word: 'الذهبية', start: 11.5, end: 12.0, isKeyword: true, color: '#FFE600' },
    ],
  },
];
