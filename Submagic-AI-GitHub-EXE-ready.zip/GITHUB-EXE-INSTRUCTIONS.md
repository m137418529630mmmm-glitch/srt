# Build Submagic AI EXE with GitHub Actions

1. Upload the contents of this folder to your GitHub repository (including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Submagic AI for Windows** and click **Run workflow**, or push a commit to `main`/`master`.
4. When the workflow completes, open its run and download the `Submagic-AI-Windows-Installer` artifact.

The workflow builds a Windows x64 NSIS installer. The first build may take several minutes. Check the Actions logs if it fails.

API keys should be entered by each user in the app or configured securely; do not commit `.env` files or private API keys.
